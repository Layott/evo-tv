"use client"

import { ChevronRight } from "lucide-react"
import Image from "next/image"
import { useRouter } from "next/navigation"

const liveStreams = [
  {
    id: 1,
    title: "Pro Match - Team A vs Team B",
    viewers: "45.2K",
    image: "/esports-live-stream-match.jpg",
  },
  {
    id: 2,
    title: "Ranked Grind Session",
    viewers: "12.8K",
    image: "/esports-ranked-gameplay.jpg",
  },
  {
    id: 3,
    title: "Tournament Qualifier",
    viewers: "78.5K",
    image: "/esports-tournament-qualifier.jpg",
  },
  {
    id: 4,
    title: "Casual Gameplay",
    viewers: "5.3K",
    image: "/esports-casual-gameplay-stream.jpg",
  },
]

export default function LiveNowSection() {
  const router = useRouter()

  return (
    <div className="px-4 py-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-white">Live Now</h2>
        <button className="flex items-center gap-1" style={{ color: "#2CD7E3" }}>
          View All <ChevronRight size={16} />
        </button>
      </div>

      {/* Horizontal scroll container */}
      <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
        {liveStreams.map((stream) => (
          <div
            key={stream.id}
            onClick={() => router.push(`/stream/${stream.id}`)}
            className="flex-shrink-0 w-48 rounded-lg overflow-hidden cursor-pointer transition-transform hover:scale-105"
            style={{
              border: "1px solid rgba(44, 215, 227, 0.3)",
            }}
          >
            {/* Thumbnail */}
            <div className="relative w-full h-28">
              <Image src={stream.image || "/placeholder.svg"} alt={stream.title} fill className="object-cover" />
              {/* Live badge */}
              <div
                className="absolute top-2 left-2 px-2 py-1 rounded text-xs font-bold"
                style={{
                  backgroundColor: "#00FF00",
                  color: "#000000",
                }}
              >
                LIVE
              </div>
              {/* Viewers count */}
              <div className="absolute bottom-2 right-2 text-xs font-semibold" style={{ color: "#2CD7E3" }}>
                {stream.viewers}
              </div>
            </div>

            {/* Info */}
            <div className="p-3 bg-opacity-50" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
              <p className="text-sm font-semibold text-white truncate">{stream.title}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
