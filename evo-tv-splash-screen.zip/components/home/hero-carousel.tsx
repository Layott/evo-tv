"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"

const heroMatches = [
  {
    id: 1,
    title: "Championship Finals",
    subtitle: "Team Alpha vs Team Beta",
    viewers: "125.4K",
    image: "/esports-championship-finals-live-stream.jpg",
  },
  {
    id: 2,
    title: "Regional Qualifier",
    subtitle: "Eastern Conference",
    viewers: "89.2K",
    image: "/esports-regional-qualifier-tournament.jpg",
  },
  {
    id: 3,
    title: "Pro League Match",
    subtitle: "Week 5 Playoffs",
    viewers: "156.8K",
    image: "/esports-pro-league-playoff-match.jpg",
  },
]

export default function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const router = useRouter()

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroMatches.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  return (
    <div className="relative w-full h-64 overflow-hidden">
      {heroMatches.map((match, index) => (
        <div
          key={match.id}
          onClick={() => router.push(`/stream/${match.id}`)}
          className={`absolute inset-0 transition-opacity duration-1000 cursor-pointer ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          <Image src={match.image || "/placeholder.svg"} alt={match.title} fill className="object-cover" />
          {/* Gradient overlay */}
          <div
            className="absolute inset-0"
            style={{
              background: "linear-gradient(to top, rgba(0,0,0,0.8), transparent)",
            }}
          />
          {/* Content */}
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <h2 className="text-xl font-bold text-white">{match.title}</h2>
            <p className="text-sm" style={{ color: "#2CD7E3" }}>
              {match.subtitle}
            </p>
            <p className="text-xs mt-1" style={{ color: "#00FF00" }}>
              🔴 LIVE • {match.viewers} watching
            </p>
          </div>
        </div>
      ))}

      {/* Carousel indicators */}
      <div className="absolute bottom-4 right-4 flex gap-2">
        {heroMatches.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className="w-2 h-2 rounded-full transition-all"
            style={{
              backgroundColor: index === currentSlide ? "#2CD7E3" : "rgba(44, 215, 227, 0.3)",
            }}
          />
        ))}
      </div>
    </div>
  )
}
