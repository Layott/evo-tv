"use client"

import Image from "next/image"

export default function AdBanner() {
  return (
    <div className="px-4 py-6">
      <div
        className="w-full h-32 rounded-lg overflow-hidden cursor-pointer transition-opacity hover:opacity-90"
        style={{
          border: "1px solid rgba(44, 215, 227, 0.3)",
          backgroundColor: "rgba(44, 215, 227, 0.05)",
        }}
      >
        <Image
          src="/gaming-product-advertisement-banner.jpg"
          alt="Advertisement"
          width={400}
          height={128}
          className="w-full h-full object-cover"
        />
      </div>
    </div>
  )
}
