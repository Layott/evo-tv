"use client"

import { TrendingUp } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const trendingClips = [
  {
    id: "101",
    title: "Insane 1v5 Clutch",
    creator: "ProPlayer123",
    views: "2.3M",
    image: "/esports-highlight-clutch-play.jpg",
  },
  {
    id: "102",
    title: "Championship Winning Moment",
    creator: "EsportsDaily",
    views: "1.8M",
    image: "/esports-championship-winning-moment.jpg",
  },
  {
    id: "103",
    title: "Best Plays of the Week",
    creator: "HighlightReel",
    views: "3.1M",
    image: "/esports-best-plays-highlights.jpg",
  },
]

export default function TrendingClipsSection() {
  return (
    <div className="px-4 py-6">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp size={20} style={{ color: "#2CD7E3" }} />
        <h2 className="text-lg font-bold text-white">Trending Clips</h2>
      </div>

      <div className="space-y-3">
        {trendingClips.map((clip) => (
          <Link
            key={clip.id}
            href={`/vod/${clip.id}`}
            className="flex gap-3 rounded-lg overflow-hidden cursor-pointer transition-all hover:opacity-80"
            style={{
              border: "1px solid rgba(44, 215, 227, 0.3)",
              backgroundColor: "rgba(0, 0, 0, 0.3)",
            }}
          >
            {/* Thumbnail */}
            <div className="relative w-24 h-24 flex-shrink-0">
              <Image src={clip.image || "/placeholder.svg"} alt={clip.title} fill className="object-cover" />
              {/* Play icon overlay */}
              <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30 hover:bg-opacity-50 transition-all">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: "#2CD7E3" }}
                >
                  <div className="w-0 h-0 border-l-4 border-l-black border-t-2 border-t-transparent border-b-2 border-b-transparent ml-1" />
                </div>
              </div>
            </div>

            {/* Info */}
            <div className="flex-1 p-3 flex flex-col justify-between">
              <div>
                <p className="text-sm font-semibold text-white">{clip.title}</p>
                <p className="text-xs" style={{ color: "#666666" }}>
                  by {clip.creator}
                </p>
              </div>
              <p className="text-xs font-semibold" style={{ color: "#2CD7E3" }}>
                {clip.views} views
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
