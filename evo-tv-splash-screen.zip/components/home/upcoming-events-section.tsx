"use client"

import { Clock } from "lucide-react"
import Image from "next/image"
import { useRouter } from "next/navigation"

const upcomingEvents = [
  {
    id: "1",
    title: "Championship Finals",
    date: "2025-11-15",
    time: "18:00",
    hoursUntil: 24,
    image: "/esports-championship-finals-event.jpg",
  },
  {
    id: "2",
    title: "Regional Qualifier",
    date: "2025-11-16",
    time: "20:00",
    hoursUntil: 48,
    image: "/esports-regional-qualifier-event.jpg",
  },
  {
    id: "3",
    title: "Pro League Week 6",
    date: "2025-11-17",
    time: "19:00",
    hoursUntil: 72,
    image: "/esports-pro-league-event.jpg",
  },
]

function CountdownTimer({ hoursUntil }: { hoursUntil: number }) {
  const days = Math.floor(hoursUntil / 24)
  const hours = hoursUntil % 24

  return (
    <div className="flex items-center gap-1 text-xs font-semibold" style={{ color: "#16CFF3" }}>
      <Clock size={14} />
      {days > 0 && `${days}d `}
      {hours}h
    </div>
  )
}

export default function UpcomingEventsSection() {
  const router = useRouter()

  return (
    <div className="px-4 py-6">
      <h2 className="text-lg font-bold text-white mb-4">Upcoming Events</h2>

      <div className="space-y-3">
        {upcomingEvents.map((event) => (
          <div
            key={event.id}
            onClick={() => router.push(`/events/${event.id}`)}
            className="flex gap-3 rounded-lg overflow-hidden cursor-pointer transition-all hover:opacity-80"
            style={{
              border: "1px solid rgba(44, 215, 227, 0.3)",
              backgroundColor: "rgba(0, 0, 0, 0.3)",
            }}
          >
            {/* Thumbnail */}
            <div className="relative w-24 h-24 flex-shrink-0">
              <Image src={event.image || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
            </div>

            {/* Info */}
            <div className="flex-1 p-3 flex flex-col justify-between">
              <div>
                <p className="text-sm font-semibold text-white">{event.title}</p>
                <p className="text-xs" style={{ color: "#666666" }}>
                  {event.date} at {event.time}
                </p>
              </div>
              <CountdownTimer hoursUntil={event.hoursUntil} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
