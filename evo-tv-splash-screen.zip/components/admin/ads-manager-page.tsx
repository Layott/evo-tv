"use client"

import { useState } from "react"
import { Plus, Eye, Edit, Trash2, DollarSign } from "lucide-react"

interface Ad {
  id: string
  name: string
  type: "banner" | "video" | "native"
  cpm: number
  impressions: number
  clicks: number
  revenue: number
  status: "active" | "paused"
  placement: string[]
}

export function AdsManagerPage() {
  const [ads, setAds] = useState<Ad[]>([
    {
      id: "1",
      name: "Summer Gaming Sale",
      type: "banner",
      cpm: 5.5,
      impressions: 125000,
      clicks: 3450,
      revenue: 687.5,
      status: "active",
      placement: ["Home Feed", "Under Player"],
    },
    {
      id: "2",
      name: "New Gaming Gear",
      type: "video",
      cpm: 12.0,
      impressions: 45000,
      clicks: 890,
      revenue: 540.0,
      status: "active",
      placement: ["Pre-roll"],
    },
    {
      id: "3",
      name: "Tournament Sponsor",
      type: "native",
      cpm: 8.0,
      impressions: 78000,
      clicks: 1560,
      revenue: 624.0,
      status: "paused",
      placement: ["Events Page"],
    },
  ])

  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showPreviewModal, setShowPreviewModal] = useState(false)

  const toggleAdStatus = (id: string) => {
    setAds(ads.map((ad) => (ad.id === id ? { ...ad, status: ad.status === "active" ? "paused" : "active" } : ad)))
  }

  const totalRevenue = ads.reduce((sum, ad) => sum + ad.revenue, 0)
  const totalImpressions = ads.reduce((sum, ad) => sum + ad.impressions, 0)
  const totalClicks = ads.reduce((sum, ad) => sum + ad.clicks, 0)

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Ads Manager</h1>
          <p className="text-gray-400">Create and manage ad campaigns</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
        >
          <Plus className="w-5 h-5" />
          Create Ad
        </button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <DollarSign className="w-5 h-5 text-[#00FF00]" />
            <h3 className="text-sm text-gray-400">Total Revenue</h3>
          </div>
          <p className="text-2xl font-bold text-white">${totalRevenue.toFixed(2)}</p>
        </div>
        <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <Eye className="w-5 h-5 text-[#2CD7E3]" />
            <h3 className="text-sm text-gray-400">Total Impressions</h3>
          </div>
          <p className="text-2xl font-bold text-white">{totalImpressions.toLocaleString()}</p>
        </div>
        <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <Eye className="w-5 h-5 text-[#16CFF3]" />
            <h3 className="text-sm text-gray-400">Total Clicks</h3>
          </div>
          <p className="text-2xl font-bold text-white">{totalClicks.toLocaleString()}</p>
          <p className="text-xs text-gray-400 mt-1">CTR: {((totalClicks / totalImpressions) * 100).toFixed(2)}%</p>
        </div>
      </div>

      {/* Ads Table */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#1a1a1a] border-b border-[#2CD7E3]/20">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Name</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Type</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">CPM</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Impressions</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Clicks</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Revenue</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Status</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2CD7E3]/10">
              {ads.map((ad) => (
                <tr key={ad.id} className="hover:bg-[#1a1a1a]/50 transition-colors">
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-white font-medium">{ad.name}</p>
                      <p className="text-xs text-gray-400 mt-1">{ad.placement.join(", ")}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-[#1a1a1a] text-gray-400 rounded-full text-xs font-medium">
                      {ad.type.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-400">${ad.cpm.toFixed(2)}</td>
                  <td className="px-6 py-4 text-gray-400">{ad.impressions.toLocaleString()}</td>
                  <td className="px-6 py-4 text-gray-400">
                    {ad.clicks.toLocaleString()}
                    <span className="text-xs text-gray-500 ml-1">
                      ({((ad.clicks / ad.impressions) * 100).toFixed(1)}%)
                    </span>
                  </td>
                  <td className="px-6 py-4 text-[#00FF00] font-medium">${ad.revenue.toFixed(2)}</td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => toggleAdStatus(ad.id)}
                      className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                        ad.status === "active" ? "bg-[#00FF00]/20 text-[#00FF00]" : "bg-gray-500/20 text-gray-400"
                      }`}
                    >
                      {ad.status.toUpperCase()}
                    </button>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setShowPreviewModal(true)}
                        className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-red-500/20 hover:text-red-500 transition-all">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Ad Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0a0a0a] border border-[#2CD7E3]/30 rounded-lg p-6 max-w-md w-full">
            <h2 className="text-2xl font-bold text-white mb-4">Create Ad Campaign</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Campaign Name</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="Enter campaign name"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Ad Type</label>
                <select className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]">
                  <option>Banner</option>
                  <option>Video</option>
                  <option>Native</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">CPM ($)</label>
                <input
                  type="number"
                  step="0.01"
                  className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="5.00"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Placement</label>
                <div className="space-y-2">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="w-4 h-4 accent-[#2CD7E3]" />
                    <span className="text-sm text-gray-400">Home Feed</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="w-4 h-4 accent-[#2CD7E3]" />
                    <span className="text-sm text-gray-400">Under Player</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="w-4 h-4 accent-[#2CD7E3]" />
                    <span className="text-sm text-gray-400">Events Page</span>
                  </label>
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 px-4 py-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2a2a2a] transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 px-4 py-2 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
              >
                Create Campaign
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Preview Modal */}
      {showPreviewModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0a0a0a] border border-[#2CD7E3]/30 rounded-lg p-6 max-w-2xl w-full">
            <h2 className="text-2xl font-bold text-white mb-4">Ad Placement Preview</h2>
            <div className="space-y-4">
              <div className="bg-[#1a1a1a] rounded-lg p-4 border border-[#2CD7E3]/20">
                <p className="text-sm text-gray-400 mb-2">Home Feed Placement:</p>
                <div className="bg-gradient-to-r from-[#2CD7E3]/20 to-[#16CFF3]/20 border border-[#2CD7E3]/50 rounded-lg p-8 text-center">
                  <p className="text-white font-medium">Ad Banner Preview</p>
                  <p className="text-sm text-gray-400 mt-1">728x90 pixels</p>
                </div>
              </div>
              <div className="bg-[#1a1a1a] rounded-lg p-4 border border-[#2CD7E3]/20">
                <p className="text-sm text-gray-400 mb-2">Under Player Placement:</p>
                <div className="bg-gradient-to-r from-[#2CD7E3]/20 to-[#16CFF3]/20 border border-[#2CD7E3]/50 rounded-lg p-8 text-center">
                  <p className="text-white font-medium">Ad Banner Preview</p>
                  <p className="text-sm text-gray-400 mt-1">970x90 pixels</p>
                </div>
              </div>
            </div>
            <button
              onClick={() => setShowPreviewModal(false)}
              className="w-full mt-6 px-4 py-2 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
            >
              Close Preview
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
