"use client"

import { useState } from "react"
import Image from "next/image"
import { LayoutDashboard, Radio, BarChart3, Video, Megaphone, Users, TrendingUp, Settings, Menu, X } from "lucide-react"

interface AdminSidebarProps {
  activePage: string
  onPageChange: (page: string) => void
}

const menuItems = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "streams", label: "Streams", icon: Radio },
  { id: "polls", label: "Polls", icon: BarChart3 },
  { id: "content", label: "Content", icon: Video },
  { id: "ads", label: "Ads", icon: Megaphone },
  { id: "users", label: "Users & Roles", icon: Users },
  { id: "analytics", label: "Analytics", icon: TrendingUp },
  { id: "settings", label: "Settings", icon: Settings },
]

export function AdminSidebar({ activePage, onPageChange }: AdminSidebarProps) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 lg:hidden p-2 bg-[#1a1a1a] rounded-lg border border-[#2CD7E3]/30"
      >
        {isOpen ? <X className="w-6 h-6 text-white" /> : <Menu className="w-6 h-6 text-white" />}
      </button>

      {/* Overlay */}
      {isOpen && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setIsOpen(false)} />}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-64 bg-[#0a0a0a] border-r border-[#2CD7E3]/20 z-40 transition-transform duration-300 ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0`}
      >
        <div className="p-6 border-b border-[#2CD7E3]/20">
          <div className="flex items-center gap-3">
            <Image src="/evotv colored.png" alt="EVO TV" width={40} height={40} className="object-contain" />
            <div>
              <h1 className="text-xl font-bold text-white">EVO TV</h1>
              <p className="text-xs text-gray-400">Admin Dashboard</p>
            </div>
          </div>
        </div>

        <nav className="p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = activePage === item.id
            return (
              <button
                key={item.id}
                onClick={() => {
                  onPageChange(item.id)
                  setIsOpen(false)
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  isActive
                    ? "bg-[#2CD7E3]/20 text-[#2CD7E3] border border-[#2CD7E3]/50"
                    : "text-gray-400 hover:bg-[#1a1a1a] hover:text-white"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            )
          })}
        </nav>
      </aside>
    </>
  )
}
