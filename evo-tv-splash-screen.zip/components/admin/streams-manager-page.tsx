"use client"

import { useState } from "react"
import { Play, Square, Edit, Trash2, Shield, Plus } from "lucide-react"

interface Stream {
  id: string
  title: string
  game: string
  status: "live" | "scheduled" | "ended"
  viewers: number
  partnerOnly: boolean
  scheduledTime?: string
}

export function StreamsManagerPage() {
  const [streams, setStreams] = useState<Stream[]>([
    {
      id: "1",
      title: "CS2 Championship Finals",
      game: "Counter-Strike 2",
      status: "live",
      viewers: 12453,
      partnerOnly: true,
    },
    {
      id: "2",
      title: "Valorant Pro League",
      game: "Valorant",
      status: "live",
      viewers: 8234,
      partnerOnly: false,
    },
    {
      id: "3",
      title: "Dota 2 Tournament",
      game: "Dota 2",
      status: "scheduled",
      viewers: 0,
      partnerOnly: false,
      scheduledTime: "2025-10-27 18:00",
    },
  ])

  const [showCreateModal, setShowCreateModal] = useState(false)

  const togglePartnerOnly = (id: string) => {
    setStreams(streams.map((stream) => (stream.id === id ? { ...stream, partnerOnly: !stream.partnerOnly } : stream)))
  }

  const toggleStreamStatus = (id: string) => {
    setStreams(
      streams.map((stream) => {
        if (stream.id === id) {
          if (stream.status === "live") {
            return { ...stream, status: "ended" as const }
          } else if (stream.status === "scheduled") {
            return { ...stream, status: "live" as const, viewers: Math.floor(Math.random() * 10000) }
          }
        }
        return stream
      }),
    )
  }

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Streams Manager</h1>
          <p className="text-gray-400">Manage live and scheduled streams</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
        >
          <Plus className="w-5 h-5" />
          Create Stream
        </button>
      </div>

      {/* Streams Table */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#1a1a1a] border-b border-[#2CD7E3]/20">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Title</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Game</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Status</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Viewers</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Partner Only</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2CD7E3]/10">
              {streams.map((stream) => (
                <tr key={stream.id} className="hover:bg-[#1a1a1a]/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {stream.partnerOnly && <Shield className="w-4 h-4 text-[#2CD7E3]" />}
                      <span className="text-white font-medium">{stream.title}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-400">{stream.game}</td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        stream.status === "live"
                          ? "bg-[#00FF00]/20 text-[#00FF00]"
                          : stream.status === "scheduled"
                            ? "bg-[#2CD7E3]/20 text-[#2CD7E3]"
                            : "bg-gray-500/20 text-gray-400"
                      }`}
                    >
                      {stream.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-400">
                    {stream.viewers > 0 ? stream.viewers.toLocaleString() : "-"}
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => togglePartnerOnly(stream.id)}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                        stream.partnerOnly
                          ? "bg-[#2CD7E3]/20 text-[#2CD7E3] border border-[#2CD7E3]/50"
                          : "bg-[#1a1a1a] text-gray-400 border border-gray-600"
                      }`}
                    >
                      {stream.partnerOnly ? "Yes" : "No"}
                    </button>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {stream.status !== "ended" && (
                        <button
                          onClick={() => toggleStreamStatus(stream.id)}
                          className={`p-2 rounded-lg transition-all ${
                            stream.status === "live"
                              ? "bg-red-500/20 text-red-500 hover:bg-red-500/30"
                              : "bg-[#00FF00]/20 text-[#00FF00] hover:bg-[#00FF00]/30"
                          }`}
                          title={stream.status === "live" ? "Stop Stream" : "Start Stream"}
                        >
                          {stream.status === "live" ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        </button>
                      )}
                      <button
                        className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-red-500/20 hover:text-red-500 transition-all"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Stream Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0a0a0a] border border-[#2CD7E3]/30 rounded-lg p-6 max-w-md w-full">
            <h2 className="text-2xl font-bold text-white mb-4">Create New Stream</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Stream Title</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="Enter stream title"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Game</label>
                <select className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]">
                  <option>Counter-Strike 2</option>
                  <option>Valorant</option>
                  <option>Dota 2</option>
                  <option>League of Legends</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Schedule Time (Optional)</label>
                <input
                  type="datetime-local"
                  className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="partner-only" className="w-4 h-4 accent-[#2CD7E3]" />
                <label htmlFor="partner-only" className="text-sm text-gray-400">
                  Partner Only Stream
                </label>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 px-4 py-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2a2a2a] transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 px-4 py-2 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
              >
                Create Stream
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
