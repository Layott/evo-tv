"use client"

import { useState } from "react"
import { Shield, UserPlus, Edit, Trash2 } from "lucide-react"

interface User {
  id: string
  name: string
  email: string
  role: "Partner" | "Admin" | "Moderator" | "Analyst"
  joinDate: string
  status: "active" | "suspended"
}

export function UsersRolesPage() {
  const [users, setUsers] = useState<User[]>([
    {
      id: "1",
      name: "John Smith",
      email: "john@evotv.com",
      role: "Admin",
      joinDate: "2024-01-15",
      status: "active",
    },
    {
      id: "2",
      name: "Sarah Johnson",
      email: "sarah@partner.com",
      role: "Partner",
      joinDate: "2024-03-20",
      status: "active",
    },
    {
      id: "3",
      name: "Mike Chen",
      email: "mike@evotv.com",
      role: "Moderator",
      joinDate: "2024-05-10",
      status: "active",
    },
    {
      id: "4",
      name: "Emily Davis",
      email: "emily@evotv.com",
      role: "Analyst",
      joinDate: "2024-07-01",
      status: "active",
    },
  ])

  const [showAddUserModal, setShowAddUserModal] = useState(false)
  const [filterRole, setFilterRole] = useState<string>("all")

  const roleColors = {
    Partner: "#2CD7E3",
    Admin: "#FF6B6B",
    Moderator: "#16CFF3",
    Analyst: "#00FF00",
  }

  const filteredUsers = filterRole === "all" ? users : users.filter((u) => u.role === filterRole)

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Users & Roles</h1>
          <p className="text-gray-400">Manage user accounts and permissions</p>
        </div>
        <button
          onClick={() => setShowAddUserModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
        >
          <UserPlus className="w-5 h-5" />
          Add User
        </button>
      </div>

      {/* Role Filter */}
      <div className="flex items-center gap-3 flex-wrap">
        <button
          onClick={() => setFilterRole("all")}
          className={`px-4 py-2 rounded-lg transition-all ${
            filterRole === "all" ? "bg-[#2CD7E3] text-black" : "bg-[#1a1a1a] text-gray-400 hover:bg-[#2a2a2a]"
          }`}
        >
          All Users ({users.length})
        </button>
        {Object.keys(roleColors).map((role) => (
          <button
            key={role}
            onClick={() => setFilterRole(role)}
            className={`px-4 py-2 rounded-lg transition-all ${
              filterRole === role ? "bg-[#2CD7E3] text-black" : "bg-[#1a1a1a] text-gray-400 hover:bg-[#2a2a2a]"
            }`}
          >
            {role}s ({users.filter((u) => u.role === role).length})
          </button>
        ))}
      </div>

      {/* Users Table */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#1a1a1a] border-b border-[#2CD7E3]/20">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">User</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Email</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Role</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Join Date</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Status</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2CD7E3]/10">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-[#1a1a1a]/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#2CD7E3] to-[#16CFF3] flex items-center justify-center text-black font-bold">
                        {user.name.charAt(0)}
                      </div>
                      <span className="text-white font-medium">{user.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-400">{user.email}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4" style={{ color: roleColors[user.role] }} />
                      <span
                        className="px-3 py-1 rounded-full text-xs font-medium"
                        style={{
                          backgroundColor: `${roleColors[user.role]}20`,
                          color: roleColors[user.role],
                        }}
                      >
                        {user.role}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-400">{user.joinDate}</td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        user.status === "active" ? "bg-[#00FF00]/20 text-[#00FF00]" : "bg-red-500/20 text-red-500"
                      }`}
                    >
                      {user.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-red-500/20 hover:text-red-500 transition-all">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0a0a0a] border border-[#2CD7E3]/30 rounded-lg p-6 max-w-md w-full">
            <h2 className="text-2xl font-bold text-white mb-4">Add New User</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Full Name</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="Enter full name"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Email</label>
                <input
                  type="email"
                  className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="Enter email address"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Role</label>
                <select className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]">
                  <option>Partner</option>
                  <option>Admin</option>
                  <option>Moderator</option>
                  <option>Analyst</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowAddUserModal(false)}
                className="flex-1 px-4 py-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2a2a2a] transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowAddUserModal(false)}
                className="flex-1 px-4 py-2 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
              >
                Add User
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
