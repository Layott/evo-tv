"use client"

import { useState } from "react"
import { Plus, Play, Square, Download, Edit, Trash2 } from "lucide-react"

interface Poll {
  id: string
  question: string
  options: { text: string; votes: number }[]
  status: "active" | "closed" | "scheduled"
  totalVotes: number
  attachedTo?: string
}

export function PollsManagerPage() {
  const [polls, setPolls] = useState<Poll[]>([
    {
      id: "1",
      question: "Who will win the CS2 Finals?",
      options: [
        { text: "Team Alpha", votes: 1234 },
        { text: "Team Beta", votes: 987 },
        { text: "Team Gamma", votes: 456 },
      ],
      status: "active",
      totalVotes: 2677,
      attachedTo: "CS2 Championship Finals",
    },
    {
      id: "2",
      question: "Best play of the tournament?",
      options: [
        { text: "Ace by Player1", votes: 543 },
        { text: "Clutch by Player2", votes: 789 },
        { text: "1v5 by Player3", votes: 1234 },
      ],
      status: "closed",
      totalVotes: 2566,
    },
  ])

  const [showCreateModal, setShowCreateModal] = useState(false)

  const togglePollStatus = (id: string) => {
    setPolls(
      polls.map((poll) =>
        poll.id === id ? { ...poll, status: poll.status === "active" ? "closed" : "active" } : poll,
      ),
    )
  }

  const exportToCSV = (poll: Poll) => {
    const csv = [
      ["Option", "Votes", "Percentage"],
      ...poll.options.map((opt) => [
        opt.text,
        opt.votes.toString(),
        `${((opt.votes / poll.totalVotes) * 100).toFixed(1)}%`,
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `poll-${poll.id}-results.csv`
    a.click()
  }

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Polls Manager</h1>
          <p className="text-gray-400">Create and manage live polls</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
        >
          <Plus className="w-5 h-5" />
          Create Poll
        </button>
      </div>

      {/* Polls Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {polls.map((poll) => (
          <div key={poll.id} className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6 space-y-4">
            {/* Poll Header */}
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="text-lg font-bold text-white mb-1">{poll.question}</h3>
                {poll.attachedTo && <p className="text-sm text-gray-400">Attached to: {poll.attachedTo}</p>}
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  poll.status === "active" ? "bg-[#00FF00]/20 text-[#00FF00]" : "bg-gray-500/20 text-gray-400"
                }`}
              >
                {poll.status.toUpperCase()}
              </span>
            </div>

            {/* Poll Results */}
            <div className="space-y-3">
              {poll.options.map((option, index) => {
                const percentage = (option.votes / poll.totalVotes) * 100
                return (
                  <div key={index}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-white">{option.text}</span>
                      <span className="text-sm text-gray-400">
                        {option.votes} ({percentage.toFixed(1)}%)
                      </span>
                    </div>
                    <div className="h-2 bg-[#1a1a1a] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#2CD7E3] to-[#16CFF3] transition-all duration-500"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Total Votes */}
            <p className="text-sm text-gray-400">Total votes: {poll.totalVotes.toLocaleString()}</p>

            {/* Actions */}
            <div className="flex items-center gap-2 pt-4 border-t border-[#2CD7E3]/10">
              <button
                onClick={() => togglePollStatus(poll.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                  poll.status === "active"
                    ? "bg-red-500/20 text-red-500 hover:bg-red-500/30"
                    : "bg-[#00FF00]/20 text-[#00FF00] hover:bg-[#00FF00]/30"
                }`}
              >
                {poll.status === "active" ? (
                  <>
                    <Square className="w-4 h-4" />
                    Close
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    Reopen
                  </>
                )}
              </button>
              <button
                onClick={() => exportToCSV(poll)}
                className="flex items-center gap-2 px-4 py-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all"
              >
                <Download className="w-4 h-4" />
                Export CSV
              </button>
              <button className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all">
                <Edit className="w-4 h-4" />
              </button>
              <button className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-red-500/20 hover:text-red-500 transition-all">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Create Poll Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0a0a0a] border border-[#2CD7E3]/30 rounded-lg p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold text-white mb-4">Create New Poll</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Poll Question</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="Enter your question"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Options</label>
                <div className="space-y-2">
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                    placeholder="Option 1"
                  />
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                    placeholder="Option 2"
                  />
                  <input
                    type="text"
                    className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                    placeholder="Option 3"
                  />
                </div>
                <button className="mt-2 text-sm text-[#2CD7E3] hover:text-[#16CFF3]">+ Add Option</button>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Attach to Stream (Optional)</label>
                <select className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]">
                  <option value="">None</option>
                  <option>CS2 Championship Finals</option>
                  <option>Valorant Pro League</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 px-4 py-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2a2a2a] transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 px-4 py-2 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
              >
                Create Poll
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
