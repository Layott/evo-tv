"use client"

import { useState } from "react"
import { Download, TrendingUp, Users, Clock, BarChart3 } from "lucide-react"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts"

export function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("7d")

  const viewershipData = [
    { date: "Oct 20", viewers: 12000, streams: 8 },
    { date: "Oct 21", viewers: 15000, streams: 10 },
    { date: "Oct 22", viewers: 18000, streams: 12 },
    { date: "Oct 23", viewers: 22000, streams: 15 },
    { date: "Oct 24", viewers: 19000, streams: 11 },
    { date: "Oct 25", viewers: 25000, streams: 14 },
    { date: "Oct 26", viewers: 28000, streams: 16 },
  ]

  const watchTimeData = [
    { game: "CS2", hours: 45000 },
    { game: "Valorant", hours: 38000 },
    { game: "Dota 2", hours: 32000 },
    { game: "LoL", hours: 28000 },
    { game: "Rocket League", hours: 15000 },
  ]

  const pollEngagementData = [
    { date: "Oct 20", votes: 2500, polls: 5 },
    { date: "Oct 21", votes: 3200, polls: 6 },
    { date: "Oct 22", votes: 4100, polls: 8 },
    { date: "Oct 23", votes: 5500, polls: 10 },
    { date: "Oct 24", votes: 4800, polls: 7 },
    { date: "Oct 25", votes: 6200, polls: 9 },
    { date: "Oct 26", votes: 7100, polls: 11 },
  ]

  const exportToCSV = (data: any[], filename: string) => {
    const headers = Object.keys(data[0])
    const csv = [headers.join(","), ...data.map((row) => headers.map((header) => row[header]).join(","))].join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = filename
    a.click()
  }

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Analytics</h1>
          <p className="text-gray-400">Track performance and engagement metrics</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
          >
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <Users className="w-5 h-5 text-[#2CD7E3]" />
            <h3 className="text-sm text-gray-400">Avg Viewers</h3>
          </div>
          <p className="text-2xl font-bold text-white">19,857</p>
          <p className="text-xs text-[#00FF00] mt-1">+15.3% from last week</p>
        </div>
        <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <Clock className="w-5 h-5 text-[#16CFF3]" />
            <h3 className="text-sm text-gray-400">Watch Time</h3>
          </div>
          <p className="text-2xl font-bold text-white">158K hrs</p>
          <p className="text-xs text-[#00FF00] mt-1">+22.1% from last week</p>
        </div>
        <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <BarChart3 className="w-5 h-5 text-[#2CD7E3]" />
            <h3 className="text-sm text-gray-400">Poll Engagement</h3>
          </div>
          <p className="text-2xl font-bold text-white">68%</p>
          <p className="text-xs text-[#00FF00] mt-1">+5.2% from last week</p>
        </div>
        <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-5 h-5 text-[#00FF00]" />
            <h3 className="text-sm text-gray-400">Retention Rate</h3>
          </div>
          <p className="text-2xl font-bold text-white">72%</p>
          <p className="text-xs text-[#00FF00] mt-1">+3.8% from last week</p>
        </div>
      </div>

      {/* Viewership Chart */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white">Viewership Trends</h2>
          <button
            onClick={() => exportToCSV(viewershipData, "viewership-data.csv")}
            className="flex items-center gap-2 px-4 py-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={viewershipData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2CD7E3" opacity={0.1} />
            <XAxis dataKey="date" stroke="#999" />
            <YAxis stroke="#999" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#0a0a0a",
                border: "1px solid #2CD7E3",
                borderRadius: "8px",
              }}
            />
            <Legend />
            <Line type="monotone" dataKey="viewers" stroke="#2CD7E3" strokeWidth={2} name="Viewers" />
            <Line type="monotone" dataKey="streams" stroke="#16CFF3" strokeWidth={2} name="Active Streams" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Watch Time by Game */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white">Watch Time by Game</h2>
          <button
            onClick={() => exportToCSV(watchTimeData, "watch-time-data.csv")}
            className="flex items-center gap-2 px-4 py-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={watchTimeData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2CD7E3" opacity={0.1} />
            <XAxis dataKey="game" stroke="#999" />
            <YAxis stroke="#999" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#0a0a0a",
                border: "1px solid #2CD7E3",
                borderRadius: "8px",
              }}
            />
            <Bar dataKey="hours" fill="#2CD7E3" name="Watch Hours" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Poll Engagement */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white">Poll Engagement</h2>
          <button
            onClick={() => exportToCSV(pollEngagementData, "poll-engagement-data.csv")}
            className="flex items-center gap-2 px-4 py-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={pollEngagementData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2CD7E3" opacity={0.1} />
            <XAxis dataKey="date" stroke="#999" />
            <YAxis stroke="#999" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#0a0a0a",
                border: "1px solid #2CD7E3",
                borderRadius: "8px",
              }}
            />
            <Legend />
            <Line type="monotone" dataKey="votes" stroke="#00FF00" strokeWidth={2} name="Total Votes" />
            <Line type="monotone" dataKey="polls" stroke="#16CFF3" strokeWidth={2} name="Active Polls" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
