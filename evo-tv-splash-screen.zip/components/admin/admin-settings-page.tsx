"use client"

import { useState } from "react"
import { Key, Webhook, Shield, Copy, Eye, EyeOff } from "lucide-react"

export function AdminSettingsPage() {
  const [showApiKey, setShowApiKey] = useState(false)
  const [settings, setSettings] = useState({
    requireApproval: true,
    allowPublicPolls: false,
    enableAutoModeration: true,
    requireEmailVerification: true,
  })

  const apiKey = "evotv_sk_test_1234567890abcdef"
  const webhookUrl = "https://api.evotv.com/webhooks/events"

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Admin Settings</h1>
        <p className="text-gray-400">Configure platform settings and integrations</p>
      </div>

      {/* API Keys */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6 space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <Key className="w-5 h-5 text-[#2CD7E3]" />
          <h2 className="text-xl font-bold text-white">API Keys</h2>
        </div>
        <div>
          <label className="block text-sm text-gray-400 mb-2">Production API Key</label>
          <div className="flex items-center gap-2">
            <div className="flex-1 px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white font-mono text-sm">
              {showApiKey ? apiKey : "••••••••••••••••••••••••••••••"}
            </div>
            <button
              onClick={() => setShowApiKey(!showApiKey)}
              className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all"
            >
              {showApiKey ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
            <button
              onClick={() => copyToClipboard(apiKey)}
              className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all"
            >
              <Copy className="w-5 h-5" />
            </button>
          </div>
        </div>
        <button className="px-4 py-2 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium">
          Regenerate API Key
        </button>
      </div>

      {/* Webhooks */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6 space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <Webhook className="w-5 h-5 text-[#2CD7E3]" />
          <h2 className="text-xl font-bold text-white">Webhook Endpoints</h2>
        </div>
        <div>
          <label className="block text-sm text-gray-400 mb-2">Event Webhook URL</label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={webhookUrl}
              readOnly
              className="flex-1 px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
            />
            <button
              onClick={() => copyToClipboard(webhookUrl)}
              className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all"
            >
              <Copy className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="space-y-2">
          <p className="text-sm text-gray-400">Subscribed Events:</p>
          <div className="flex flex-wrap gap-2">
            {["stream.started", "stream.ended", "poll.created", "poll.closed", "vod.published"].map((event) => (
              <span key={event} className="px-3 py-1 bg-[#1a1a1a] text-gray-400 rounded-full text-xs font-mono">
                {event}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Role-Based Access Control */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6 space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-5 h-5 text-[#2CD7E3]" />
          <h2 className="text-xl font-bold text-white">Role-Based Access Control</h2>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-lg">
            <div>
              <p className="text-white font-medium">Require approval for new partners</p>
              <p className="text-sm text-gray-400">New partner accounts must be approved by admin</p>
            </div>
            <button
              onClick={() => toggleSetting("requireApproval")}
              className={`relative w-12 h-6 rounded-full transition-all ${
                settings.requireApproval ? "bg-[#2CD7E3]" : "bg-gray-600"
              }`}
            >
              <div
                className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings.requireApproval ? "translate-x-6" : ""
                }`}
              />
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-lg">
            <div>
              <p className="text-white font-medium">Allow public polls</p>
              <p className="text-sm text-gray-400">Non-admin users can create public polls</p>
            </div>
            <button
              onClick={() => toggleSetting("allowPublicPolls")}
              className={`relative w-12 h-6 rounded-full transition-all ${
                settings.allowPublicPolls ? "bg-[#2CD7E3]" : "bg-gray-600"
              }`}
            >
              <div
                className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings.allowPublicPolls ? "translate-x-6" : ""
                }`}
              />
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-lg">
            <div>
              <p className="text-white font-medium">Enable auto-moderation</p>
              <p className="text-sm text-gray-400">Automatically flag inappropriate content</p>
            </div>
            <button
              onClick={() => toggleSetting("enableAutoModeration")}
              className={`relative w-12 h-6 rounded-full transition-all ${
                settings.enableAutoModeration ? "bg-[#2CD7E3]" : "bg-gray-600"
              }`}
            >
              <div
                className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings.enableAutoModeration ? "translate-x-6" : ""
                }`}
              />
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-lg">
            <div>
              <p className="text-white font-medium">Require email verification</p>
              <p className="text-sm text-gray-400">Users must verify email before accessing content</p>
            </div>
            <button
              onClick={() => toggleSetting("requireEmailVerification")}
              className={`relative w-12 h-6 rounded-full transition-all ${
                settings.requireEmailVerification ? "bg-[#2CD7E3]" : "bg-gray-600"
              }`}
            >
              <div
                className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings.requireEmailVerification ? "translate-x-6" : ""
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <button className="px-6 py-3 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium">
          Save All Settings
        </button>
      </div>
    </div>
  )
}
