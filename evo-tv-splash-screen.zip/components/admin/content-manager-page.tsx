"use client"

import { useState } from "react"
import { Upload, Edit, Trash2, Eye, EyeOff, LinkIcon } from "lucide-react"

interface VOD {
  id: string
  title: string
  event: string
  duration: string
  uploadDate: string
  status: "published" | "draft" | "processing"
  views: number
  linkedTo?: string
}

export function ContentManagerPage() {
  const [vods, setVods] = useState<VOD[]>([
    {
      id: "101",
      title: "CS2 Finals - Grand Championship",
      event: "CS2 Championship",
      duration: "2:34:12",
      uploadDate: "2025-10-25",
      status: "published",
      views: 45234,
      linkedTo: "CS2 Championship Finals Event",
    },
    {
      id: "102",
      title: "Valorant Highlights - Week 3",
      event: "Valorant Pro League",
      duration: "0:45:23",
      uploadDate: "2025-10-24",
      status: "published",
      views: 12456,
    },
    {
      id: "103",
      title: "Dota 2 Tournament - Day 1",
      event: "Dota 2 International",
      duration: "3:12:45",
      uploadDate: "2025-10-26",
      status: "processing",
      views: 0,
    },
  ])

  const [showUploadModal, setShowUploadModal] = useState(false)

  const togglePublishStatus = (id: string) => {
    setVods(
      vods.map((vod) =>
        vod.id === id
          ? {
              ...vod,
              status: vod.status === "published" ? "draft" : "published",
            }
          : vod,
      ),
    )
  }

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Content Manager</h1>
          <p className="text-gray-400">Upload and manage VOD content</p>
        </div>
        <button
          onClick={() => setShowUploadModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
        >
          <Upload className="w-5 h-5" />
          Upload VOD
        </button>
      </div>

      {/* VODs Table */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#1a1a1a] border-b border-[#2CD7E3]/20">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Title</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Event</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Duration</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Upload Date</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Status</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Views</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2CD7E3]/10">
              {vods.map((vod) => (
                <tr key={vod.id} className="hover:bg-[#1a1a1a]/50 transition-colors">
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-white font-medium">{vod.title}</p>
                      {vod.linkedTo && (
                        <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                          <LinkIcon className="w-3 h-3" />
                          {vod.linkedTo}
                        </p>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-400">{vod.event}</td>
                  <td className="px-6 py-4 text-gray-400">{vod.duration}</td>
                  <td className="px-6 py-4 text-gray-400">{vod.uploadDate}</td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        vod.status === "published"
                          ? "bg-[#00FF00]/20 text-[#00FF00]"
                          : vod.status === "processing"
                            ? "bg-[#2CD7E3]/20 text-[#2CD7E3]"
                            : "bg-gray-500/20 text-gray-400"
                      }`}
                    >
                      {vod.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-400">{vod.views > 0 ? vod.views.toLocaleString() : "-"}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {vod.status !== "processing" && (
                        <button
                          onClick={() => togglePublishStatus(vod.id)}
                          className={`p-2 rounded-lg transition-all ${
                            vod.status === "published"
                              ? "bg-[#2CD7E3]/20 text-[#2CD7E3] hover:bg-[#2CD7E3]/30"
                              : "bg-[#1a1a1a] text-gray-400 hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3]"
                          }`}
                          title={vod.status === "published" ? "Unpublish" : "Publish"}
                        >
                          {vod.status === "published" ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                        </button>
                      )}
                      <button className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2CD7E3]/20 hover:text-[#2CD7E3] transition-all">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-red-500/20 hover:text-red-500 transition-all">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upload VOD Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0a0a0a] border border-[#2CD7E3]/30 rounded-lg p-6 max-w-md w-full">
            <h2 className="text-2xl font-bold text-white mb-4">Upload VOD</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Video File</label>
                <div className="border-2 border-dashed border-[#2CD7E3]/30 rounded-lg p-8 text-center hover:border-[#2CD7E3] transition-all cursor-pointer">
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-400">Click to upload or drag and drop</p>
                  <p className="text-xs text-gray-500 mt-1">MP4, MOV, AVI (max 5GB)</p>
                </div>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Title</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="Enter VOD title"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Event</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="Enter event name"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Link to Event/Stream (Optional)</label>
                <select className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]">
                  <option value="">None</option>
                  <option>CS2 Championship Finals Event</option>
                  <option>Valorant Pro League</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowUploadModal(false)}
                className="flex-1 px-4 py-2 bg-[#1a1a1a] text-gray-400 rounded-lg hover:bg-[#2a2a2a] transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowUploadModal(false)}
                className="flex-1 px-4 py-2 bg-[#2CD7E3] text-black rounded-lg hover:bg-[#16CFF3] transition-all font-medium"
              >
                Upload
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
