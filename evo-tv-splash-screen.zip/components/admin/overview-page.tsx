"use client"

import { TrendingUp, Users, DollarSign, Radio, Video, BarChart3 } from "lucide-react"

export function OverviewPage() {
  const kpis = [
    {
      label: "Active Streams",
      value: "12",
      change: "+3 from yesterday",
      icon: Radio,
      color: "#2CD7E3",
    },
    {
      label: "Active Viewers",
      value: "45,234",
      change: "+12.5% from last hour",
      icon: Users,
      color: "#16CFF3",
    },
    {
      label: "Revenue Today",
      value: "$8,432",
      change: "+18.2% from yesterday",
      icon: DollarSign,
      color: "#00FF00",
    },
    {
      label: "Total VODs",
      value: "1,247",
      change: "+23 this week",
      icon: Video,
      color: "#2CD7E3",
    },
    {
      label: "Active Polls",
      value: "8",
      change: "3 ending soon",
      icon: BarChart3,
      color: "#16CFF3",
    },
    {
      label: "Engagement Rate",
      value: "68%",
      change: "+5.3% from last week",
      icon: TrendingUp,
      color: "#00FF00",
    },
  ]

  const quickActions = [
    { label: "Start New Stream", action: "streams" },
    { label: "Create Poll", action: "polls" },
    { label: "Upload VOD", action: "content" },
    { label: "Create Ad Campaign", action: "ads" },
  ]

  const recentActivity = [
    { time: "2 min ago", event: 'Stream "CS2 Finals" started', user: "Admin" },
    { time: "15 min ago", event: 'Poll "Best Player" closed', user: "Moderator" },
    { time: "1 hour ago", event: 'VOD "Highlights Reel" published', user: "Content Manager" },
    { time: "2 hours ago", event: "New partner account approved", user: "Admin" },
    { time: "3 hours ago", event: 'Ad campaign "Summer Sale" activated', user: "Marketing" },
  ]

  return (
    <div className="p-6 lg:p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Dashboard Overview</h1>
        <p className="text-gray-400">Welcome back! Here's what's happening today.</p>
      </div>

      {/* KPIs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {kpis.map((kpi) => {
          const Icon = kpi.icon
          return (
            <div
              key={kpi.label}
              className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6 hover:border-[#2CD7E3]/50 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 rounded-lg" style={{ backgroundColor: `${kpi.color}20` }}>
                  <Icon className="w-6 h-6" style={{ color: kpi.color }} />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-white mb-1">{kpi.value}</h3>
              <p className="text-sm text-gray-400 mb-2">{kpi.label}</p>
              <p className="text-xs text-[#2CD7E3]">{kpi.change}</p>
            </div>
          )
        })}
      </div>

      {/* Quick Actions */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
        <h2 className="text-xl font-bold text-white mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action) => (
            <button
              key={action.label}
              className="px-6 py-4 bg-[#1a1a1a] border border-[#2CD7E3]/30 rounded-lg text-white hover:bg-[#2CD7E3]/10 hover:border-[#2CD7E3] transition-all"
            >
              {action.label}
            </button>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-[#0a0a0a] border border-[#2CD7E3]/20 rounded-lg p-6">
        <h2 className="text-xl font-bold text-white mb-4">Recent Activity</h2>
        <div className="space-y-4">
          {recentActivity.map((activity, index) => (
            <div key={index} className="flex items-start gap-4 pb-4 border-b border-[#2CD7E3]/10 last:border-0">
              <div className="w-2 h-2 rounded-full bg-[#2CD7E3] mt-2" />
              <div className="flex-1">
                <p className="text-white text-sm">{activity.event}</p>
                <p className="text-gray-400 text-xs mt-1">
                  {activity.time} • by {activity.user}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
