"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Settings,
  MessageSquare,
  ThumbsUp,
  Share2,
  BookmarkPlus,
  ChevronDown,
  ChevronUp,
  X,
  ShoppingBag,
  Minus,
  Plus,
  Trash2,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"

interface Chapter {
  time: number
  label: string
}

interface RelatedVideo {
  id: string
  title: string
  creator: string
  views: string
  duration: string
  thumbnail: string
}

interface VODPlayerProps {
  videoId: string
  title: string
  event: string
  duration: string
  uploadDate: string
  thumbnail: string
  chapters: Chapter[]
  relatedVideos: RelatedVideo[]
  initialProgress?: number
}

export default function VODPlayer({
  videoId,
  title,
  event,
  duration,
  uploadDate,
  thumbnail,
  chapters,
  relatedVideos,
  initialProgress = 0,
}: VODPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(initialProgress)
  const [showCaptions, setShowCaptions] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const [isSaved, setIsSaved] = useState(false)
  const [showChapters, setShowChapters] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [quality, setQuality] = useState("Auto")
  const [playbackSpeed, setPlaybackSpeed] = useState(1)
  const [audioLanguage, setAudioLanguage] = useState("English")
  const [subtitles, setSubtitles] = useState("Off")
  const [showShop, setShowShop] = useState(false)
  const [shopView, setShopView] = useState<"products" | "cart" | "checkout">("products")
  const [cart, setCart] = useState<Array<{ id: string; name: string; price: number; quantity: number; image: string }>>(
    [],
  )
  const [showToast, setShowToast] = useState(false)
  const [toastMessage, setToastMessage] = useState("")
  const videoRef = useRef<HTMLDivElement>(null)

  const merchProducts = [
    {
      id: "1",
      name: "Team Jersey",
      price: 79.99,
      image: "/team-alpha-logo.jpg",
      description: "Official team jersey",
    },
    {
      id: "2",
      name: "Championship Hoodie",
      price: 59.99,
      image: "/esports-championship-finals-live-stream.jpg",
      description: "Limited edition hoodie",
    },
    {
      id: "3",
      name: "Team Cap",
      price: 29.99,
      image: "/team-beta-logo.jpg",
      description: "Adjustable team cap",
    },
    {
      id: "4",
      name: "Event Poster",
      price: 19.99,
      image: "/esports-tournament-logo.png",
      description: "Signed event poster",
    },
  ]

  const showNotification = (message: string) => {
    setToastMessage(message)
    setShowToast(true)
    setTimeout(() => setShowToast(false), 3000)
  }

  const addToCart = (product: (typeof merchProducts)[0]) => {
    const existingItem = cart.find((item) => item.id === product.id)
    if (existingItem) {
      setCart(cart.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)))
      showNotification(`Added another ${product.name} to cart`)
    } else {
      setCart([...cart, { ...product, quantity: 1 }])
      showNotification(`${product.name} added to cart`)
    }
  }

  const updateQuantity = (id: string, change: number) => {
    setCart(
      cart
        .map((item) => (item.id === id ? { ...item, quantity: Math.max(0, item.quantity + change) } : item))
        .filter((item) => item.quantity > 0),
    )
  }

  const removeFromCart = (id: string) => {
    setCart(cart.filter((item) => item.id !== id))
    showNotification("Item removed from cart")
  }

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  const handleCheckout = () => {
    showNotification("Order placed successfully!")
    setCart([])
    setShowShop(false)
    setShopView("products")
  }

  // Parse duration to seconds
  const parseDuration = (dur: string) => {
    const parts = dur.split(":").map(Number)
    if (parts.length === 2) return parts[0] * 60 + parts[1]
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2]
    return 0
  }

  const totalSeconds = parseDuration(duration)

  // Auto-play simulation
  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= totalSeconds) {
            setIsPlaying(false)
            return totalSeconds
          }
          return prev + 1
        })
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isPlaying, totalSeconds])

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600)
    const mins = Math.floor((seconds % 3600) / 60)
    const secs = Math.floor(seconds % 60)
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
    }
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = Number(e.target.value)
    setCurrentTime(newTime)
  }

  const handleChapterClick = (time: number) => {
    setCurrentTime(time)
    setIsPlaying(true)
  }

  const progressPercentage = (currentTime / totalSeconds) * 100

  return (
    <div className="flex flex-col min-h-screen" style={{ backgroundColor: "#000000" }}>
      {showToast && (
        <div
          className="fixed top-4 right-4 z-[100] px-4 py-3 rounded-lg shadow-lg animate-in slide-in-from-top"
          style={{
            backgroundColor: "#1a1a1a",
            border: "1px solid #2CD7E3",
          }}
        >
          <p className="text-sm text-white">{toastMessage}</p>
        </div>
      )}

      {/* Video Player */}
      <div className="relative w-full aspect-video bg-black" ref={videoRef}>
        {/* Mock Video Display */}
        <div className="absolute inset-0">
          <Image src={thumbnail || "/placeholder.svg"} alt={title} fill className="object-cover" />
          {/* Dark overlay when paused */}
          {!isPlaying && (
            <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
              <button
                onClick={() => setIsPlaying(true)}
                className="w-16 h-16 rounded-full flex items-center justify-center transition-all hover:scale-110"
                style={{ backgroundColor: "#2CD7E3" }}
              >
                <Play size={32} fill="black" color="black" className="ml-1" />
              </button>
            </div>
          )}
        </div>

        <button
          onClick={() => setShowShop(!showShop)}
          className="absolute top-4 right-4 z-20 w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110"
          style={{
            backgroundColor: "rgba(0, 0, 0, 0.8)",
            border: "2px solid #2CD7E3",
            boxShadow: "0 0 20px rgba(44, 215, 227, 0.5)",
          }}
        >
          <ShoppingBag size={20} color="#2CD7E3" />
          {cartItemCount > 0 && (
            <div
              className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold"
              style={{ backgroundColor: "#00FF00", color: "#000" }}
            >
              {cartItemCount}
            </div>
          )}
        </button>

        {showShop && (
          <div
            className="absolute top-16 right-4 z-30 w-80 max-h-[70vh] rounded-lg overflow-hidden shadow-2xl"
            style={{
              backgroundColor: "rgba(0, 0, 0, 0.95)",
              border: "1px solid #2CD7E3",
              backdropFilter: "blur(10px)",
            }}
          >
            {/* Shop Header */}
            <div
              className="flex items-center justify-between p-4 border-b"
              style={{ borderColor: "rgba(44, 215, 227, 0.3)" }}
            >
              <h3 className="text-lg font-bold text-white">
                {shopView === "products" && "Merch Shop"}
                {shopView === "cart" && `Cart (${cartItemCount})`}
                {shopView === "checkout" && "Checkout"}
              </h3>
              <button onClick={() => setShowShop(false)} className="text-white hover:text-[#2CD7E3] transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Shop Content */}
            <div className="overflow-y-auto max-h-[calc(70vh-120px)]">
              {/* Products View */}
              {shopView === "products" && (
                <div className="p-4 space-y-3">
                  {merchProducts.map((product) => (
                    <div
                      key={product.id}
                      className="rounded-lg overflow-hidden"
                      style={{
                        border: "1px solid rgba(44, 215, 227, 0.3)",
                        backgroundColor: "rgba(26, 26, 26, 0.8)",
                      }}
                    >
                      <div className="relative h-32 w-full">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="p-3">
                        <h4 className="text-sm font-semibold text-white mb-1">{product.name}</h4>
                        <p className="text-xs text-gray-400 mb-2">{product.description}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-lg font-bold" style={{ color: "#2CD7E3" }}>
                            ${product.price}
                          </span>
                          <button
                            onClick={() => addToCart(product)}
                            className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all hover:opacity-90"
                            style={{ backgroundColor: "#2CD7E3", color: "#000" }}
                          >
                            Add to Cart
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Cart View */}
              {shopView === "cart" && (
                <div className="p-4">
                  {cart.length === 0 ? (
                    <div className="text-center py-8">
                      <ShoppingBag size={48} color="#666" className="mx-auto mb-3" />
                      <p className="text-gray-400 text-sm">Your cart is empty</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {cart.map((item) => (
                        <div
                          key={item.id}
                          className="flex gap-3 p-3 rounded-lg"
                          style={{
                            border: "1px solid rgba(44, 215, 227, 0.3)",
                            backgroundColor: "rgba(26, 26, 26, 0.8)",
                          }}
                        >
                          <div className="relative w-16 h-16 flex-shrink-0 rounded overflow-hidden">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <h4 className="text-sm font-semibold text-white mb-1">{item.name}</h4>
                            <p className="text-xs mb-2" style={{ color: "#2CD7E3" }}>
                              ${item.price}
                            </p>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => updateQuantity(item.id, -1)}
                                className="w-6 h-6 rounded flex items-center justify-center"
                                style={{ backgroundColor: "rgba(44, 215, 227, 0.2)" }}
                              >
                                <Minus size={12} color="#2CD7E3" />
                              </button>
                              <span className="text-sm text-white w-6 text-center">{item.quantity}</span>
                              <button
                                onClick={() => updateQuantity(item.id, 1)}
                                className="w-6 h-6 rounded flex items-center justify-center"
                                style={{ backgroundColor: "rgba(44, 215, 227, 0.2)" }}
                              >
                                <Plus size={12} color="#2CD7E3" />
                              </button>
                              <button
                                onClick={() => removeFromCart(item.id)}
                                className="ml-auto text-red-500 hover:text-red-400"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Checkout View */}
              {shopView === "checkout" && (
                <div className="p-4 space-y-4">
                  <div>
                    <label className="text-xs text-gray-400 mb-1 block">Email</label>
                    <input
                      type="email"
                      placeholder="your@email.com"
                      className="w-full px-3 py-2 rounded-lg text-sm text-white"
                      style={{
                        backgroundColor: "rgba(26, 26, 26, 0.8)",
                        border: "1px solid rgba(44, 215, 227, 0.3)",
                      }}
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 mb-1 block">Card Number</label>
                    <input
                      type="text"
                      placeholder="1234 5678 9012 3456"
                      className="w-full px-3 py-2 rounded-lg text-sm text-white"
                      style={{
                        backgroundColor: "rgba(26, 26, 26, 0.8)",
                        border: "1px solid rgba(44, 215, 227, 0.3)",
                      }}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Expiry</label>
                      <input
                        type="text"
                        placeholder="MM/YY"
                        className="w-full px-3 py-2 rounded-lg text-sm text-white"
                        style={{
                          backgroundColor: "rgba(26, 26, 26, 0.8)",
                          border: "1px solid rgba(44, 215, 227, 0.3)",
                        }}
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">CVV</label>
                      <input
                        type="text"
                        placeholder="123"
                        className="w-full px-3 py-2 rounded-lg text-sm text-white"
                        style={{
                          backgroundColor: "rgba(26, 26, 26, 0.8)",
                          border: "1px solid rgba(44, 215, 227, 0.3)",
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 mb-1 block">Shipping Address</label>
                    <textarea
                      placeholder="123 Main St, City, State, ZIP"
                      rows={3}
                      className="w-full px-3 py-2 rounded-lg text-sm text-white resize-none"
                      style={{
                        backgroundColor: "rgba(26, 26, 26, 0.8)",
                        border: "1px solid rgba(44, 215, 227, 0.3)",
                      }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Shop Footer */}
            <div className="p-4 border-t" style={{ borderColor: "rgba(44, 215, 227, 0.3)" }}>
              {shopView === "products" && cart.length > 0 && (
                <button
                  onClick={() => setShopView("cart")}
                  className="w-full py-2.5 rounded-lg font-semibold transition-all hover:opacity-90 flex items-center justify-between px-4"
                  style={{ backgroundColor: "#2CD7E3", color: "#000" }}
                >
                  <span>View Cart ({cartItemCount})</span>
                  <span>${cartTotal.toFixed(2)}</span>
                </button>
              )}
              {shopView === "cart" && cart.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-white mb-2">
                    <span className="text-sm">Total:</span>
                    <span className="text-lg font-bold" style={{ color: "#2CD7E3" }}>
                      ${cartTotal.toFixed(2)}
                    </span>
                  </div>
                  <button
                    onClick={() => setShopView("products")}
                    className="w-full py-2 rounded-lg text-sm font-semibold transition-all"
                    style={{
                      backgroundColor: "rgba(44, 215, 227, 0.1)",
                      border: "1px solid #2CD7E3",
                      color: "#2CD7E3",
                    }}
                  >
                    Continue Shopping
                  </button>
                  <button
                    onClick={() => setShopView("checkout")}
                    className="w-full py-2.5 rounded-lg font-semibold transition-all hover:opacity-90"
                    style={{ backgroundColor: "#2CD7E3", color: "#000" }}
                  >
                    Proceed to Checkout
                  </button>
                </div>
              )}
              {shopView === "checkout" && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-white mb-2">
                    <span className="text-sm">Total:</span>
                    <span className="text-lg font-bold" style={{ color: "#2CD7E3" }}>
                      ${cartTotal.toFixed(2)}
                    </span>
                  </div>
                  <button
                    onClick={() => setShopView("cart")}
                    className="w-full py-2 rounded-lg text-sm font-semibold transition-all"
                    style={{
                      backgroundColor: "rgba(44, 215, 227, 0.1)",
                      border: "1px solid #2CD7E3",
                      color: "#2CD7E3",
                    }}
                  >
                    Back to Cart
                  </button>
                  <button
                    onClick={handleCheckout}
                    className="w-full py-2.5 rounded-lg font-semibold transition-all hover:opacity-90"
                    style={{ backgroundColor: "#2CD7E3", color: "#000" }}
                  >
                    Place Order
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Continue Watching Progress Bar */}
        {initialProgress > 0 && currentTime === initialProgress && (
          <div className="absolute top-4 left-4 right-4 bg-black bg-opacity-70 rounded-lg p-3">
            <p className="text-xs text-white mb-2">Continue watching from {formatTime(initialProgress)}</p>
            <div className="w-full h-1 bg-gray-700 rounded-full overflow-hidden">
              <div
                className="h-full transition-all"
                style={{
                  width: `${(initialProgress / totalSeconds) * 100}%`,
                  backgroundColor: "#2CD7E3",
                }}
              />
            </div>
          </div>
        )}

        {/* Video Controls Overlay */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/80 to-transparent p-4">
          {/* Progress Bar */}
          <div className="mb-3">
            <input
              type="range"
              min="0"
              max={totalSeconds}
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-1 rounded-full appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #2CD7E3 0%, #2CD7E3 ${progressPercentage}%, #333 ${progressPercentage}%, #333 100%)`,
              }}
            />
            {/* Chapter markers */}
            <div className="relative w-full h-2 -mt-1">
              {chapters.map((chapter, idx) => {
                const markerPosition = (chapter.time / totalSeconds) * 100
                return (
                  <div
                    key={idx}
                    className="absolute w-1 h-2 bg-white rounded-full cursor-pointer hover:scale-150 transition-transform"
                    style={{ left: `${markerPosition}%` }}
                    onClick={() => handleChapterClick(chapter.time)}
                    title={chapter.label}
                  />
                )
              })}
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="text-white hover:text-[#2CD7E3] transition-colors"
              >
                {isPlaying ? <Pause size={24} /> : <Play size={24} />}
              </button>
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="text-white hover:text-[#2CD7E3] transition-colors"
              >
                {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
              </button>
              <span className="text-xs text-white">
                {formatTime(currentTime)} / {duration}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowCaptions(!showCaptions)}
                className={`transition-colors ${showCaptions ? "text-[#2CD7E3]" : "text-white hover:text-[#2CD7E3]"}`}
              >
                <MessageSquare size={20} />
              </button>
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="text-white hover:text-[#2CD7E3] transition-colors"
              >
                <Settings size={20} />
              </button>
              <button className="text-white hover:text-[#2CD7E3] transition-colors">
                <Maximize size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Video Info Section */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4">
          {/* Title and Event */}
          <h1 className="text-xl font-bold text-white mb-1">{title}</h1>
          <p className="text-sm mb-2" style={{ color: "#2CD7E3" }}>
            {event}
          </p>
          <div className="flex items-center gap-4 text-xs mb-4" style={{ color: "#999999" }}>
            <span>{duration}</span>
            <span>•</span>
            <span>Uploaded {uploadDate}</span>
            <span>•</span>
            <span>{quality}</span>
            <span>•</span>
            <span>{playbackSpeed}x</span>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3 mb-6">
            <button
              onClick={() => setIsLiked(!isLiked)}
              className="flex items-center gap-2 px-4 py-2 rounded-full transition-all"
              style={{
                border: `1px solid ${isLiked ? "#2CD7E3" : "rgba(44, 215, 227, 0.5)"}`,
                backgroundColor: isLiked ? "rgba(44, 215, 227, 0.1)" : "transparent",
                color: isLiked ? "#2CD7E3" : "white",
              }}
            >
              <ThumbsUp size={16} fill={isLiked ? "#2CD7E3" : "none"} />
              <span className="text-sm">Like</span>
            </button>

            <button
              className="flex items-center gap-2 px-4 py-2 rounded-full transition-all hover:bg-[rgba(44,215,227,0.1)]"
              style={{
                border: "1px solid rgba(44, 215, 227, 0.5)",
                color: "white",
              }}
            >
              <Share2 size={16} />
              <span className="text-sm">Share</span>
            </button>

            <button
              onClick={() => setIsSaved(!isSaved)}
              className="flex items-center gap-2 px-4 py-2 rounded-full transition-all"
              style={{
                border: `1px solid ${isSaved ? "#2CD7E3" : "rgba(44, 215, 227, 0.5)"}`,
                backgroundColor: isSaved ? "rgba(44, 215, 227, 0.1)" : "transparent",
                color: isSaved ? "#2CD7E3" : "white",
              }}
            >
              <BookmarkPlus size={16} fill={isSaved ? "#2CD7E3" : "none"} />
              <span className="text-sm">{isSaved ? "Saved" : "Save"}</span>
            </button>
          </div>

          {/* Chapters Section */}
          <div className="mb-6">
            <button
              onClick={() => setShowChapters(!showChapters)}
              className="flex items-center justify-between w-full py-3 px-4 rounded-lg transition-all"
              style={{
                border: "1px solid rgba(44, 215, 227, 0.3)",
                backgroundColor: "rgba(0, 0, 0, 0.3)",
              }}
            >
              <span className="text-sm font-semibold text-white">Chapters ({chapters.length})</span>
              {showChapters ? <ChevronUp size={20} color="#2CD7E3" /> : <ChevronDown size={20} color="#2CD7E3" />}
            </button>

            {showChapters && (
              <div className="mt-2 space-y-2">
                {chapters.map((chapter, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleChapterClick(chapter.time)}
                    className="w-full flex items-center justify-between p-3 rounded-lg transition-all hover:bg-[rgba(44,215,227,0.1)]"
                    style={{
                      border: "1px solid rgba(44, 215, 227, 0.2)",
                      backgroundColor: currentTime >= chapter.time ? "rgba(44, 215, 227, 0.05)" : "transparent",
                    }}
                  >
                    <span className="text-sm text-white">{chapter.label}</span>
                    <span className="text-xs" style={{ color: "#2CD7E3" }}>
                      {formatTime(chapter.time)}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Related Videos */}
          <div>
            <h2 className="text-lg font-bold text-white mb-4">Related Videos</h2>
            <div className="space-y-3">
              {relatedVideos.map((video) => (
                <Link
                  key={video.id}
                  href={`/vod/${video.id}`}
                  className="flex gap-3 rounded-lg overflow-hidden transition-all hover:opacity-80"
                  style={{
                    border: "1px solid rgba(44, 215, 227, 0.3)",
                    backgroundColor: "rgba(0, 0, 0, 0.3)",
                  }}
                >
                  {/* Thumbnail */}
                  <div className="relative w-32 h-20 flex-shrink-0">
                    <Image
                      src={video.thumbnail || "/placeholder.svg"}
                      alt={video.title}
                      fill
                      className="object-cover"
                    />
                    {/* Duration badge */}
                    <div className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded text-xs font-semibold bg-black bg-opacity-80 text-white">
                      {video.duration}
                    </div>
                  </div>

                  {/* Info */}
                  <div className="flex-1 p-2 flex flex-col justify-between">
                    <div>
                      <p className="text-sm font-semibold text-white line-clamp-2">{video.title}</p>
                      <p className="text-xs mt-1" style={{ color: "#666666" }}>
                        {video.creator}
                      </p>
                    </div>
                    <p className="text-xs" style={{ color: "#999999" }}>
                      {video.views} views
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
