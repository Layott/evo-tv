"use client"

import { useState, useEffect } from "react"
import { Search, ShoppingCart, X, ChevronDown, Star, Minus, Plus } from "lucide-react"
import { useRouter } from "next/navigation"
import Image from "next/image"

// Mock products data
const mockProducts = [
  {
    id: "1",
    name: "Team Alpha Jersey 2025",
    price: 15000,
    image: "/team-alpha-jersey.jpg",
    category: "Apparel",
    tag: "Limited",
    rating: 4.8,
    reviews: 234,
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Blue", "Black", "White"],
    stock: 5,
    sku: "TA-JER-2025",
    description:
      "Official Team Alpha 2025 Championship Jersey. Premium quality fabric with moisture-wicking technology.",
    shipping: "3-5 business days",
  },
  {
    id: "2",
    name: "EVO TV Gaming Hoodie",
    price: 12000,
    image: "/evo-hoodie.jpg",
    category: "Apparel",
    tag: "Popular",
    rating: 4.9,
    reviews: 567,
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "Cyan"],
    stock: 23,
    sku: "EVO-HOD-001",
    description: "Comfortable gaming hoodie with EVO TV branding. Perfect for long gaming sessions.",
    shipping: "3-5 business days",
  },
  {
    id: "3",
    name: "Championship Cap",
    price: 5000,
    image: "/championship-cap.jpg",
    category: "Accessories",
    tag: null,
    rating: 4.6,
    reviews: 189,
    sizes: ["One Size"],
    colors: ["Black", "Blue", "White"],
    stock: 45,
    sku: "CHAMP-CAP-001",
    description: "Adjustable championship cap with embroidered logo.",
    shipping: "2-3 business days",
  },
  {
    id: "4",
    name: "Premium Subscription - 1 Year",
    price: 25000,
    image: "/premium-sub.jpg",
    category: "Digital Items",
    tag: "Best Value",
    rating: 5.0,
    reviews: 1203,
    sizes: null,
    colors: null,
    stock: 999,
    sku: "PREM-SUB-12M",
    description: "Ad-free viewing, exclusive content, early access to events, and more.",
    shipping: "Instant digital delivery",
    isDigital: true,
  },
  {
    id: "5",
    name: "EVO TV Gift Card",
    price: 10000,
    image: "/gift-card.jpg",
    category: "Gift Cards",
    tag: null,
    rating: 4.9,
    reviews: 456,
    sizes: null,
    colors: null,
    stock: 999,
    sku: "GIFT-10K",
    description: "Digital gift card redeemable for merch, subscriptions, and more.",
    shipping: "Instant digital delivery",
    isDigital: true,
  },
  {
    id: "6",
    name: "Limited Edition Poster Set",
    price: 8000,
    image: "/poster-set.jpg",
    category: "Limited Drops",
    tag: "Limited",
    rating: 4.7,
    reviews: 89,
    sizes: null,
    colors: null,
    stock: 12,
    sku: "POST-LTD-001",
    description: "Set of 3 limited edition championship posters. Only 50 sets available.",
    shipping: "5-7 business days",
  },
]

export default function ShopPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState("All")
  const [sortBy, setSortBy] = useState("Popular")
  const [showSortDropdown, setShowSortDropdown] = useState(false)
  const [cart, setCart] = useState<any[]>([])
  const [showCart, setShowCart] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<any>(null)
  const [selectedSize, setSelectedSize] = useState<string>("")
  const [selectedColor, setSelectedColor] = useState<string>("")
  const [quantity, setQuantity] = useState(1)
  const [promoCode, setPromoCode] = useState("")
  const [discount, setDiscount] = useState(0)

  const categories = ["All", "Apparel", "Accessories", "Digital Items", "Gift Cards", "Limited Drops"]
  const sortOptions = ["Popular", "Newest", "Price: Low to High", "Price: High to Low"]

  // Load cart from localStorage
  useEffect(() => {
    const savedCart = localStorage.getItem("evotvCart")
    if (savedCart) {
      setCart(JSON.parse(savedCart))
    }
  }, [])

  // Save cart to localStorage
  useEffect(() => {
    localStorage.setItem("evotvCart", JSON.stringify(cart))
  }, [cart])

  // Filter and sort products
  const filteredProducts = mockProducts
    .filter((p) => activeCategory === "All" || p.category === activeCategory)
    .filter((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === "Price: Low to High") return a.price - b.price
      if (sortBy === "Price: High to Low") return b.price - a.price
      if (sortBy === "Newest") return b.id.localeCompare(a.id)
      return 0 // Popular (default order)
    })

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0)
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shipping = cart.some((item) => !item.isDigital) ? 2000 : 0
  const tax = Math.round(subtotal * 0.075)
  const total = subtotal - discount + shipping + tax

  const addToCart = (product: any, size?: string, color?: string, qty = 1) => {
    const cartItem = {
      ...product,
      selectedSize: size,
      selectedColor: color,
      quantity: qty,
      cartId: `${product.id}-${size}-${color}`,
    }

    const existingIndex = cart.findIndex((item) => item.cartId === cartItem.cartId)
    if (existingIndex >= 0) {
      const newCart = [...cart]
      newCart[existingIndex].quantity += qty
      setCart(newCart)
    } else {
      setCart([...cart, cartItem])
    }

    // Mock analytics
    console.log("[v0] Analytics: add-to-cart", { product: product.name, price: product.price })
  }

  const updateCartQuantity = (cartId: string, newQty: number) => {
    if (newQty <= 0) {
      setCart(cart.filter((item) => item.cartId !== cartId))
    } else {
      setCart(cart.map((item) => (item.cartId === cartId ? { ...item, quantity: newQty } : item)))
    }
  }

  const applyPromoCode = () => {
    if (promoCode.toUpperCase() === "EVOTV10") {
      setDiscount(Math.round(subtotal * 0.1))
    } else if (promoCode.toUpperCase() === "WELCOME20") {
      setDiscount(Math.round(subtotal * 0.2))
    } else {
      alert("Invalid promo code")
    }
  }

  const proceedToCheckout = () => {
    // Mock analytics
    console.log("[v0] Analytics: checkout-initiated", { total, itemCount: cartItemCount })
    router.push("/checkout")
  }

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Top Navbar */}
      <div className="sticky top-0 z-40 bg-black border-b border-[#2CD7E3]/20 px-4 py-3">
        <div className="flex items-center justify-between gap-3">
          <button onClick={() => router.push("/home")} className="flex-shrink-0">
            <Image src="/evotv colored.png" alt="EVO TV" width={80} height={30} className="h-8 w-auto" />
          </button>

          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#111] border border-gray-800 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-[#2CD7E3]"
            />
          </div>

          <button
            onClick={() => setShowCart(true)}
            className="relative flex-shrink-0 p-2 rounded-lg hover:bg-[#2CD7E3]/10 transition-colors"
          >
            <ShoppingCart size={24} className="text-[#2CD7E3]" />
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#00FF00] text-black text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {cartItemCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Category Filters */}
      <div className="px-4 py-4 overflow-x-auto scrollbar-hide">
        <div className="flex gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all ${
                activeCategory === cat
                  ? "bg-[#16CFF3] text-black"
                  : "bg-[#111] text-gray-400 border border-gray-800 hover:border-[#2CD7E3]"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Sort Dropdown */}
      <div className="px-4 pb-4 relative">
        <button
          onClick={() => setShowSortDropdown(!showSortDropdown)}
          className="flex items-center gap-2 px-4 py-2 bg-[#111] border border-gray-800 rounded-lg text-sm"
        >
          <span className="text-gray-400">Sort by:</span>
          <span className="text-white">{sortBy}</span>
          <ChevronDown size={16} className="text-gray-400" />
        </button>

        {showSortDropdown && (
          <div className="absolute top-full mt-2 left-4 right-4 bg-[#111] border border-[#2CD7E3] rounded-lg overflow-hidden z-30">
            {sortOptions.map((option) => (
              <button
                key={option}
                onClick={() => {
                  setSortBy(option)
                  setShowSortDropdown(false)
                }}
                className="w-full px-4 py-3 text-left text-sm hover:bg-[#2CD7E3]/10 transition-colors"
              >
                {option}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Product Grid */}
      <div className="px-4 grid grid-cols-2 gap-4">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            onClick={() => {
              setSelectedProduct(product)
              setSelectedSize(product.sizes?.[0] || "")
              setSelectedColor(product.colors?.[0] || "")
              setQuantity(1)
            }}
            className="bg-[#111] rounded-lg overflow-hidden border border-gray-800 hover:border-[#2CD7E3] transition-all cursor-pointer"
          >
            <div className="relative aspect-square bg-gray-900">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 50vw, 33vw"
              />
              {product.tag && (
                <span className="absolute top-2 right-2 bg-[#16CFF3] text-black text-xs font-bold px-2 py-1 rounded">
                  {product.tag}
                </span>
              )}
              {product.stock < 10 && product.stock > 0 && (
                <span className="absolute bottom-2 left-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
                  Only {product.stock} left!
                </span>
              )}
            </div>
            <div className="p-3">
              <h3 className="font-semibold text-sm mb-1 line-clamp-2">{product.name}</h3>
              <div className="flex items-center gap-1 mb-2">
                <Star size={12} className="fill-[#00FF00] text-[#00FF00]" />
                <span className="text-xs text-gray-400">
                  {product.rating} ({product.reviews})
                </span>
              </div>
              <p className="text-[#2CD7E3] font-bold text-lg">₦{product.price.toLocaleString()}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black/90 z-50 overflow-y-auto">
          <div className="min-h-screen px-4 py-6">
            <div className="max-w-2xl mx-auto bg-[#111] rounded-lg overflow-hidden">
              <div className="sticky top-0 bg-[#111] border-b border-gray-800 px-4 py-3 flex items-center justify-between z-10">
                <h2 className="font-bold text-lg">Product Details</h2>
                <button onClick={() => setSelectedProduct(null)} className="p-2 hover:bg-gray-800 rounded-lg">
                  <X size={24} />
                </button>
              </div>

              <div className="p-4">
                <div className="relative aspect-square bg-gray-900 rounded-lg overflow-hidden mb-4">
                  <Image
                    src={selectedProduct.image || "/placeholder.svg"}
                    alt={selectedProduct.name}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                </div>

                <h3 className="text-2xl font-bold mb-2">{selectedProduct.name}</h3>
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center gap-1">
                    <Star size={16} className="fill-[#00FF00] text-[#00FF00]" />
                    <span className="text-sm">
                      {selectedProduct.rating} ({selectedProduct.reviews} reviews)
                    </span>
                  </div>
                  <span className="text-gray-600">•</span>
                  <span className="text-sm text-gray-400">SKU: {selectedProduct.sku}</span>
                </div>

                <p className="text-[#2CD7E3] text-3xl font-bold mb-4">₦{selectedProduct.price.toLocaleString()}</p>

                <p className="text-gray-300 mb-6">{selectedProduct.description}</p>

                {selectedProduct.sizes && (
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-sm font-semibold">Size</label>
                      <button className="text-xs text-[#2CD7E3]">Size Guide</button>
                    </div>
                    <div className="flex gap-2">
                      {selectedProduct.sizes.map((size: string) => (
                        <button
                          key={size}
                          onClick={() => setSelectedSize(size)}
                          className={`px-4 py-2 rounded-lg border transition-all ${
                            selectedSize === size
                              ? "border-[#2CD7E3] bg-[#2CD7E3]/10 text-[#2CD7E3]"
                              : "border-gray-700 hover:border-gray-600"
                          }`}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {selectedProduct.colors && (
                  <div className="mb-4">
                    <label className="text-sm font-semibold mb-2 block">Color</label>
                    <div className="flex gap-2">
                      {selectedProduct.colors.map((color: string) => (
                        <button
                          key={color}
                          onClick={() => setSelectedColor(color)}
                          className={`px-4 py-2 rounded-lg border transition-all ${
                            selectedColor === color
                              ? "border-[#2CD7E3] bg-[#2CD7E3]/10 text-[#2CD7E3]"
                              : "border-gray-700 hover:border-gray-600"
                          }`}
                        >
                          {color}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="mb-4">
                  <label className="text-sm font-semibold mb-2 block">Quantity</label>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-2 bg-gray-800 rounded-lg hover:bg-gray-700"
                    >
                      <Minus size={20} />
                    </button>
                    <span className="text-xl font-bold w-12 text-center">{quantity}</span>
                    <button
                      onClick={() => setQuantity(Math.min(selectedProduct.stock, quantity + 1))}
                      className="p-2 bg-gray-800 rounded-lg hover:bg-gray-700"
                    >
                      <Plus size={20} />
                    </button>
                    <span className="text-sm text-gray-400">({selectedProduct.stock} available)</span>
                  </div>
                </div>

                <div className="mb-6 p-3 bg-gray-900 rounded-lg">
                  <p className="text-sm text-gray-400">
                    <span className="font-semibold text-white">Shipping:</span> {selectedProduct.shipping}
                  </p>
                  {selectedProduct.isDigital && (
                    <p className="text-xs text-[#00FF00] mt-1">✓ Instant digital delivery after purchase</p>
                  )}
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      addToCart(selectedProduct, selectedSize, selectedColor, quantity)
                      setSelectedProduct(null)
                    }}
                    className="flex-1 bg-[#2CD7E3] text-black font-bold py-3 rounded-lg hover:bg-[#16CFF3] transition-colors"
                  >
                    Add to Cart
                  </button>
                  <button
                    onClick={() => {
                      addToCart(selectedProduct, selectedSize, selectedColor, quantity)
                      setSelectedProduct(null)
                      setShowCart(true)
                    }}
                    className="flex-1 bg-[#16CFF3] text-black font-bold py-3 rounded-lg hover:bg-[#2CD7E3] transition-colors"
                  >
                    Buy Now
                  </button>
                </div>

                <div className="mt-4 text-center">
                  <button className="text-sm text-[#2CD7E3]">Returns Policy</button>
                  <span className="text-gray-600 mx-2">•</span>
                  <button className="text-sm text-[#2CD7E3]">Back in Stock Alert</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cart Drawer */}
      {showCart && (
        <div className="fixed inset-0 bg-black/80 z-50" onClick={() => setShowCart(false)}>
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-[#111] border-l border-[#2CD7E3] overflow-y-auto"
          >
            <div className="sticky top-0 bg-[#111] border-b border-gray-800 px-4 py-4 flex items-center justify-between z-10">
              <h2 className="text-xl font-bold">Shopping Cart ({cartItemCount})</h2>
              <button onClick={() => setShowCart(false)} className="p-2 hover:bg-gray-800 rounded-lg">
                <X size={24} />
              </button>
            </div>

            {cart.length === 0 ? (
              <div className="p-8 text-center">
                <ShoppingCart size={64} className="mx-auto mb-4 text-gray-600" />
                <p className="text-gray-400 mb-4">Your cart is empty</p>
                <button
                  onClick={() => setShowCart(false)}
                  className="bg-[#2CD7E3] text-black px-6 py-2 rounded-lg font-semibold"
                >
                  Continue Shopping
                </button>
              </div>
            ) : (
              <>
                <div className="p-4 space-y-4">
                  {cart.map((item) => (
                    <div key={item.cartId} className="flex gap-3 bg-gray-900 p-3 rounded-lg">
                      <div className="relative w-20 h-20 flex-shrink-0 bg-gray-800 rounded-lg overflow-hidden">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          fill
                          className="object-cover"
                          sizes="80px"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-sm mb-1 line-clamp-2">{item.name}</h4>
                        {item.selectedSize && (
                          <p className="text-xs text-gray-400">
                            Size: {item.selectedSize} • Color: {item.selectedColor}
                          </p>
                        )}
                        <p className="text-[#2CD7E3] font-bold mt-1">₦{item.price.toLocaleString()}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <button
                            onClick={() => updateCartQuantity(item.cartId, item.quantity - 1)}
                            className="p-1 bg-gray-800 rounded hover:bg-gray-700"
                          >
                            <Minus size={14} />
                          </button>
                          <span className="text-sm font-semibold w-8 text-center">{item.quantity}</span>
                          <button
                            onClick={() => updateCartQuantity(item.cartId, item.quantity + 1)}
                            className="p-1 bg-gray-800 rounded hover:bg-gray-700"
                          >
                            <Plus size={14} />
                          </button>
                          <button
                            onClick={() => updateCartQuantity(item.cartId, 0)}
                            className="ml-auto text-xs text-red-500 hover:text-red-400"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-4 border-t border-gray-800">
                  <div className="flex gap-2 mb-4">
                    <input
                      type="text"
                      placeholder="Promo code"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#2CD7E3]"
                    />
                    <button
                      onClick={applyPromoCode}
                      className="bg-[#2CD7E3] text-black px-4 py-2 rounded-lg font-semibold text-sm"
                    >
                      Apply
                    </button>
                  </div>

                  <div className="space-y-2 text-sm mb-4">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Subtotal</span>
                      <span>₦{subtotal.toLocaleString()}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-[#00FF00]">
                        <span>Discount</span>
                        <span>-₦{discount.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-400">Shipping</span>
                      <span>{shipping === 0 ? "Free" : `₦${shipping.toLocaleString()}`}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Tax (7.5%)</span>
                      <span>₦{tax.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold pt-2 border-t border-gray-700">
                      <span>Total</span>
                      <span className="text-[#2CD7E3]">₦{total.toLocaleString()}</span>
                    </div>
                  </div>

                  <button
                    onClick={proceedToCheckout}
                    className="w-full bg-[#16CFF3] text-black font-bold py-3 rounded-lg hover:bg-[#2CD7E3] transition-colors"
                  >
                    Proceed to Checkout
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
