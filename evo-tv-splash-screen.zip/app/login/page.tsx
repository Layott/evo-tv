"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function LoginPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"login" | "signup">("login")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (activeTab === "signup") {
      router.push("/verify-email")
    } else {
      router.push("/home")
    }
  }

  const DiscordIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.211.375-.444.864-.607 1.25a18.27 18.27 0 0 0-5.487 0c-.163-.386-.395-.875-.607-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.873-1.295 1.226-1.994a.076.076 0 0 0-.042-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.294.075.075 0 0 1 .078-.01c3.928 1.793 8.18 1.793 12.062 0a.075.075 0 0 1 .079.009c.12.098.246.198.373.295a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.076.076 0 0 0-.041.107c.36.698.77 1.364 1.225 1.994a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.057c.5-4.761-.838-8.898-3.549-12.562a.06.06 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-.965-2.157-2.156 0-1.193.964-2.157 2.157-2.157 1.193 0 2.156.964 2.156 2.157 0 1.19-.963 2.156-2.156 2.156zm7.975 0c-1.183 0-2.157-.965-2.157-2.156 0-1.193.964-2.157 2.157-2.157 1.193 0 2.157.964 2.157 2.157 0 1.19-.964 2.156-2.157 2.156z" />
    </svg>
  )

  const GoogleIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
        fill="#4285F4"
      />
      <path
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
        fill="#34A853"
      />
      <path
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
        fill="#FBBC05"
      />
      <path
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
        fill="#EA4335"
      />
    </svg>
  )

  const AppleIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.05 13.5c-.91 2.92.37 5.65 2.85 6.75.56.3 1.11.56 1.66.75-.59 1.33-1.89 2.77-3.27 3.64-1.44 1.02-2.89 2.26-5.29 2.26-2.17 0-2.54-.63-4.09-.63-1.44 0-2.4.67-4.1.67-2.5 0-4.29-2.31-5.73-4.41-1.73-2.47-3.34-6.66-1.73-9.28 1.35-2.11 3.61-3.26 5.61-3.26 1.66 0 2.59.67 3.94.67 1.22 0 1.97-.67 3.21-.67 1.75 0 3.68.88 4.72 2.51M12 2C13.33 2 14.5 1 14.5 0S13.33-2 12-2s-2.5 1-2.5 2 1.17 2 2.5 2z" />
    </svg>
  )

  const FacebookIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
    </svg>
  )

  const SocialButton = ({ icon: Icon, label, color }: { icon: React.ReactNode; label: string; color: string }) => (
    <button
      className="w-full py-3 px-4 rounded-lg border-2 transition-all duration-200 flex items-center justify-center gap-2 hover:shadow-lg"
      style={{
        borderColor: "#2CD7E3",
        color: color,
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.boxShadow = `0 0 20px ${color}, inset 0 0 20px rgba(44, 215, 227, 0.1)`
        e.currentTarget.style.borderColor = "#16CFF3"
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.boxShadow = "none"
        e.currentTarget.style.borderColor = "#2CD7E3"
      }}
    >
      <span className="text-xl" style={{ color: color }}>
        {Icon}
      </span>
      <span className="text-sm font-medium">{label}</span>
    </button>
  )

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: "#000000" }}>
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2" style={{ color: "#2CD7E3" }}>
            EVO TV
          </h1>
          <p style={{ color: "#666666" }}>Stream your entertainment</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-4 mb-8 border-b" style={{ borderColor: "#2CD7E3" }}>
          <button
            onClick={() => setActiveTab("login")}
            className="flex-1 py-3 font-semibold transition-colors duration-200 relative"
            style={{
              color: activeTab === "login" ? "#2CD7E3" : "#666666",
            }}
          >
            Login
            {activeTab === "login" && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5" style={{ backgroundColor: "#16CFF3" }} />
            )}
          </button>
          <button
            onClick={() => setActiveTab("signup")}
            className="flex-1 py-3 font-semibold transition-colors duration-200 relative"
            style={{
              color: activeTab === "signup" ? "#2CD7E3" : "#666666",
            }}
          >
            Create Account
            {activeTab === "signup" && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5" style={{ backgroundColor: "#16CFF3" }} />
            )}
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 mb-6">
          {/* Email Field */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: "#2CD7E3" }}>
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-4 py-3 rounded-lg border-2 transition-all duration-200 focus:outline-none"
              style={{
                backgroundColor: "#0a0a0a",
                borderColor: "#2CD7E3",
                color: "#ffffff",
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "#16CFF3"
                e.currentTarget.style.boxShadow = "0 0 20px rgba(22, 207, 243, 0.3)"
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = "#2CD7E3"
                e.currentTarget.style.boxShadow = "none"
              }}
            />
          </div>

          {/* Password Field */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: "#2CD7E3" }}>
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-3 rounded-lg border-2 transition-all duration-200 focus:outline-none"
              style={{
                backgroundColor: "#0a0a0a",
                borderColor: "#2CD7E3",
                color: "#ffffff",
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "#16CFF3"
                e.currentTarget.style.boxShadow = "0 0 20px rgba(22, 207, 243, 0.3)"
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = "#2CD7E3"
                e.currentTarget.style.boxShadow = "none"
              }}
            />
          </div>

          {/* Confirm Password Field (Sign Up Only) */}
          {activeTab === "signup" && (
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: "#2CD7E3" }}>
                Confirm Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 rounded-lg border-2 transition-all duration-200 focus:outline-none"
                style={{
                  backgroundColor: "#0a0a0a",
                  borderColor: "#2CD7E3",
                  color: "#ffffff",
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = "#16CFF3"
                  e.currentTarget.style.boxShadow = "0 0 20px rgba(22, 207, 243, 0.3)"
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = "#2CD7E3"
                  e.currentTarget.style.boxShadow = "none"
                }}
              />
            </div>
          )}

          {/* Forgot Password Link (Login Only) */}
          {activeTab === "login" && (
            <div className="flex justify-end">
              <Link
                href="#"
                className="text-sm transition-colors duration-200 hover:underline"
                style={{ color: "#2CD7E3" }}
              >
                Forgot password?
              </Link>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-3 px-4 rounded-lg font-semibold transition-all duration-200 border-2 hover:shadow-lg"
            style={{
              backgroundColor: "#2CD7E3",
              color: "#000000",
              borderColor: "#2CD7E3",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "#16CFF3"
              e.currentTarget.style.borderColor = "#16CFF3"
              e.currentTarget.style.boxShadow = "0 0 30px rgba(22, 207, 243, 0.5)"
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "#2CD7E3"
              e.currentTarget.style.borderColor = "#2CD7E3"
              e.currentTarget.style.boxShadow = "none"
            }}
          >
            {activeTab === "login" ? "Sign In" : "Create Account"}
          </button>
        </form>

        {/* Divider */}
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 h-px" style={{ backgroundColor: "#2CD7E3" }} />
          <span style={{ color: "#666666" }}>or continue with</span>
          <div className="flex-1 h-px" style={{ backgroundColor: "#2CD7E3" }} />
        </div>

        {/* Social Login Buttons */}
        <div className="space-y-3">
          <SocialButton icon={<DiscordIcon />} label="Discord" color="#5865F2" />
          <SocialButton icon={<GoogleIcon />} label="Google" color="#EA4335" />
          <SocialButton icon={<AppleIcon />} label="Apple" color="#ffffff" />
          <SocialButton icon={<FacebookIcon />} label="Facebook" color="#1877F2" />
        </div>

        {/* Footer Text */}
        <p className="text-center text-sm mt-8" style={{ color: "#666666" }}>
          {activeTab === "login" ? "Don't have an account? " : "Already have an account? "}
          <button
            onClick={() => setActiveTab(activeTab === "login" ? "signup" : "login")}
            className="transition-colors duration-200 hover:underline"
            style={{ color: "#2CD7E3" }}
          >
            {activeTab === "login" ? "Sign up" : "Sign in"}
          </button>
        </p>
      </div>
    </div>
  )
}
