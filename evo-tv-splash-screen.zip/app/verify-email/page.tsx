"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

export default function VerifyEmailPage() {
  const router = useRouter()
  const [countdown, setCountdown] = useState(5)

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          router.push("/onboarding")
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [router])

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: "#000000" }}>
      <div className="w-full max-w-md text-center">
        {/* Email Icon */}
        <div className="mb-8 flex justify-center">
          <div
            className="w-20 h-20 rounded-full flex items-center justify-center animate-pulse"
            style={{ backgroundColor: "rgba(44, 215, 227, 0.1)", borderColor: "#2CD7E3", borderWidth: "2px" }}
          >
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#2CD7E3" strokeWidth="2">
              <rect x="2" y="4" width="20" height="16" rx="2" />
              <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
            </svg>
          </div>
        </div>

        {/* Heading */}
        <h1 className="text-3xl font-bold mb-4" style={{ color: "#2CD7E3" }}>
          Check Your Email
        </h1>

        {/* Description */}
        <p className="mb-6 text-lg" style={{ color: "#999999" }}>
          We've sent a verification link to your email address. Click the link to verify your account and get started.
        </p>

        {/* Verification Status */}
        <div
          className="p-6 rounded-lg mb-8 border-2"
          style={{ backgroundColor: "rgba(44, 215, 227, 0.05)", borderColor: "#2CD7E3" }}
        >
          <p className="text-sm mb-2" style={{ color: "#666666" }}>
            Didn't receive the email?
          </p>
          <button
            className="text-sm font-semibold transition-colors duration-200 hover:underline"
            style={{ color: "#16CFF3" }}
          >
            Resend verification link
          </button>
        </div>

        {/* Auto-redirect Message */}
        <div className="space-y-4">
          <p style={{ color: "#666666" }}>
            Redirecting to onboarding in <span style={{ color: "#2CD7E3", fontWeight: "bold" }}>{countdown}</span>{" "}
            seconds...
          </p>
          <button
            onClick={() => router.push("/onboarding")}
            className="w-full py-3 px-4 rounded-lg font-semibold transition-all duration-200 border-2"
            style={{
              backgroundColor: "#2CD7E3",
              color: "#000000",
              borderColor: "#2CD7E3",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "#16CFF3"
              e.currentTarget.style.borderColor = "#16CFF3"
              e.currentTarget.style.boxShadow = "0 0 30px rgba(22, 207, 243, 0.5)"
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "#2CD7E3"
              e.currentTarget.style.borderColor = "#2CD7E3"
              e.currentTarget.style.boxShadow = "none"
            }}
          >
            Continue to Onboarding
          </button>
        </div>

        {/* Footer */}
        <p className="text-sm mt-8" style={{ color: "#666666" }}>
          Having trouble? <span style={{ color: "#2CD7E3", cursor: "pointer" }}>Contact support</span>
        </p>
      </div>
    </div>
  )
}
