"use client"

import { useState } from "react"
import TopNavbar from "@/components/home/top-navbar"
import HeroCarousel from "@/components/home/hero-carousel"
import LiveNowSection from "@/components/home/live-now-section"
import UpcomingEventsSection from "@/components/home/upcoming-events-section"
import TrendingClipsSection from "@/components/home/trending-clips-section"
import AdBanner from "@/components/home/ad-banner"
import BottomNavigation from "@/components/home/bottom-navigation"

export default function HomePage() {
  const [activeTab, setActiveTab] = useState("home")

  return (
    <div className="flex flex-col min-h-screen" style={{ backgroundColor: "#000000" }}>
      {/* Top Navbar */}
      <TopNavbar />

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {/* Hero Carousel */}
        <HeroCarousel />

        {/* Live Now Section */}
        <LiveNowSection />

        {/* Ad Banner */}
        <AdBanner />

        {/* Upcoming Events Section */}
        <UpcomingEventsSection />

        {/* Trending Clips Section */}
        <TrendingClipsSection />
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  )
}
