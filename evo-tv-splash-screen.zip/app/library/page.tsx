"use client"

import { useState } from "react"
import { ArrowLeft, Trash2, Check, X } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import Image from "next/image"

// Mock data for library content
const mockWatchHistory = [
  {
    id: "1",
    title: "Insane 1v5 Clutch - Championship Finals",
    creator: "ProPlayer123",
    thumbnail: "/esports-highlight-clutch-play.jpg",
    duration: "12:34",
    progress: 65,
    lastWatched: "2 hours ago",
  },
  {
    id: "2",
    title: "Championship Winning Moment",
    creator: "EsportsDaily",
    thumbnail: "/esports-championship-winning-moment.jpg",
    duration: "8:45",
    progress: 100,
    lastWatched: "1 day ago",
  },
  {
    id: "3",
    title: "Best Plays of the Week - Episode 12",
    creator: "HighlightReel",
    thumbnail: "/esports-best-plays-highlights.jpg",
    duration: "15:20",
    progress: 45,
    lastWatched: "3 days ago",
  },
]

const mockSavedVideos = [
  {
    id: "4",
    title: "Pro Tips: Advanced Movement Techniques",
    creator: "CoachGaming",
    thumbnail: "/esports-pro-tips-tutorial.jpg",
    duration: "18:30",
    progress: 0,
    lastWatched: "Never",
  },
  {
    id: "5",
    title: "Tournament Recap: Spring Finals",
    creator: "EsportsNews",
    thumbnail: "/esports-tournament-recap.jpg",
    duration: "25:15",
    progress: 20,
    lastWatched: "1 week ago",
  },
]

const mockSubscriptions = [
  {
    id: "6",
    title: "Weekly Highlights - New Episode",
    creator: "HighlightReel",
    thumbnail: "/esports-weekly-highlights.jpg",
    duration: "14:22",
    progress: 0,
    lastWatched: "Never",
    uploadDate: "1 day ago",
  },
  {
    id: "7",
    title: "Live Tournament Analysis",
    creator: "ProAnalyst",
    thumbnail: "/esports-tournament-analysis.jpg",
    duration: "32:10",
    progress: 0,
    lastWatched: "Never",
    uploadDate: "3 days ago",
  },
]

export default function LibraryPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("history")
  const [watchHistory, setWatchHistory] = useState(mockWatchHistory)
  const [savedVideos, setSavedVideos] = useState(mockSavedVideos)
  const [subscriptions, setSubscriptions] = useState(mockSubscriptions)
  const [showToast, setShowToast] = useState(false)
  const [toastMessage, setToastMessage] = useState("")

  // Get continue watching videos (progress > 0 and < 100)
  const continueWatching = watchHistory.filter((video) => video.progress > 0 && video.progress < 100)

  const showToastMessage = (message: string) => {
    setToastMessage(message)
    setShowToast(true)
    setTimeout(() => setShowToast(false), 3000)
  }

  const handleClearHistory = () => {
    setWatchHistory([])
    showToastMessage("Watch history cleared")
  }

  const handleRemoveSaved = () => {
    setSavedVideos([])
    showToastMessage("All saved videos removed")
  }

  const handleMarkAllWatched = () => {
    setSubscriptions(subscriptions.map((video) => ({ ...video, progress: 100 })))
    showToastMessage("All videos marked as watched")
  }

  const renderVideoCard = (video: any) => (
    <Link
      key={video.id}
      href={`/vod/${video.id}`}
      className="flex gap-3 p-3 rounded-lg transition-all hover:bg-[rgba(44,215,227,0.1)]"
    >
      <div className="relative w-32 h-20 flex-shrink-0 rounded-lg overflow-hidden">
        <Image src={video.thumbnail || "/placeholder.svg"} alt={video.title} fill className="object-cover" />
        <div
          className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded text-xs font-semibold"
          style={{ backgroundColor: "rgba(0, 0, 0, 0.8)", color: "white" }}
        >
          {video.duration}
        </div>
        {/* Progress bar */}
        {video.progress > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1" style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}>
            <div
              className="h-full transition-all"
              style={{ backgroundColor: "#2CD7E3", width: `${video.progress}%` }}
            />
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="text-white font-semibold text-sm line-clamp-2 mb-1">{video.title}</h3>
        <p className="text-gray-400 text-xs mb-1">{video.creator}</p>
        <p className="text-gray-500 text-xs">
          {video.lastWatched !== "Never" ? `Watched ${video.lastWatched}` : "Not watched yet"}
        </p>
        {video.uploadDate && <p className="text-gray-500 text-xs">Uploaded {video.uploadDate}</p>}
      </div>
    </Link>
  )

  const renderEmptyState = (message: string, description: string) => (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      <div
        className="w-20 h-20 rounded-full flex items-center justify-center mb-4"
        style={{ backgroundColor: "rgba(44, 215, 227, 0.1)" }}
      >
        <X size={40} color="#666666" />
      </div>
      <h3 className="text-white text-lg font-semibold mb-2">{message}</h3>
      <p className="text-gray-400 text-sm max-w-xs">{description}</p>
    </div>
  )

  return (
    <div className="min-h-screen pb-20" style={{ backgroundColor: "#000000" }}>
      {/* Header */}
      <div
        className="sticky top-0 z-10 flex items-center justify-between px-4 py-4 border-b"
        style={{ backgroundColor: "#000000", borderColor: "rgba(44, 215, 227, 0.2)" }}
      >
        <button onClick={() => router.back()} className="p-2">
          <ArrowLeft size={24} color="white" />
        </button>
        <h1 className="text-white text-xl font-bold">Library</h1>
        <div className="w-10" />
      </div>

      {/* Continue Watching Section */}
      {continueWatching.length > 0 && (
        <div className="px-4 py-4 border-b" style={{ borderColor: "rgba(44, 215, 227, 0.2)" }}>
          <h2 className="text-white text-lg font-bold mb-3">Continue Watching</h2>
          <div className="space-y-2">{continueWatching.map(renderVideoCard)}</div>
        </div>
      )}

      {/* Tabs */}
      <div
        className="flex items-center gap-1 px-4 py-3 border-b overflow-x-auto"
        style={{ borderColor: "rgba(44, 215, 227, 0.2)" }}
      >
        {[
          { id: "history", label: "Watch History" },
          { id: "saved", label: "Saved Videos" },
          { id: "subscriptions", label: "Subscriptions" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className="px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all"
            style={{
              backgroundColor: activeTab === tab.id ? "rgba(44, 215, 227, 0.2)" : "transparent",
              color: activeTab === tab.id ? "#2CD7E3" : "#666666",
              border: activeTab === tab.id ? "1px solid #2CD7E3" : "1px solid transparent",
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Bulk Actions */}
      <div className="px-4 py-3 flex items-center justify-between">
        <p className="text-gray-400 text-sm">
          {activeTab === "history" && `${watchHistory.length} videos`}
          {activeTab === "saved" && `${savedVideos.length} videos`}
          {activeTab === "subscriptions" && `${subscriptions.length} videos`}
        </p>
        <button
          onClick={() => {
            if (activeTab === "history") handleClearHistory()
            if (activeTab === "saved") handleRemoveSaved()
            if (activeTab === "subscriptions") handleMarkAllWatched()
          }}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-semibold transition-all"
          style={{
            color: "#2CD7E3",
            border: "1px solid #2CD7E3",
            backgroundColor: "rgba(44, 215, 227, 0.1)",
          }}
        >
          {activeTab === "history" && (
            <>
              <Trash2 size={16} />
              Clear History
            </>
          )}
          {activeTab === "saved" && (
            <>
              <Trash2 size={16} />
              Remove All
            </>
          )}
          {activeTab === "subscriptions" && (
            <>
              <Check size={16} />
              Mark All Watched
            </>
          )}
        </button>
      </div>

      {/* Content */}
      <div className="px-4">
        {activeTab === "history" && (
          <>
            {watchHistory.length > 0 ? (
              <div className="space-y-2">{watchHistory.map(renderVideoCard)}</div>
            ) : (
              renderEmptyState(
                "No watch history yet",
                "Videos you watch will appear here so you can easily find them later.",
              )
            )}
          </>
        )}

        {activeTab === "saved" && (
          <>
            {savedVideos.length > 0 ? (
              <div className="space-y-2">{savedVideos.map(renderVideoCard)}</div>
            ) : (
              renderEmptyState(
                "No saved videos",
                "Save videos you want to watch later by tapping the bookmark icon on any video.",
              )
            )}
          </>
        )}

        {activeTab === "subscriptions" && (
          <>
            {subscriptions.length > 0 ? (
              <div className="space-y-2">{subscriptions.map(renderVideoCard)}</div>
            ) : (
              renderEmptyState(
                "No subscription videos",
                "Follow teams and streamers to see their latest videos here. Start exploring in the Discover tab!",
              )
            )}
          </>
        )}
      </div>

      {/* Toast Notification */}
      {showToast && (
        <div
          className="fixed bottom-24 left-1/2 transform -translate-x-1/2 px-6 py-3 rounded-full shadow-lg animate-in fade-in slide-in-from-bottom-4"
          style={{
            backgroundColor: "rgba(44, 215, 227, 0.95)",
            color: "#000000",
          }}
        >
          <p className="font-semibold text-sm">{toastMessage}</p>
        </div>
      )}
    </div>
  )
}
