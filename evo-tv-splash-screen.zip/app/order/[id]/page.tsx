"use client"

import { Check, Download, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default async function OrderConfirmationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="px-4 py-6 max-w-2xl mx-auto">
        <Link href="/shop" className="inline-flex items-center gap-2 text-[#2CD7E3] mb-6 hover:underline">
          <ArrowLeft size={20} />
          Back to Shop
        </Link>

        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-[#00FF00] rounded-full flex items-center justify-center mx-auto mb-4">
            <Check size={48} className="text-black" />
          </div>
          <h1 className="text-3xl font-bold mb-2">Order Confirmed!</h1>
          <p className="text-gray-400">Thank you for your purchase</p>
        </div>

        <div className="bg-[#111] rounded-lg p-6 mb-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-sm text-gray-400 mb-1">Order Number</p>
              <p className="text-xl font-bold text-[#2CD7E3]">{id}</p>
            </div>
            <button className="flex items-center gap-2 text-sm text-[#2CD7E3] hover:underline">
              <Download size={16} />
              Receipt
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-800">
            <div>
              <p className="text-sm text-gray-400 mb-1">Estimated Delivery</p>
              <p className="font-semibold">3-5 Business Days</p>
            </div>
            <div>
              <p className="text-sm text-gray-400 mb-1">Order Date</p>
              <p className="font-semibold">{new Date().toLocaleDateString()}</p>
            </div>
          </div>
        </div>

        <div className="bg-[#111] rounded-lg p-6 mb-6">
          <h3 className="font-semibold mb-4">What's Next?</h3>
          <ul className="space-y-3 text-sm text-gray-300">
            <li className="flex items-start gap-3">
              <Check size={20} className="text-[#00FF00] flex-shrink-0 mt-0.5" />
              <span>You'll receive an email confirmation shortly</span>
            </li>
            <li className="flex items-start gap-3">
              <Check size={20} className="text-[#00FF00] flex-shrink-0 mt-0.5" />
              <span>Track your order status in your profile</span>
            </li>
            <li className="flex items-start gap-3">
              <Check size={20} className="text-[#00FF00] flex-shrink-0 mt-0.5" />
              <span>Digital items are available immediately in your library</span>
            </li>
          </ul>
        </div>

        <div className="flex gap-3">
          <Link
            href="/profile"
            onClick={() => {
              // Set active tab to shop and orders when navigating
              if (typeof window !== "undefined") {
                localStorage.setItem("evo-tv-profile-tab", "shop")
                localStorage.setItem("evo-tv-shop-subtab", "orders")
              }
            }}
            className="flex-1 bg-[#2CD7E3] text-black font-bold py-3 rounded-lg hover:bg-[#16CFF3] transition-colors text-center"
          >
            View Order
          </Link>
          <Link
            href="/shop"
            className="flex-1 bg-gray-800 text-white font-bold py-3 rounded-lg hover:bg-gray-700 transition-colors text-center"
          >
            Continue Shopping
          </Link>
        </div>
      </div>
    </div>
  )
}
