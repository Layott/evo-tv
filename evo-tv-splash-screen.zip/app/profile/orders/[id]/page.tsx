"use client"

import { ArrowLeft, Download, MessageCircle, Package, Check, MapPin, CreditCard } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default async function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  // Mock order data
  const order = {
    id: id,
    date: "2025-02-20",
    status: "Delivered",
    total: 45000,
    subtotal: 45000,
    shipping: 0,
    tax: 3375,
    items: [
      { name: "Team Alpha Jersey", image: "/team-alpha-jersey.jpg", quantity: 1, price: 35000 },
      { name: "EVO Hoodie", image: "/evo-hoodie.jpg", quantity: 1, price: 10000 },
    ],
    tracking: "TRK-9876543210",
    shippingAddress: "John Doe\n123 Main Street\nLagos, Nigeria\n+234 800 000 0000",
    paymentMethod: "Visa •••• 4242",
    timeline: [
      { status: "Order Placed", date: "2025-02-20 10:30 AM", completed: true },
      { status: "Processing", date: "2025-02-20 11:00 AM", completed: true },
      { status: "Shipped", date: "2025-02-21 09:00 AM", completed: true },
      { status: "Delivered", date: "2025-02-23 02:30 PM", completed: true },
    ],
  }

  const canReturn = order.status === "Delivered"
  const returnWindowDays = 14

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black border-b border-[#2CD7E3]/20 px-4 py-4">
        <div className="flex items-center gap-4">
          <Link href="/profile" className="p-2 hover:bg-gray-800 rounded-lg">
            <ArrowLeft size={24} />
          </Link>
          <div>
            <h1 className="text-xl font-bold">Order Details</h1>
            <p className="text-sm text-gray-400">#{order.id}</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4 max-w-2xl mx-auto">
        {/* Order Status */}
        <div className="bg-[#111] rounded-lg p-6 border border-[#2CD7E3]/20">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-[#2CD7E3]">{order.status}</h2>
              <p className="text-sm text-gray-400 mt-1">Order placed on {order.date}</p>
            </div>
            {order.tracking && (
              <div className="text-right">
                <p className="text-xs text-gray-400">Tracking ID</p>
                <p className="text-sm font-mono text-[#2CD7E3]">{order.tracking}</p>
              </div>
            )}
          </div>

          {/* Timeline */}
          <div className="space-y-3">
            {order.timeline.map((event, index) => (
              <div key={index} className="flex items-start gap-3">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    event.completed ? "bg-[#00FF00]" : "bg-gray-700"
                  }`}
                >
                  {event.completed ? (
                    <Check size={16} className="text-black" />
                  ) : (
                    <div className="w-2 h-2 bg-gray-400 rounded-full" />
                  )}
                </div>
                <div className="flex-1">
                  <p className={`font-semibold ${event.completed ? "text-white" : "text-gray-400"}`}>{event.status}</p>
                  <p className="text-xs text-gray-500">{event.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Shipping Address */}
        <div className="bg-[#111] rounded-lg p-4 border border-gray-800">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <MapPin size={20} className="text-[#2CD7E3]" />
            Shipping Address
          </h3>
          <p className="text-sm text-gray-300 whitespace-pre-line">{order.shippingAddress}</p>
        </div>

        {/* Order Items */}
        <div className="bg-[#111] rounded-lg p-4 border border-gray-800">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <Package size={20} className="text-[#2CD7E3]" />
            Order Items
          </h3>
          <div className="space-y-3">
            {order.items.map((item, index) => (
              <div key={index} className="flex gap-3 pb-3 border-b border-gray-800 last:border-0 last:pb-0">
                <div className="relative w-20 h-20 bg-gray-800 rounded-lg overflow-hidden flex-shrink-0">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    fill
                    className="object-cover"
                    sizes="80px"
                  />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold">{item.name}</h4>
                  <p className="text-sm text-gray-400">Qty: {item.quantity}</p>
                  <p className="text-[#2CD7E3] font-bold mt-1">₦{item.price.toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order Summary */}
        <div className="bg-[#111] rounded-lg p-4 border border-gray-800">
          <h3 className="font-semibold mb-3">Order Summary</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Subtotal</span>
              <span>₦{order.subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Shipping</span>
              <span>{order.shipping === 0 ? "Free" : `₦${order.shipping.toLocaleString()}`}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Tax (7.5%)</span>
              <span>₦{order.tax.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-lg font-bold pt-2 border-t border-gray-700">
              <span>Total</span>
              <span className="text-[#2CD7E3]">₦{order.total.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Payment Method */}
        <div className="bg-[#111] rounded-lg p-4 border border-gray-800">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <CreditCard size={20} className="text-[#2CD7E3]" />
            Payment Method
          </h3>
          <p className="text-sm text-gray-300">{order.paymentMethod}</p>
        </div>

        {/* Actions */}
        <div className="space-y-3">
          <button
            onClick={() => {
              console.log("[v0] Analytics: receipt-downloaded", { orderId: order.id })
              alert("Receipt download started")
            }}
            className="w-full py-3 bg-[#2CD7E3] text-black font-bold rounded-lg hover:bg-[#16CFF3] transition-all flex items-center justify-center gap-2"
          >
            <Download size={20} />
            Download Receipt
          </button>

          {canReturn && (
            <button
              onClick={() => {
                console.log("[v0] Analytics: return-initiated", { orderId: order.id })
                alert(`Return request initiated. You have ${returnWindowDays} days from delivery to return items.`)
              }}
              className="w-full py-3 border border-[#2CD7E3]/50 text-[#2CD7E3] font-bold rounded-lg hover:bg-[#2CD7E3]/10 transition-all"
            >
              Request Return
            </button>
          )}

          <Link
            href={`/support?orderId=${order.id}`}
            onClick={() => console.log("[v0] Analytics: support-contacted", { orderId: order.id })}
            className="w-full py-3 border border-gray-700 text-white font-bold rounded-lg hover:bg-gray-800 transition-all flex items-center justify-center gap-2"
          >
            <MessageCircle size={20} />
            Contact Support
          </Link>
        </div>

        {/* Policies */}
        <div className="bg-[#111] rounded-lg p-4 border border-[#2CD7E3]/20 text-sm text-gray-400">
          <p className="mb-2">
            <strong className="text-white">Return Policy:</strong> Items can be returned within {returnWindowDays} days
            of delivery for a full refund.
          </p>
          <p className="mb-2">
            <strong className="text-white">Delivery:</strong> Standard delivery takes 3-5 business days. Express
            delivery available at checkout.
          </p>
          <p>
            <strong className="text-white">Support:</strong> Contact us at support@evotv.com for any questions or
            concerns.
          </p>
        </div>
      </div>
    </div>
  )
}
