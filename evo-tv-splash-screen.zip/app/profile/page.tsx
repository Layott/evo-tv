"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Edit,
  Mail,
  CreditCard,
  Bell,
  Play,
  ShieldAlert,
  Info,
  LogOut,
  ChevronRight,
  Check,
  Tv,
  ShoppingBag,
  Package,
  Heart,
  Search,
  Filter,
  Trash2,
  Plus,
  Wallet,
} from "lucide-react"
import BottomNavigation from "@/components/home/bottom-navigation"
import Image from "next/image"
import Link from "next/link"

// Mock user data
const mockUser = {
  avatar: "/diverse-user-avatars.png",
  handle: "@esports_fan_2024",
  bio: "Competitive gaming enthusiast | CS2 & Valorant player | Live stream addict",
  email: "user@example.com",
}

// Mock subscription data
const mockSubscription = {
  plan: "Premium",
  renewalDate: "March 15, 2025",
  price: "$9.99/month",
  receipts: [
    { date: "Feb 15, 2025", amount: "$9.99", status: "Paid" },
    { date: "Jan 15, 2025", amount: "$9.99", status: "Paid" },
    { date: "Dec 15, 2024", amount: "$9.99", status: "Paid" },
  ],
}

export default function ProfilePage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("profile")
  const [shopSubTab, setShopSubTab] = useState("orders")
  const [showToast, setShowToast] = useState(false)
  const [toastMessage, setToastMessage] = useState("")
  const [showEditModal, setShowEditModal] = useState(false)
  const [showOAuthModal, setShowOAuthModal] = useState(false)
  const [selectedOAuth, setSelectedOAuth] = useState("")
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false)
  const [show2FAModal, setShow2FAModal] = useState(false)
  const [showBlockedUsersModal, setShowBlockedUsersModal] = useState(false)
  const [showAddPaymentModal, setShowAddPaymentModal] = useState(false)
  const [orderSearchQuery, setOrderSearchQuery] = useState("")
  const [orderStatusFilter, setOrderStatusFilter] = useState("all")
  const [showFilterModal, setShowFilterModal] = useState(false)

  // Settings state with localStorage persistence
  const [settings, setSettings] = useState({
    // Account
    oauthProviders: {
      discord: false,
      google: true,
      apple: false,
      facebook: false,
    },
    // Notifications
    notificationsEnabled: true,
    liveNotifications: true,
    pollNotifications: true,
    eventReminders: true,
    emailDigests: false,
    // Playback
    autoPlayNext: true,
    videoQuality: "Auto",
    captionsDefault: false,
    // Ads
    adPersonalization: true,
    // Privacy
    twoFactorEnabled: false,
  })

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem("evo-tv-settings")
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
  }, [])

  // Save settings to localStorage whenever they change
  const updateSettings = (newSettings: typeof settings) => {
    setSettings(newSettings)
    localStorage.setItem("evo-tv-settings", JSON.stringify(newSettings))
  }

  const showToastMessage = (message: string) => {
    setToastMessage(message)
    setShowToast(true)
    setTimeout(() => setShowToast(false), 3000)
  }

  const handleToggle = (category: string, key: string) => {
    const newSettings = { ...settings, [key]: !settings[key as keyof typeof settings] }
    updateSettings(newSettings)
    showToastMessage(`${category} ${newSettings[key as keyof typeof settings] ? "enabled" : "disabled"}`)
  }

  const handleOAuthToggle = (provider: string) => {
    const newSettings = {
      ...settings,
      oauthProviders: {
        ...settings.oauthProviders,
        [provider]: !settings.oauthProviders[provider as keyof typeof settings.oauthProviders],
      },
    }
    updateSettings(newSettings)
    const action = newSettings.oauthProviders[provider as keyof typeof settings.oauthProviders]
      ? "connected"
      : "disconnected"
    showToastMessage(`${provider.charAt(0).toUpperCase() + provider.slice(1)} ${action}`)
    setShowOAuthModal(false)
  }

  const handleQualityChange = (quality: string) => {
    const newSettings = { ...settings, videoQuality: quality }
    updateSettings(newSettings)
    showToastMessage(`Video quality set to ${quality}`)
  }

  const handleLogout = () => {
    localStorage.clear()
    showToastMessage("Logged out successfully")
    setTimeout(() => router.push("/login"), 1500)
  }

  // Mock orders data
  const [orders, setOrders] = useState([
    {
      id: "EVO-1234567890",
      date: "2025-02-20",
      status: "Delivered",
      total: 45000,
      items: [
        { name: "Team Alpha Jersey", image: "/team-alpha-jersey.jpg", quantity: 1, price: 35000 },
        { name: "EVO Hoodie", image: "/evo-hoodie.jpg", quantity: 1, price: 10000 },
      ],
      tracking: "TRK-9876543210",
      shippingAddress: "123 Main Street, Lagos, Nigeria",
      paymentMethod: "•••• 4242",
      timeline: [
        { status: "Order Placed", date: "2025-02-20 10:30 AM", completed: true },
        { status: "Processing", date: "2025-02-20 11:00 AM", completed: true },
        { status: "Shipped", date: "2025-02-21 09:00 AM", completed: true },
        { status: "Delivered", date: "2025-02-23 02:30 PM", completed: true },
      ],
    },
    {
      id: "EVO-1234567891",
      date: "2025-02-18",
      status: "Shipped",
      total: 15000,
      items: [{ name: "Championship Cap", image: "/championship-cap.jpg", quantity: 1, price: 15000 }],
      tracking: "TRK-9876543211",
      shippingAddress: "123 Main Street, Lagos, Nigeria",
      paymentMethod: "•••• 4242",
      timeline: [
        { status: "Order Placed", date: "2025-02-18 03:15 PM", completed: true },
        { status: "Processing", date: "2025-02-18 04:00 PM", completed: true },
        { status: "Shipped", date: "2025-02-19 10:00 AM", completed: true },
        { status: "Out for Delivery", date: "Expected: 2025-02-24", completed: false },
      ],
    },
    {
      id: "EVO-1234567892",
      date: "2025-02-15",
      status: "Processing",
      total: 25000,
      items: [{ name: "Premium Subscription (1 Year)", image: "/premium-sub.jpg", quantity: 1, price: 25000 }],
      tracking: null,
      shippingAddress: "Digital Item - No shipping required",
      paymentMethod: "•••• 4242",
      timeline: [
        { status: "Order Placed", date: "2025-02-15 08:00 AM", completed: true },
        { status: "Processing", date: "In Progress", completed: false },
      ],
    },
  ])

  const [savedItems, setSavedItems] = useState([
    {
      id: "1",
      name: "Team Beta Jersey",
      price: 35000,
      image: "/team-alpha-jersey.jpg",
      inStock: true,
      stockCount: 12,
    },
    {
      id: "2",
      name: "Limited Edition Poster Set",
      price: 8000,
      image: "/poster-set.jpg",
      inStock: true,
      stockCount: 3,
    },
    {
      id: "3",
      name: "EVO Gaming Mouse",
      price: 18000,
      image: "/gaming-mouse.png",
      inStock: false,
      stockCount: 0,
    },
  ])

  const [paymentMethods, setPaymentMethods] = useState([
    { id: "1", type: "card", last4: "4242", brand: "Visa", expiry: "12/26", isDefault: true },
    { id: "2", type: "card", last4: "8888", brand: "Mastercard", expiry: "08/27", isDefault: false },
    { id: "3", type: "wallet", name: "PayPal", email: "user@example.com", isDefault: false },
  ])

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
      order.items.some((item) => item.name.toLowerCase().includes(orderSearchQuery.toLowerCase()))
    const matchesStatus = orderStatusFilter === "all" || order.status.toLowerCase() === orderStatusFilter.toLowerCase()
    return matchesSearch && matchesStatus
  })

  const handleRemoveSavedItem = (id: string) => {
    setSavedItems(savedItems.filter((item) => item.id !== id))
    showToastMessage("Item removed from saved items")
    console.log("[v0] Analytics: saved-item-removed", { itemId: id })
  }

  const handleMoveToCart = (item: any) => {
    const cart = JSON.parse(localStorage.getItem("evotvCart") || "[]")
    cart.push({ ...item, cartId: Date.now(), quantity: 1 })
    localStorage.setItem("evotvCart", JSON.stringify(cart))
    showToastMessage("Item added to cart")
    console.log("[v0] Analytics: saved-item-moved-to-cart", { itemId: item.id })
  }

  const handleDeletePaymentMethod = (id: string) => {
    setPaymentMethods(paymentMethods.filter((method) => method.id !== id))
    showToastMessage("Payment method removed")
  }

  const handleSetDefaultPayment = (id: string) => {
    setPaymentMethods(
      paymentMethods.map((method) => ({
        ...method,
        isDefault: method.id === id,
      })),
    )
    showToastMessage("Default payment method updated")
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "delivered":
        return "bg-[#00FF00]/20 text-[#00FF00]"
      case "shipped":
        return "bg-[#2CD7E3]/20 text-[#2CD7E3]"
      case "processing":
        return "bg-yellow-500/20 text-yellow-500"
      case "cancelled":
        return "bg-red-500/20 text-red-500"
      default:
        return "bg-gray-500/20 text-gray-500"
    }
  }

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-[#2CD7E3]/20">
        <button onClick={() => router.push("/home")} className="p-2">
          <ArrowLeft size={24} className="text-white" />
        </button>
        <h1 className="text-xl font-bold">Profile & Settings</h1>
        <div className="w-10" />
      </div>

      {/* Main tabs for Profile and Shop */}
      <div className="flex border-b border-[#2CD7E3]/20">
        <button
          onClick={() => setActiveTab("profile")}
          className={`flex-1 py-4 font-semibold transition-all ${
            activeTab === "profile" ? "text-[#2CD7E3] border-b-2 border-[#2CD7E3]" : "text-gray-400 hover:text-white"
          }`}
        >
          Profile
        </button>
        <button
          onClick={() => setActiveTab("shop")}
          className={`flex-1 py-4 font-semibold transition-all flex items-center justify-center gap-2 ${
            activeTab === "shop" ? "text-[#2CD7E3] border-b-2 border-[#2CD7E3]" : "text-gray-400 hover:text-white"
          }`}
        >
          <ShoppingBag size={20} />
          Shop
        </button>
      </div>

      {activeTab === "profile" && (
        <div className="p-4 space-y-6">
          {/* Profile Block */}
          <div className="bg-[#111111] rounded-lg p-6 border border-[#2CD7E3]/20">
            <div className="flex items-start gap-4">
              <div className="relative">
                <Image
                  src={mockUser.avatar || "/placeholder.svg"}
                  alt="Profile"
                  width={80}
                  height={80}
                  className="rounded-full border-2 border-[#2CD7E3]"
                />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold text-white">{mockUser.handle}</h2>
                <p className="text-sm text-gray-400 mt-1">{mockUser.bio}</p>
                <button
                  onClick={() => setShowEditModal(true)}
                  className="mt-3 px-4 py-2 rounded-lg border border-[#2CD7E3] text-[#2CD7E3] text-sm font-semibold hover:bg-[#2CD7E3]/10 transition-all flex items-center gap-2"
                >
                  <Edit size={16} />
                  Edit Profile
                </button>
              </div>
            </div>
          </div>

          {/* Account Settings */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-[#2CD7E3] flex items-center gap-2">
              <Mail size={20} />
              Account
            </h3>
            <div className="bg-[#111111] rounded-lg border border-[#2CD7E3]/20 divide-y divide-gray-800">
              <div className="p-4">
                <div className="text-sm text-gray-400">Email</div>
                <div className="text-white mt-1">{mockUser.email}</div>
              </div>
              <div className="p-4">
                <div className="text-sm text-gray-400 mb-3">Linked Accounts</div>
                <div className="space-y-2">
                  {Object.entries(settings.oauthProviders).map(([provider, connected]) => (
                    <button
                      key={provider}
                      onClick={() => {
                        setSelectedOAuth(provider)
                        setShowOAuthModal(true)
                      }}
                      className="w-full flex items-center justify-between p-3 rounded-lg bg-black/50 hover:bg-black/70 transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-[#2CD7E3]/20 flex items-center justify-center">
                          {provider === "discord" && "🎮"}
                          {provider === "google" && "🔍"}
                          {provider === "apple" && "🍎"}
                          {provider === "facebook" && "📘"}
                        </div>
                        <span className="capitalize">{provider}</span>
                      </div>
                      {connected ? (
                        <span className="text-green-500 text-sm flex items-center gap-1">
                          <Check size={16} />
                          Connected
                        </span>
                      ) : (
                        <span className="text-gray-500 text-sm">Not connected</span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Subscription Settings */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-[#2CD7E3] flex items-center gap-2">
              <CreditCard size={20} />
              Subscription
            </h3>
            <div className="bg-[#111111] rounded-lg border border-[#2CD7E3]/20 divide-y divide-gray-800">
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <div className="text-white font-semibold">{mockSubscription.plan} Plan</div>
                    <div className="text-sm text-gray-400 mt-1">{mockSubscription.price}</div>
                  </div>
                  <div className="px-3 py-1 rounded-full bg-[#2CD7E3]/20 text-[#2CD7E3] text-xs font-semibold">
                    Active
                  </div>
                </div>
                <div className="text-sm text-gray-400">Renews on {mockSubscription.renewalDate}</div>
              </div>
              <div className="p-4 space-y-2">
                <button
                  onClick={() => setShowSubscriptionModal(true)}
                  className="w-full px-4 py-2 rounded-lg bg-[#2CD7E3] text-black font-semibold hover:bg-[#16CFF3] transition-all"
                >
                  Manage Subscription
                </button>
                <button
                  onClick={() => showToastMessage("Viewing receipts")}
                  className="w-full px-4 py-2 rounded-lg border border-[#2CD7E3]/50 text-[#2CD7E3] font-semibold hover:bg-[#2CD7E3]/10 transition-all"
                >
                  View Receipts
                </button>
              </div>
            </div>
          </div>

          {/* Notification Settings */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-[#2CD7E3] flex items-center gap-2">
              <Bell size={20} />
              Notifications
            </h3>
            <div className="bg-[#111111] rounded-lg border border-[#2CD7E3]/20 divide-y divide-gray-800">
              <ToggleItem
                label="Enable Notifications"
                description="Master toggle for all notifications"
                checked={settings.notificationsEnabled}
                onChange={() => handleToggle("Notifications", "notificationsEnabled")}
              />
              <ToggleItem
                label="Live Notifications"
                description="Get notified when followed streamers go live"
                checked={settings.liveNotifications}
                onChange={() => handleToggle("Live notifications", "liveNotifications")}
                disabled={!settings.notificationsEnabled}
              />
              <ToggleItem
                label="Poll Notifications"
                description="Participate in live polls and votes"
                checked={settings.pollNotifications}
                onChange={() => handleToggle("Poll notifications", "pollNotifications")}
                disabled={!settings.notificationsEnabled}
              />
              <ToggleItem
                label="Event Reminders"
                description="Reminders for upcoming events you're interested in"
                checked={settings.eventReminders}
                onChange={() => handleToggle("Event reminders", "eventReminders")}
                disabled={!settings.notificationsEnabled}
              />
              <ToggleItem
                label="Email Digests"
                description="Weekly summary of highlights and updates"
                checked={settings.emailDigests}
                onChange={() => handleToggle("Email digests", "emailDigests")}
                disabled={!settings.notificationsEnabled}
              />
            </div>
          </div>

          {/* Playback Settings */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-[#2CD7E3] flex items-center gap-2">
              <Play size={20} />
              Playback
            </h3>
            <div className="bg-[#111111] rounded-lg border border-[#2CD7E3]/20 divide-y divide-gray-800">
              <ToggleItem
                label="Auto-play Next"
                description="Automatically play the next video"
                checked={settings.autoPlayNext}
                onChange={() => handleToggle("Auto-play", "autoPlayNext")}
              />
              <div className="p-4">
                <div className="text-white font-semibold mb-1">Video Quality Cap</div>
                <div className="text-sm text-gray-400 mb-3">Maximum video quality for playback</div>
                <div className="flex gap-2">
                  {["Auto", "1080p", "720p", "480p"].map((quality) => (
                    <button
                      key={quality}
                      onClick={() => handleQualityChange(quality)}
                      className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                        settings.videoQuality === quality
                          ? "bg-[#2CD7E3] text-black"
                          : "bg-black/50 text-gray-400 hover:bg-black/70"
                      }`}
                    >
                      {quality}
                    </button>
                  ))}
                </div>
              </div>
              <ToggleItem
                label="Captions Default"
                description="Always show captions when available"
                checked={settings.captionsDefault}
                onChange={() => handleToggle("Captions", "captionsDefault")}
              />
            </div>
          </div>

          {/* Ads Settings */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-[#2CD7E3] flex items-center gap-2">
              <Tv size={20} />
              Ads
            </h3>
            <div className="bg-[#111111] rounded-lg border border-[#2CD7E3]/20 divide-y divide-gray-800">
              <ToggleItem
                label="Ad Personalization"
                description="Show ads based on your interests"
                checked={settings.adPersonalization}
                onChange={() => handleToggle("Ad personalization", "adPersonalization")}
              />
              <div className="p-4">
                <button
                  onClick={() => showToastMessage("Redirecting to ad-free purchase...")}
                  className="w-full px-4 py-3 rounded-lg bg-gradient-to-r from-[#2CD7E3] to-[#16CFF3] text-black font-bold hover:opacity-90 transition-all"
                >
                  Purchase Ad-Free Experience
                </button>
                <p className="text-xs text-gray-500 text-center mt-2">Remove all ads for $4.99/month</p>
              </div>
            </div>
          </div>

          {/* Privacy & Security Settings */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-[#2CD7E3] flex items-center gap-2">
              <ShieldAlert size={20} />
              Privacy & Security
            </h3>
            <div className="bg-[#111111] rounded-lg border border-[#2CD7E3]/20 divide-y divide-gray-800">
              <button
                onClick={() => setShow2FAModal(true)}
                className="w-full p-4 flex items-center justify-between hover:bg-black/30 transition-all"
              >
                <div className="text-left">
                  <div className="text-white font-semibold">Two-Factor Authentication</div>
                  <div className="text-sm text-gray-400 mt-1">
                    {settings.twoFactorEnabled ? "Enabled" : "Add an extra layer of security"}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {settings.twoFactorEnabled && (
                    <span className="text-green-500 text-sm">
                      <Check size={16} />
                    </span>
                  )}
                  <ChevronRight size={20} className="text-gray-400" />
                </div>
              </button>
              <button
                onClick={() => setShowBlockedUsersModal(true)}
                className="w-full p-4 flex items-center justify-between hover:bg-black/30 transition-all"
              >
                <div className="text-left">
                  <div className="text-white font-semibold">Blocked Users</div>
                  <div className="text-sm text-gray-400 mt-1">Manage your blocked users list</div>
                </div>
                <ChevronRight size={20} className="text-gray-400" />
              </button>
            </div>
          </div>

          {/* About Settings */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-[#2CD7E3] flex items-center gap-2">
              <Info size={20} />
              About
            </h3>
            <div className="bg-[#111111] rounded-lg border border-[#2CD7E3]/20 divide-y divide-gray-800">
              <div className="p-4">
                <div className="text-sm text-gray-400">App Version</div>
                <div className="text-white mt-1">EVO TV v1.0.0 (Build 2025.02)</div>
              </div>
              <button
                onClick={() => showToastMessage("Opening Terms of Service...")}
                className="w-full p-4 flex items-center justify-between hover:bg-black/30 transition-all"
              >
                <span className="text-white">Terms of Service</span>
                <ChevronRight size={20} className="text-gray-400" />
              </button>
              <button
                onClick={() => showToastMessage("Opening Privacy Policy...")}
                className="w-full p-4 flex items-center justify-between hover:bg-black/30 transition-all"
              >
                <span className="text-white">Privacy Policy</span>
                <ChevronRight size={20} className="text-gray-400" />
              </button>
              <button
                onClick={() => showToastMessage("Opening bug report form...")}
                className="w-full p-4 flex items-center justify-between hover:bg-black/30 transition-all"
              >
                <span className="text-white">Report a Bug</span>
                <ChevronRight size={20} className="text-gray-400" />
              </button>
            </div>
          </div>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="w-full px-4 py-3 rounded-lg bg-red-600/20 border border-red-600/50 text-red-500 font-bold hover:bg-red-600/30 transition-all flex items-center justify-center gap-2"
          >
            <LogOut size={20} />
            Logout
          </button>
        </div>
      )}

      {activeTab === "shop" && (
        <div>
          <div className="flex border-b border-[#2CD7E3]/20 px-4">
            <button
              onClick={() => setShopSubTab("orders")}
              className={`px-4 py-3 font-semibold text-sm transition-all ${
                shopSubTab === "orders"
                  ? "text-[#2CD7E3] border-b-2 border-[#2CD7E3]"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              Orders
            </button>
            <button
              onClick={() => setShopSubTab("saved")}
              className={`px-4 py-3 font-semibold text-sm transition-all ${
                shopSubTab === "saved" ? "text-[#2CD7E3] border-b-2 border-[#2CD7E3]" : "text-gray-400 hover:text-white"
              }`}
            >
              Saved Items
            </button>
            <button
              onClick={() => setShopSubTab("payment")}
              className={`px-4 py-3 font-semibold text-sm transition-all ${
                shopSubTab === "payment"
                  ? "text-[#2CD7E3] border-b-2 border-[#2CD7E3]"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              Payment
            </button>
          </div>

          {shopSubTab === "orders" && (
            <div className="p-4 space-y-4">
              {/* Search and Filter */}
              <div className="flex gap-2">
                <div className="flex-1 relative">
                  <Search size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search orders..."
                    value={orderSearchQuery}
                    onChange={(e) => setOrderSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-[#111] border border-gray-800 rounded-lg text-white focus:outline-none focus:border-[#2CD7E3]"
                  />
                </div>
                <button
                  onClick={() => setShowFilterModal(true)}
                  className="p-2 bg-[#111] border border-gray-800 rounded-lg hover:border-[#2CD7E3] transition-all"
                >
                  <Filter size={20} className="text-[#2CD7E3]" />
                </button>
              </div>

              {/* Orders List */}
              {filteredOrders.length === 0 ? (
                <div className="text-center py-12">
                  <Package size={48} className="mx-auto text-gray-600 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-400 mb-2">No orders found</h3>
                  <p className="text-sm text-gray-500 mb-4">
                    {orderSearchQuery || orderStatusFilter !== "all"
                      ? "Try adjusting your search or filters"
                      : "Start shopping to see your orders here"}
                  </p>
                  <Link
                    href="/shop"
                    className="inline-block px-6 py-2 bg-[#2CD7E3] text-black font-semibold rounded-lg hover:bg-[#16CFF3] transition-all"
                  >
                    Browse Shop
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredOrders.map((order) => (
                    <Link
                      key={order.id}
                      href={`/profile/orders/${order.id}`}
                      className="block bg-[#111] rounded-lg p-4 border border-gray-800 hover:border-[#2CD7E3] transition-all"
                      onClick={() => console.log("[v0] Analytics: order-viewed", { orderId: order.id })}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="text-sm text-gray-400">Order #{order.id}</p>
                          <p className="text-xs text-gray-500 mt-1">{order.date}</p>
                        </div>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(order.status)}`}
                        >
                          {order.status}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 mb-3">
                        <div className="relative w-16 h-16 bg-gray-800 rounded-lg overflow-hidden flex-shrink-0">
                          <Image
                            src={order.items[0].image || "/placeholder.svg"}
                            alt={order.items[0].name}
                            fill
                            className="object-cover"
                            sizes="64px"
                          />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-semibold">{order.items[0].name}</p>
                          {order.items.length > 1 && (
                            <p className="text-xs text-gray-400">+{order.items.length - 1} more item(s)</p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-gray-800">
                        <span className="text-lg font-bold text-[#2CD7E3]">₦{order.total.toLocaleString()}</span>
                        <span className="text-sm text-[#2CD7E3] flex items-center gap-1">
                          View Details
                          <ChevronRight size={16} />
                        </span>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          )}

          {shopSubTab === "saved" && (
            <div className="p-4">
              {savedItems.length === 0 ? (
                <div className="text-center py-12">
                  <Heart size={48} className="mx-auto text-gray-600 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-400 mb-2">No saved items</h3>
                  <p className="text-sm text-gray-500 mb-4">Save items you love to buy them later</p>
                  <Link
                    href="/shop"
                    className="inline-block px-6 py-2 bg-[#2CD7E3] text-black font-semibold rounded-lg hover:bg-[#16CFF3] transition-all"
                  >
                    Browse Shop
                  </Link>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  {savedItems.map((item) => (
                    <div key={item.id} className="bg-[#111] rounded-lg overflow-hidden border border-gray-800">
                      <div className="relative aspect-square bg-gray-800">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          fill
                          className="object-cover"
                          sizes="50vw"
                        />
                        {!item.inStock && (
                          <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                            <span className="text-red-500 font-semibold text-sm">Out of Stock</span>
                          </div>
                        )}
                        {item.inStock && item.stockCount <= 5 && (
                          <div className="absolute top-2 left-2 bg-yellow-500/90 text-black text-xs font-bold px-2 py-1 rounded">
                            Only {item.stockCount} left!
                          </div>
                        )}
                      </div>
                      <div className="p-3">
                        <h4 className="font-semibold text-sm mb-1 line-clamp-2">{item.name}</h4>
                        <p className="text-[#2CD7E3] font-bold mb-3">₦{item.price.toLocaleString()}</p>
                        <div className="space-y-2">
                          <button
                            onClick={() => handleMoveToCart(item)}
                            disabled={!item.inStock}
                            className="w-full py-2 bg-[#2CD7E3] text-black text-sm font-semibold rounded-lg hover:bg-[#16CFF3] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            {item.inStock ? "Move to Cart" : "Notify When Available"}
                          </button>
                          <button
                            onClick={() => handleRemoveSavedItem(item.id)}
                            className="w-full py-2 border border-gray-700 text-gray-400 text-sm font-semibold rounded-lg hover:border-red-500 hover:text-red-500 transition-all flex items-center justify-center gap-2"
                          >
                            <Trash2 size={16} />
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {shopSubTab === "payment" && (
            <div className="p-4 space-y-4">
              <button
                onClick={() => setShowAddPaymentModal(true)}
                className="w-full py-3 border-2 border-dashed border-[#2CD7E3]/50 rounded-lg text-[#2CD7E3] font-semibold hover:bg-[#2CD7E3]/10 transition-all flex items-center justify-center gap-2"
              >
                <Plus size={20} />
                Add Payment Method
              </button>

              {paymentMethods.length === 0 ? (
                <div className="text-center py-12">
                  <CreditCard size={48} className="mx-auto text-gray-600 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-400 mb-2">No payment methods</h3>
                  <p className="text-sm text-gray-500">Add a payment method for faster checkout</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {paymentMethods.map((method) => (
                    <div
                      key={method.id}
                      className="bg-[#111] rounded-lg p-4 border border-gray-800 hover:border-[#2CD7E3]/50 transition-all"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          {method.type === "card" ? (
                            <CreditCard size={24} className="text-[#2CD7E3]" />
                          ) : (
                            <Wallet size={24} className="text-[#2CD7E3]" />
                          )}
                          <div>
                            {method.type === "card" ? (
                              <>
                                <p className="font-semibold">
                                  {method.brand} •••• {method.last4}
                                </p>
                                <p className="text-xs text-gray-400">Expires {method.expiry}</p>
                              </>
                            ) : (
                              <>
                                <p className="font-semibold">{method.name}</p>
                                <p className="text-xs text-gray-400">{method.email}</p>
                              </>
                            )}
                          </div>
                        </div>
                        {method.isDefault && (
                          <span className="px-2 py-1 bg-[#2CD7E3]/20 text-[#2CD7E3] text-xs font-semibold rounded">
                            Default
                          </span>
                        )}
                      </div>
                      <div className="flex gap-2">
                        {!method.isDefault && (
                          <button
                            onClick={() => handleSetDefaultPayment(method.id)}
                            className="flex-1 py-2 border border-[#2CD7E3]/50 text-[#2CD7E3] text-sm font-semibold rounded-lg hover:bg-[#2CD7E3]/10 transition-all"
                          >
                            Set as Default
                          </button>
                        )}
                        <button
                          onClick={() => handleDeletePaymentMethod(method.id)}
                          className="px-4 py-2 border border-red-500/50 text-red-500 text-sm font-semibold rounded-lg hover:bg-red-500/10 transition-all"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="bg-[#111] rounded-lg p-4 border border-[#2CD7E3]/20">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <Bell size={16} className="text-[#2CD7E3]" />
                  Order Notifications
                </h4>
                <p className="text-sm text-gray-400 mb-3">
                  Get updates about your orders via email and push notifications
                </p>
                <Link
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("profile")
                    showToastMessage("Opening notification settings...")
                  }}
                  className="text-sm text-[#2CD7E3] hover:underline"
                >
                  Manage notification preferences →
                </Link>
              </div>
            </div>
          )}
        </div>
      )}

      {showFilterModal && (
        <div className="fixed inset-0 bg-black/80 flex items-end justify-center z-50">
          <div className="bg-[#111] rounded-t-2xl border-t border-[#2CD7E3] p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-white mb-4">Filter Orders</h3>
            <div className="space-y-3 mb-6">
              <button
                onClick={() => {
                  setOrderStatusFilter("all")
                  setShowFilterModal(false)
                }}
                className={`w-full p-3 rounded-lg text-left transition-all ${
                  orderStatusFilter === "all"
                    ? "bg-[#2CD7E3] text-black font-semibold"
                    : "bg-black/50 text-white hover:bg-black/70"
                }`}
              >
                All Orders
              </button>
              {["Processing", "Shipped", "Delivered", "Cancelled"].map((status) => (
                <button
                  key={status}
                  onClick={() => {
                    setOrderStatusFilter(status)
                    setShowFilterModal(false)
                  }}
                  className={`w-full p-3 rounded-lg text-left transition-all ${
                    orderStatusFilter === status
                      ? "bg-[#2CD7E3] text-black font-semibold"
                      : "bg-black/50 text-white hover:bg-black/70"
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowFilterModal(false)}
              className="w-full py-3 border border-gray-700 text-gray-400 rounded-lg hover:bg-black/50 transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {showAddPaymentModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-[#111] rounded-lg border border-[#2CD7E3] p-6 w-full max-w-md my-8">
            <h3 className="text-xl font-bold text-white mb-4">Add Payment Method</h3>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                const newMethod = {
                  id: Date.now().toString(),
                  type: "card",
                  last4: "1234",
                  brand: "Visa",
                  expiry: "12/28",
                  isDefault: paymentMethods.length === 0,
                }
                setPaymentMethods([...paymentMethods, newMethod])
                showToastMessage("Payment method added successfully")
                setShowAddPaymentModal(false)
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-sm font-semibold mb-2">Card Number *</label>
                <input
                  type="text"
                  required
                  className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="1234 5678 9012 3456"
                  maxLength={19}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold mb-2">Expiry *</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#2CD7E3]"
                    placeholder="MM/YY"
                    maxLength={5}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">CVV *</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#2CD7E3]"
                    placeholder="123"
                    maxLength={3}
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Cardholder Name *</label>
                <input
                  type="text"
                  required
                  className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="John Doe"
                />
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 accent-[#2CD7E3]" />
                <span className="text-sm text-gray-400">Save for future purchases</span>
              </label>
              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-[#2CD7E3] text-black font-semibold rounded-lg hover:bg-[#16CFF3] transition-all"
                >
                  Add Card
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddPaymentModal(false)}
                  className="px-4 py-3 border border-gray-700 text-gray-400 rounded-lg hover:bg-black/50 transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {showEditModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="bg-[#111111] rounded-lg border border-[#2CD7E3] p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-white mb-4">Edit Profile</h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-400">Handle</label>
                <input
                  type="text"
                  defaultValue={mockUser.handle}
                  className="w-full mt-1 px-4 py-2 rounded-lg bg-black border border-gray-700 text-white focus:border-[#2CD7E3] focus:outline-none"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400">Bio</label>
                <textarea
                  defaultValue={mockUser.bio}
                  rows={3}
                  className="w-full mt-1 px-4 py-2 rounded-lg bg-black border border-gray-700 text-white focus:border-[#2CD7E3] focus:outline-none resize-none"
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    showToastMessage("Profile updated successfully")
                    setShowEditModal(false)
                  }}
                  className="flex-1 px-4 py-2 rounded-lg bg-[#2CD7E3] text-black font-semibold hover:bg-[#16CFF3] transition-all"
                >
                  Save Changes
                </button>
                <button
                  onClick={() => setShowEditModal(false)}
                  className="px-4 py-2 rounded-lg border border-gray-700 text-gray-400 hover:bg-black/50 transition-all"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* OAuth Modal */}
      {showOAuthModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="bg-[#111111] rounded-lg border border-[#2CD7E3] p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-white mb-4 capitalize">{selectedOAuth}</h3>
            <p className="text-gray-400 mb-6">
              {settings.oauthProviders[selectedOAuth as keyof typeof settings.oauthProviders]
                ? `Disconnect your ${selectedOAuth} account?`
                : `Connect your ${selectedOAuth} account to enable quick login and social features.`}
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => handleOAuthToggle(selectedOAuth)}
                className="flex-1 px-4 py-2 rounded-lg bg-[#2CD7E3] text-black font-semibold hover:bg-[#16CFF3] transition-all"
              >
                {settings.oauthProviders[selectedOAuth as keyof typeof settings.oauthProviders]
                  ? "Disconnect"
                  : "Connect"}
              </button>
              <button
                onClick={() => setShowOAuthModal(false)}
                className="px-4 py-2 rounded-lg border border-gray-700 text-gray-400 hover:bg-black/50 transition-all"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-[#111111] rounded-lg border border-[#2CD7E3] p-6 w-full max-w-md my-8">
            <h3 className="text-xl font-bold text-white mb-4">Manage Subscription</h3>
            <div className="space-y-4 mb-6">
              <div className="p-4 rounded-lg bg-black/50 border border-[#2CD7E3]/30">
                <div className="text-white font-semibold mb-2">{mockSubscription.plan} Plan</div>
                <div className="text-2xl font-bold text-[#2CD7E3] mb-1">{mockSubscription.price}</div>
                <div className="text-sm text-gray-400">Renews {mockSubscription.renewalDate}</div>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-2">Recent Receipts</h4>
                <div className="space-y-2">
                  {mockSubscription.receipts.map((receipt, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-black/30">
                      <div>
                        <div className="text-white text-sm">{receipt.date}</div>
                        <div className="text-xs text-gray-400">{receipt.status}</div>
                      </div>
                      <div className="text-[#2CD7E3] font-semibold">{receipt.amount}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <button
                onClick={() => {
                  showToastMessage("Redirecting to upgrade options...")
                  setShowSubscriptionModal(false)
                }}
                className="w-full px-4 py-2 rounded-lg bg-[#2CD7E3] text-black font-semibold hover:bg-[#16CFF3] transition-all"
              >
                Upgrade Plan
              </button>
              <button
                onClick={() => {
                  showToastMessage("Subscription cancelled")
                  setShowSubscriptionModal(false)
                }}
                className="w-full px-4 py-2 rounded-lg border border-red-600/50 text-red-500 font-semibold hover:bg-red-600/10 transition-all"
              >
                Cancel Subscription
              </button>
              <button
                onClick={() => setShowSubscriptionModal(false)}
                className="w-full px-4 py-2 rounded-lg border border-gray-700 text-gray-400 hover:bg-black/50 transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2FA Modal */}
      {show2FAModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="bg-[#111111] rounded-lg border border-[#2CD7E3] p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-white mb-4">Two-Factor Authentication</h3>
            {settings.twoFactorEnabled ? (
              <>
                <p className="text-gray-400 mb-6">Two-factor authentication is currently enabled for your account.</p>
                <button
                  onClick={() => {
                    const newSettings = { ...settings, twoFactorEnabled: false }
                    updateSettings(newSettings)
                    showToastMessage("Two-factor authentication disabled")
                    setShow2FAModal(false)
                  }}
                  className="w-full px-4 py-2 rounded-lg border border-red-600/50 text-red-500 font-semibold hover:bg-red-600/10 transition-all mb-2"
                >
                  Disable 2FA
                </button>
              </>
            ) : (
              <>
                <p className="text-gray-400 mb-4">
                  Add an extra layer of security to your account by enabling two-factor authentication.
                </p>
                <div className="p-4 rounded-lg bg-black/50 border border-[#2CD7E3]/30 mb-4">
                  <div className="text-sm text-gray-400 mb-2">Setup Steps:</div>
                  <ol className="text-sm text-white space-y-1 list-decimal list-inside">
                    <li>Download an authenticator app</li>
                    <li>Scan the QR code</li>
                    <li>Enter the verification code</li>
                  </ol>
                </div>
                <button
                  onClick={() => {
                    const newSettings = { ...settings, twoFactorEnabled: true }
                    updateSettings(newSettings)
                    showToastMessage("Two-factor authentication enabled")
                    setShow2FAModal(false)
                  }}
                  className="w-full px-4 py-2 rounded-lg bg-[#2CD7E3] text-black font-semibold hover:bg-[#16CFF3] transition-all mb-2"
                >
                  Enable 2FA
                </button>
              </>
            )}
            <button
              onClick={() => setShow2FAModal(false)}
              className="w-full px-4 py-2 rounded-lg border border-gray-700 text-gray-400 hover:bg-black/50 transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Blocked Users Modal */}
      {showBlockedUsersModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="bg-[#111111] rounded-lg border border-[#2CD7E3] p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-white mb-4">Blocked Users</h3>
            <div className="mb-6">
              <p className="text-gray-400 text-center py-8">No blocked users</p>
            </div>
            <button
              onClick={() => setShowBlockedUsersModal(false)}
              className="w-full px-4 py-2 rounded-lg border border-gray-700 text-gray-400 hover:bg-black/50 transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {showToast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-in slide-in-from-top">
          <div className="bg-[#2CD7E3] text-black px-6 py-3 rounded-lg font-semibold shadow-lg flex items-center gap-2">
            <Check size={20} />
            {toastMessage}
          </div>
        </div>
      )}

      <BottomNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  )
}

// Toggle Item Component
function ToggleItem({
  label,
  description,
  checked,
  onChange,
  disabled = false,
}: {
  label: string
  description: string
  checked: boolean
  onChange: () => void
  disabled?: boolean
}) {
  return (
    <div className={`p-4 flex items-center justify-between ${disabled ? "opacity-50" : ""}`}>
      <div className="flex-1">
        <div className="text-white font-semibold">{label}</div>
        <div className="text-sm text-gray-400 mt-1">{description}</div>
      </div>
      <button
        onClick={onChange}
        disabled={disabled}
        className={`relative w-12 h-6 rounded-full transition-all ${
          checked ? "bg-[#2CD7E3]" : "bg-gray-700"
        } ${disabled ? "cursor-not-allowed" : "cursor-pointer"}`}
      >
        <div
          className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform ${
            checked ? "translate-x-6" : "translate-x-0"
          }`}
        />
      </button>
    </div>
  )
}
