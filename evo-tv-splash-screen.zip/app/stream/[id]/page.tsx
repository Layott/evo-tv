"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import {
  ArrowLeft,
  Settings,
  MessageSquare,
  Heart,
  Share2,
  Flag,
  ChevronDown,
  ChevronUp,
  X,
  Check,
  Play,
  Pause,
  Volume2,
  Maximize,
  Send,
  ShoppingBag,
  Plus,
  Minus,
  Trash2,
  CreditCard,
} from "lucide-react"
import AdBanner from "@/components/home/ad-banner"

// Mock stream data
const streamData = {
  1: {
    title: "Pro Match - Team A vs Team B",
    team1: "Team Alpha",
    team2: "Team Beta",
    viewers: "45.2K",
    duration: "2:34:15",
    videoUrl: "/esports-live-stream-match.jpg",
  },
  2: {
    title: "Ranked Grind Session",
    team1: "Solo Player",
    team2: "Ranked Match",
    viewers: "12.8K",
    duration: "1:15:30",
    videoUrl: "/esports-ranked-gameplay.jpg",
  },
  3: {
    title: "Tournament Qualifier",
    team1: "Team Phoenix",
    team2: "Team Dragon",
    viewers: "78.5K",
    duration: "3:45:22",
    videoUrl: "/esports-tournament-qualifier.jpg",
  },
  4: {
    title: "Casual Gameplay",
    team1: "Streamer",
    team2: "Community",
    viewers: "5.3K",
    duration: "0:45:10",
    videoUrl: "/esports-casual-gameplay-stream.jpg",
  },
}

const pollData = {
  question: "Who will win this match?",
  options: [
    { id: 1, text: "Team Alpha", votes: 1245 },
    { id: 2, text: "Team Beta", votes: 987 },
  ],
}

const mockComments = [
  {
    id: 1,
    user: "ProGamer123",
    avatar: "/gamer-avatar-1.png",
    text: "This match is insane! 🔥",
    timestamp: "2m ago",
    likes: 45,
  },
  {
    id: 2,
    user: "EsportsKing",
    avatar: "/gamer-avatar-2.png",
    text: "Team Alpha looking strong today",
    timestamp: "5m ago",
    likes: 23,
  },
  {
    id: 3,
    user: "StreamFan99",
    avatar: "/gamer-avatar-3.png",
    text: "Best tournament of the year!",
    timestamp: "8m ago",
    likes: 67,
  },
  {
    id: 4,
    user: "GamingLegend",
    avatar: "/gamer-avatar-4.png",
    text: "Who else thinks Team Beta will make a comeback?",
    timestamp: "12m ago",
    likes: 34,
  },
  {
    id: 5,
    user: "TwitchViewer",
    avatar: "/gamer-avatar-1.png",
    text: "The plays are incredible!",
    timestamp: "15m ago",
    likes: 89,
  },
  {
    id: 6,
    user: "EsportsFanatic",
    avatar: "/gamer-avatar-2.png",
    text: "This is why I love esports",
    timestamp: "18m ago",
    likes: 56,
  },
]

const mockMerch = [
  {
    id: 1,
    name: "Team Alpha Jersey",
    price: 79.99,
    image: "/team-alpha-logo.jpg",
    description: "Official Team Alpha gaming jersey",
    category: "Apparel",
  },
  {
    id: 2,
    name: "Team Beta Hoodie",
    price: 59.99,
    image: "/team-beta-logo.jpg",
    description: "Premium Team Beta hoodie",
    category: "Apparel",
  },
  {
    id: 3,
    name: "EVO TV Cap",
    price: 24.99,
    image: "/esports-tournament-logo.png",
    description: "Official EVO TV baseball cap",
    category: "Accessories",
  },
  {
    id: 4,
    name: "Gaming Mouse Pad",
    price: 19.99,
    image: "/esports-championship-finals-live-stream.jpg",
    description: "Large gaming mouse pad with team logo",
    category: "Accessories",
  },
  {
    id: 5,
    name: "Championship Poster",
    price: 14.99,
    image: "/esports-tournament-recap.jpg",
    description: "Limited edition championship poster",
    category: "Collectibles",
  },
  {
    id: 6,
    name: "Team Sticker Pack",
    price: 9.99,
    image: "/esports-team-logo-2.jpg",
    description: "Set of 10 team stickers",
    category: "Collectibles",
  },
]

export default function StreamPlayerPage() {
  const router = useRouter()
  const params = useParams()
  const streamId = params.id as string
  const stream = streamData[streamId as keyof typeof streamData] || streamData[1]

  const [isFollowing, setIsFollowing] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const [quality, setQuality] = useState("1080p")
  const [captionsEnabled, setCaptionsEnabled] = useState(false)
  const [showQualityMenu, setShowQualityMenu] = useState(false)
  const [isPollExpanded, setIsPollExpanded] = useState(true)
  const [selectedPollOption, setSelectedPollOption] = useState<number | null>(null)
  const [hasVoted, setHasVoted] = useState(false)
  const [pollResults, setPollResults] = useState(pollData.options)

  const [showSettingsMenu, setShowSettingsMenu] = useState(false)
  const [playbackSpeed, setPlaybackSpeed] = useState(1)
  const [audioLanguage, setAudioLanguage] = useState("English")
  const [subtitleLanguage, setSubtitleLanguage] = useState("Off")

  const [isPlaying, setIsPlaying] = useState(true)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration] = useState(300) // 5 minutes mock duration
  const [volume, setVolume] = useState(80)
  const [showControls, setShowControls] = useState(false)
  const [showCommentsSection, setShowCommentsSection] = useState(false)
  const [comments, setComments] = useState(mockComments)
  const [newComment, setNewComment] = useState("")

  // Simulate real-time viewer count updates
  const [viewerCount, setViewerCount] = useState(stream.viewers)

  const [showShop, setShowShop] = useState(false)
  const [cart, setCart] = useState<Array<{ id: number; quantity: number }>>([])
  const [showCart, setShowCart] = useState(false)
  const [showCheckout, setShowCheckout] = useState(false)
  const [toast, setToast] = useState<string | null>(null)

  useEffect(() => {
    const interval = setInterval(() => {
      const baseCount = Number.parseFloat(stream.viewers)
      const variation = (Math.random() - 0.5) * 0.5
      const newCount = (baseCount + variation).toFixed(1)
      setViewerCount(`${newCount}K`)
    }, 3000)

    return () => clearInterval(interval)
  }, [stream.viewers])

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= duration) return 0
          return prev + 1
        })
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isPlaying, duration])

  const handleVote = () => {
    if (selectedPollOption !== null && !hasVoted) {
      setPollResults((prev) =>
        prev.map((option) => (option.id === selectedPollOption ? { ...option, votes: option.votes + 1 } : option)),
      )
      setHasVoted(true)
    }
  }

  const totalVotes = pollResults.reduce((sum, option) => sum + option.votes, 0)

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left
    const percentage = x / rect.width
    setCurrentTime(Math.floor(percentage * duration))
  }

  const handleAddComment = () => {
    if (newComment.trim()) {
      const comment = {
        id: comments.length + 1,
        user: "You",
        avatar: "/diverse-user-avatars.png",
        text: newComment,
        timestamp: "Just now",
        likes: 0,
      }
      setComments([comment, ...comments])
      setNewComment("")
    }
  }

  const addToCart = (productId: number) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === productId)
      if (existing) {
        return prev.map((item) => (item.id === productId ? { ...item, quantity: item.quantity + 1 } : item))
      }
      return [...prev, { id: productId, quantity: 1 }]
    })
    showToast("Added to cart!")
  }

  const removeFromCart = (productId: number) => {
    setCart((prev) => prev.filter((item) => item.id !== productId))
    showToast("Removed from cart")
  }

  const updateQuantity = (productId: number, delta: number) => {
    setCart(
      (prev) =>
        prev
          .map((item) => {
            if (item.id === productId) {
              const newQuantity = item.quantity + delta
              return newQuantity > 0 ? { ...item, quantity: newQuantity } : null
            }
            return item
          })
          .filter(Boolean) as Array<{ id: number; quantity: number }>,
    )
  }

  const getCartTotal = () => {
    return cart.reduce((total, item) => {
      const product = mockMerch.find((p) => p.id === item.id)
      return total + (product?.price || 0) * item.quantity
    }, 0)
  }

  const showToast = (message: string) => {
    setToast(message)
    setTimeout(() => setToast(null), 3000)
  }

  const handleCheckout = () => {
    showToast("Order placed successfully! 🎉")
    setCart([])
    setShowCheckout(false)
    setShowCart(false)
    setShowShop(false)
  }

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <div className="flex flex-col min-h-screen" style={{ backgroundColor: "#000000" }}>
      {/* Top Bar */}
      <div
        className="flex items-center justify-between px-4 py-3 border-b"
        style={{ borderColor: "rgba(44, 215, 227, 0.2)" }}
      >
        <button onClick={() => router.back()} className="text-white">
          <ArrowLeft size={24} />
        </button>
        <div className="flex items-center gap-3">
          <button onClick={() => setShowShop(true)} className="text-white relative">
            <ShoppingBag size={20} />
            {cartItemCount > 0 && (
              <span
                className="absolute -top-1 -right-1 text-black text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold"
                style={{ backgroundColor: "#2CD7E3" }}
              >
                {cartItemCount}
              </span>
            )}
          </button>
          <button onClick={() => setShowCommentsSection(!showCommentsSection)} className="text-white relative">
            <MessageSquare size={20} />
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
              {comments.length}
            </span>
          </button>
          <button onClick={() => setShowSettingsMenu(true)} className="text-white">
            <Settings size={20} />
          </button>
        </div>
      </div>

      {/* Video Player */}
      <div
        className="relative w-full aspect-video bg-black"
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => setShowControls(false)}
      >
        {/* Mock video player - using image as placeholder */}
        <div className="w-full h-full bg-cover bg-center" style={{ backgroundImage: `url(${stream.videoUrl})` }}>
          {/* LIVE badge */}
          <div
            className="absolute top-4 left-4 px-3 py-1 rounded font-bold text-sm z-10"
            style={{
              backgroundColor: "#00FF00",
              color: "#000000",
            }}
          >
            LIVE
          </div>

          {showSettingsMenu && (
            <div
              className="absolute top-4 right-4 z-20 w-72 rounded-lg overflow-hidden shadow-2xl"
              style={{ backgroundColor: "rgba(0, 0, 0, 0.95)", border: "1px solid #2CD7E3" }}
            >
              {/* Header */}
              <div
                className="flex items-center justify-between px-4 py-3 border-b"
                style={{ borderColor: "rgba(44, 215, 227, 0.3)" }}
              >
                <h2 className="text-sm font-bold" style={{ color: "#2CD7E3" }}>
                  Settings
                </h2>
                <button onClick={() => setShowSettingsMenu(false)} className="text-white">
                  <X size={18} />
                </button>
              </div>

              {/* Settings Content */}
              <div className="overflow-y-auto max-h-96">
                {/* Quality */}
                <div className="px-4 py-3 border-b" style={{ borderColor: "rgba(44, 215, 227, 0.1)" }}>
                  <h3 className="text-xs font-semibold mb-2" style={{ color: "#999999" }}>
                    Quality
                  </h3>
                  <div className="space-y-1">
                    {["Auto", "1080p", "720p", "480p", "360p"].map((q) => (
                      <button
                        key={q}
                        onClick={() => setQuality(q)}
                        className="w-full px-3 py-2 rounded text-xs font-semibold transition-all flex items-center justify-between"
                        style={{
                          backgroundColor: quality === q ? "rgba(44, 215, 227, 0.2)" : "transparent",
                          color: quality === q ? "#2CD7E3" : "#FFFFFF",
                        }}
                      >
                        {q}
                        {quality === q && <Check size={14} />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Playback Speed */}
                <div className="px-4 py-3 border-b" style={{ borderColor: "rgba(44, 215, 227, 0.1)" }}>
                  <h3 className="text-xs font-semibold mb-2" style={{ color: "#999999" }}>
                    Speed
                  </h3>
                  <div className="grid grid-cols-2 gap-1">
                    {[0.5, 0.75, 1, 1.25, 1.5, 2].map((speed) => (
                      <button
                        key={speed}
                        onClick={() => setPlaybackSpeed(speed)}
                        className="px-3 py-2 rounded text-xs font-semibold transition-all flex items-center justify-between"
                        style={{
                          backgroundColor: playbackSpeed === speed ? "rgba(44, 215, 227, 0.2)" : "transparent",
                          color: playbackSpeed === speed ? "#2CD7E3" : "#FFFFFF",
                        }}
                      >
                        {speed}x{playbackSpeed === speed && <Check size={14} />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Audio Language */}
                <div className="px-4 py-3 border-b" style={{ borderColor: "rgba(44, 215, 227, 0.1)" }}>
                  <h3 className="text-xs font-semibold mb-2" style={{ color: "#999999" }}>
                    Audio
                  </h3>
                  <div className="space-y-1">
                    {["English", "Spanish", "French", "German"].map((lang) => (
                      <button
                        key={lang}
                        onClick={() => setAudioLanguage(lang)}
                        className="w-full px-3 py-2 rounded text-xs font-semibold transition-all flex items-center justify-between"
                        style={{
                          backgroundColor: audioLanguage === lang ? "rgba(44, 215, 227, 0.2)" : "transparent",
                          color: audioLanguage === lang ? "#2CD7E3" : "#FFFFFF",
                        }}
                      >
                        {lang}
                        {audioLanguage === lang && <Check size={14} />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Subtitles */}
                <div className="px-4 py-3">
                  <h3 className="text-xs font-semibold mb-2" style={{ color: "#999999" }}>
                    Subtitles
                  </h3>
                  <div className="space-y-1">
                    {["Off", "English", "Spanish", "French"].map((lang) => (
                      <button
                        key={lang}
                        onClick={() => {
                          setSubtitleLanguage(lang)
                          setCaptionsEnabled(lang !== "Off")
                        }}
                        className="w-full px-3 py-2 rounded text-xs font-semibold transition-all flex items-center justify-between"
                        style={{
                          backgroundColor: subtitleLanguage === lang ? "rgba(44, 215, 227, 0.2)" : "transparent",
                          color: subtitleLanguage === lang ? "#2CD7E3" : "#FFFFFF",
                        }}
                      >
                        {lang}
                        {subtitleLanguage === lang && <Check size={14} />}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          <div
            className={`absolute bottom-0 left-0 right-0 transition-opacity duration-300 ${showControls ? "opacity-100" : "opacity-0"}`}
            style={{
              background: "linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.7) 50%, transparent 100%)",
            }}
          >
            {/* Timeline */}
            <div className="px-4 pb-2">
              <div
                className="w-full h-1 bg-gray-700 rounded-full cursor-pointer relative group"
                onClick={handleTimelineClick}
              >
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${(currentTime / duration) * 100}%`,
                    backgroundColor: "#2CD7E3",
                  }}
                >
                  <div
                    className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ backgroundColor: "#2CD7E3" }}
                  />
                </div>
              </div>
              <div className="flex justify-between text-xs mt-1" style={{ color: "#999999" }}>
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Control buttons */}
            <div className="flex items-center justify-between px-4 pb-3">
              <div className="flex items-center gap-3">
                {/* Play/Pause */}
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="text-white hover:text-cyan-400 transition-colors"
                >
                  {isPlaying ? <Pause size={24} fill="white" /> : <Play size={24} fill="white" />}
                </button>

                {/* Volume */}
                <div className="flex items-center gap-2">
                  <Volume2 size={20} className="text-white" />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={volume}
                    onChange={(e) => setVolume(Number(e.target.value))}
                    className="w-20 h-1 accent-cyan-400"
                  />
                  <span className="text-xs text-white w-8">{volume}%</span>
                </div>

                {/* Time display */}
                <span className="text-sm text-white">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </span>
              </div>

              <div className="flex items-center gap-3">
                {/* Settings button */}
                <button
                  onClick={() => setShowSettingsMenu(!showSettingsMenu)}
                  className="text-white hover:text-cyan-400 transition-colors"
                >
                  <Settings size={20} />
                </button>

                {/* Fullscreen */}
                <button className="text-white hover:text-cyan-400 transition-colors">
                  <Maximize size={20} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stream Info */}
      <div className="px-4 py-4">
        <h1 className="text-xl font-bold text-white mb-2">{stream.title}</h1>
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm" style={{ color: "#999999" }}>
            {stream.team1} vs {stream.team2}
          </div>
        </div>

        <div className="flex items-center gap-3 mb-4 text-xs" style={{ color: "#666666" }}>
          <span>{quality}</span>
          <span>•</span>
          <span>{playbackSpeed}x</span>
          <span>•</span>
          <span>{audioLanguage}</span>
          <span>•</span>
          <span>Subtitles: {subtitleLanguage}</span>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4 mb-4 text-sm" style={{ color: "#999999" }}>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: "#00FF00" }}></div>
            <span style={{ color: "#2CD7E3" }}>{viewerCount} watching</span>
          </div>
          <div>Duration: {stream.duration}</div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={() => setIsFollowing(!isFollowing)}
            className="px-6 py-2 rounded-full font-semibold transition-all"
            style={{
              backgroundColor: isFollowing ? "#2CD7E3" : "transparent",
              color: isFollowing ? "#000000" : "#2CD7E3",
              border: "2px solid #2CD7E3",
            }}
          >
            {isFollowing ? "Following" : "Follow"}
          </button>
          <button
            onClick={() => setIsLiked(!isLiked)}
            className="p-2 rounded-full transition-all"
            style={{
              backgroundColor: isLiked ? "rgba(44, 215, 227, 0.2)" : "transparent",
              border: "1px solid rgba(44, 215, 227, 0.5)",
            }}
          >
            <Heart size={20} fill={isLiked ? "#2CD7E3" : "none"} style={{ color: "#2CD7E3" }} />
          </button>
          <button
            className="p-2 rounded-full transition-all"
            style={{
              border: "1px solid rgba(44, 215, 227, 0.5)",
            }}
          >
            <Share2 size={20} style={{ color: "#2CD7E3" }} />
          </button>
          <button
            className="p-2 rounded-full transition-all"
            style={{
              border: "1px solid rgba(153, 153, 153, 0.5)",
            }}
          >
            <Flag size={20} style={{ color: "#999999" }} />
          </button>
        </div>
      </div>

      {showCommentsSection && (
        <div
          className="mx-4 mb-4 rounded-lg overflow-hidden"
          style={{
            border: "1px solid #2CD7E3",
            backgroundColor: "rgba(44, 215, 227, 0.05)",
          }}
        >
          <div
            className="flex items-center justify-between px-4 py-3"
            style={{ backgroundColor: "rgba(44, 215, 227, 0.1)" }}
          >
            <span className="font-bold" style={{ color: "#2CD7E3" }}>
              Live Chat ({comments.length})
            </span>
            <button onClick={() => setShowCommentsSection(false)}>
              <ChevronUp size={20} style={{ color: "#2CD7E3" }} />
            </button>
          </div>

          <div className="px-4 py-4">
            {/* Comment input */}
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleAddComment()}
                placeholder="Add a comment..."
                className="flex-1 px-4 py-2 rounded text-sm"
                style={{
                  backgroundColor: "rgba(255, 255, 255, 0.05)",
                  border: "1px solid rgba(153, 153, 153, 0.3)",
                  color: "#FFFFFF",
                }}
              />
              <button
                onClick={handleAddComment}
                className="px-4 py-2 rounded font-semibold transition-all"
                style={{
                  backgroundColor: newComment.trim() ? "#2CD7E3" : "rgba(153, 153, 153, 0.3)",
                  color: newComment.trim() ? "#000000" : "#666666",
                }}
                disabled={!newComment.trim()}
              >
                <Send size={18} />
              </button>
            </div>

            {/* Comments list */}
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {comments.map((comment) => (
                <div key={comment.id} className="flex gap-3">
                  <img src={comment.avatar || "/placeholder.svg"} alt={comment.user} className="w-8 h-8 rounded-full" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-semibold text-white">{comment.user}</span>
                      <span className="text-xs" style={{ color: "#666666" }}>
                        {comment.timestamp}
                      </span>
                    </div>
                    <p className="text-sm" style={{ color: "#CCCCCC" }}>
                      {comment.text}
                    </p>
                    <button className="text-xs mt-1" style={{ color: "#999999" }}>
                      <Heart size={12} className="inline mr-1" />
                      {comment.likes}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Live Vote Panel */}
      <div
        className="mx-4 mb-4 rounded-lg overflow-hidden"
        style={{
          border: "1px solid #2CD7E3",
          backgroundColor: "rgba(44, 215, 227, 0.05)",
        }}
      >
        <button
          onClick={() => setIsPollExpanded(!isPollExpanded)}
          className="w-full flex items-center justify-between px-4 py-3"
          style={{ backgroundColor: "rgba(44, 215, 227, 0.1)" }}
        >
          <span className="font-bold" style={{ color: "#2CD7E3" }}>
            Live Vote
          </span>
          {isPollExpanded ? (
            <ChevronUp size={20} style={{ color: "#2CD7E3" }} />
          ) : (
            <ChevronDown size={20} style={{ color: "#2CD7E3" }} />
          )}
        </button>

        {isPollExpanded && (
          <div className="px-4 py-4">
            <p className="text-white font-semibold mb-4">{pollData.question}</p>

            {!hasVoted ? (
              <>
                <div className="space-y-2 mb-4">
                  {pollResults.map((option) => (
                    <button
                      key={option.id}
                      onClick={() => setSelectedPollOption(option.id)}
                      className="w-full px-4 py-3 rounded text-left transition-all"
                      style={{
                        backgroundColor:
                          selectedPollOption === option.id ? "rgba(44, 215, 227, 0.2)" : "rgba(255, 255, 255, 0.05)",
                        border: `2px solid ${selectedPollOption === option.id ? "#2CD7E3" : "rgba(153, 153, 153, 0.3)"}`,
                        color: "#FFFFFF",
                      }}
                    >
                      {option.text}
                    </button>
                  ))}
                </div>
                <button
                  onClick={handleVote}
                  disabled={selectedPollOption === null}
                  className="w-full py-3 rounded font-bold transition-all"
                  style={{
                    backgroundColor: selectedPollOption !== null ? "#2CD7E3" : "rgba(153, 153, 153, 0.3)",
                    color: selectedPollOption !== null ? "#000000" : "#666666",
                    cursor: selectedPollOption !== null ? "pointer" : "not-allowed",
                  }}
                >
                  Vote
                </button>
              </>
            ) : (
              <div className="space-y-3">
                {pollResults.map((option) => {
                  const percentage = ((option.votes / totalVotes) * 100).toFixed(1)
                  return (
                    <div key={option.id}>
                      <div className="flex justify-between mb-1 text-sm">
                        <span className="text-white">{option.text}</span>
                        <span style={{ color: "#2CD7E3" }}>{percentage}%</span>
                      </div>
                      <div
                        className="w-full h-2 rounded-full overflow-hidden"
                        style={{ backgroundColor: "rgba(153, 153, 153, 0.2)" }}
                      >
                        <div
                          className="h-full transition-all duration-500"
                          style={{
                            width: `${percentage}%`,
                            backgroundColor: "#2CD7E3",
                          }}
                        ></div>
                      </div>
                    </div>
                  )
                })}
                <p className="text-sm text-center mt-3" style={{ color: "#999999" }}>
                  Total votes: {totalVotes.toLocaleString()}
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {showShop && (
        <div className="fixed inset-0 z-50 pointer-events-none">
          {/* Shop Panel - Floating on the right side */}
          <div
            className="absolute right-4 top-20 w-80 max-h-[calc(100vh-120px)] overflow-hidden flex flex-col rounded-lg shadow-2xl pointer-events-auto"
            style={{
              backgroundColor: "rgba(0, 0, 0, 0.95)",
              border: "2px solid #2CD7E3",
              backdropFilter: "blur(10px)",
            }}
          >
            {/* Header */}
            <div
              className="flex items-center justify-between px-4 py-3 border-b"
              style={{ borderColor: "rgba(44, 215, 227, 0.3)" }}
            >
              <h2 className="text-sm font-bold" style={{ color: "#2CD7E3" }}>
                {showCart ? "Cart" : showCheckout ? "Checkout" : "Merch"}
              </h2>
              <div className="flex items-center gap-2">
                {!showCheckout && !showCart && cartItemCount > 0 && (
                  <button
                    onClick={() => setShowCart(true)}
                    className="px-2 py-1 rounded text-xs font-semibold"
                    style={{ backgroundColor: "#2CD7E3", color: "#000000" }}
                  >
                    Cart ({cartItemCount})
                  </button>
                )}
                <button
                  onClick={() => {
                    setShowShop(false)
                    setShowCart(false)
                    setShowCheckout(false)
                  }}
                  className="text-white hover:text-cyan-400 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-3">
              {!showCart && !showCheckout && (
                // Product Grid - Compact version
                <div className="space-y-2">
                  {mockMerch.map((product) => (
                    <div
                      key={product.id}
                      className="flex gap-2 p-2 rounded-lg"
                      style={{
                        border: "1px solid rgba(44, 215, 227, 0.3)",
                        backgroundColor: "rgba(44, 215, 227, 0.05)",
                      }}
                    >
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        className="w-16 h-16 object-cover rounded"
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="text-xs font-semibold text-white mb-1 truncate">{product.name}</h3>
                        <p className="text-xs mb-2 truncate" style={{ color: "#999999" }}>
                          {product.description}
                        </p>
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-bold" style={{ color: "#2CD7E3" }}>
                            ${product.price}
                          </span>
                          <button
                            onClick={() => addToCart(product.id)}
                            className="px-2 py-1 rounded text-xs font-semibold transition-all hover:scale-105"
                            style={{ backgroundColor: "#2CD7E3", color: "#000000" }}
                          >
                            Add
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {showCart && !showCheckout && (
                // Cart View - Compact
                <div className="space-y-3">
                  {cart.length === 0 ? (
                    <div className="text-center py-8">
                      <ShoppingBag size={32} className="mx-auto mb-2" style={{ color: "#666666" }} />
                      <p className="text-xs" style={{ color: "#999999" }}>
                        Your cart is empty
                      </p>
                    </div>
                  ) : (
                    <>
                      {cart.map((item) => {
                        const product = mockMerch.find((p) => p.id === item.id)
                        if (!product) return null
                        return (
                          <div
                            key={item.id}
                            className="flex gap-2 p-2 rounded-lg"
                            style={{ border: "1px solid rgba(44, 215, 227, 0.3)" }}
                          >
                            <img
                              src={product.image || "/placeholder.svg"}
                              alt={product.name}
                              className="w-12 h-12 object-cover rounded"
                            />
                            <div className="flex-1 min-w-0">
                              <h3 className="text-xs font-semibold text-white mb-1 truncate">{product.name}</h3>
                              <p className="text-xs mb-1" style={{ color: "#2CD7E3" }}>
                                ${product.price}
                              </p>
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => updateQuantity(item.id, -1)}
                                  className="p-0.5 rounded"
                                  style={{ backgroundColor: "rgba(44, 215, 227, 0.2)" }}
                                >
                                  <Minus size={12} style={{ color: "#2CD7E3" }} />
                                </button>
                                <span className="text-white text-xs w-6 text-center">{item.quantity}</span>
                                <button
                                  onClick={() => updateQuantity(item.id, 1)}
                                  className="p-0.5 rounded"
                                  style={{ backgroundColor: "rgba(44, 215, 227, 0.2)" }}
                                >
                                  <Plus size={12} style={{ color: "#2CD7E3" }} />
                                </button>
                                <button onClick={() => removeFromCart(item.id)} className="ml-auto">
                                  <Trash2 size={14} style={{ color: "#999999" }} />
                                </button>
                              </div>
                            </div>
                          </div>
                        )
                      })}

                      <div className="border-t pt-3 mt-3" style={{ borderColor: "rgba(44, 215, 227, 0.3)" }}>
                        <div className="flex justify-between mb-1 text-xs">
                          <span style={{ color: "#999999" }}>Subtotal</span>
                          <span className="text-white">${getCartTotal().toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between mb-1 text-xs">
                          <span style={{ color: "#999999" }}>Shipping</span>
                          <span className="text-white">$5.99</span>
                        </div>
                        <div className="flex justify-between text-sm font-bold mb-3">
                          <span style={{ color: "#2CD7E3" }}>Total</span>
                          <span style={{ color: "#2CD7E3" }}>${(getCartTotal() + 5.99).toFixed(2)}</span>
                        </div>
                        <button
                          onClick={() => setShowCheckout(true)}
                          className="w-full py-2 rounded text-sm font-bold hover:scale-105 transition-transform"
                          style={{ backgroundColor: "#2CD7E3", color: "#000000" }}
                        >
                          Checkout
                        </button>
                        <button
                          onClick={() => setShowCart(false)}
                          className="w-full py-1.5 mt-2 rounded text-xs font-semibold"
                          style={{ color: "#2CD7E3", border: "1px solid rgba(44, 215, 227, 0.5)" }}
                        >
                          Continue Shopping
                        </button>
                      </div>
                    </>
                  )}
                </div>
              )}

              {showCheckout && (
                // Checkout Form - Compact
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold mb-1" style={{ color: "#999999" }}>
                      Email
                    </label>
                    <input
                      type="email"
                      placeholder="your@email.com"
                      className="w-full px-3 py-1.5 rounded text-sm"
                      style={{
                        backgroundColor: "rgba(255, 255, 255, 0.05)",
                        border: "1px solid rgba(153, 153, 153, 0.3)",
                        color: "#FFFFFF",
                      }}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold mb-1" style={{ color: "#999999" }}>
                      Card Number
                    </label>
                    <input
                      type="text"
                      placeholder="1234 5678 9012 3456"
                      className="w-full px-3 py-1.5 rounded text-sm"
                      style={{
                        backgroundColor: "rgba(255, 255, 255, 0.05)",
                        border: "1px solid rgba(153, 153, 153, 0.3)",
                        color: "#FFFFFF",
                      }}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-semibold mb-1" style={{ color: "#999999" }}>
                        Expiry
                      </label>
                      <input
                        type="text"
                        placeholder="MM/YY"
                        className="w-full px-3 py-1.5 rounded text-sm"
                        style={{
                          backgroundColor: "rgba(255, 255, 255, 0.05)",
                          border: "1px solid rgba(153, 153, 153, 0.3)",
                          color: "#FFFFFF",
                        }}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold mb-1" style={{ color: "#999999" }}>
                        CVV
                      </label>
                      <input
                        type="text"
                        placeholder="123"
                        className="w-full px-3 py-1.5 rounded text-sm"
                        style={{
                          backgroundColor: "rgba(255, 255, 255, 0.05)",
                          border: "1px solid rgba(153, 153, 153, 0.3)",
                          color: "#FFFFFF",
                        }}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold mb-1" style={{ color: "#999999" }}>
                      Shipping Address
                    </label>
                    <input
                      type="text"
                      placeholder="123 Main St, City, State, ZIP"
                      className="w-full px-3 py-1.5 rounded text-sm"
                      style={{
                        backgroundColor: "rgba(255, 255, 255, 0.05)",
                        border: "1px solid rgba(153, 153, 153, 0.3)",
                        color: "#FFFFFF",
                      }}
                    />
                  </div>

                  <div className="border-t pt-3 mt-3" style={{ borderColor: "rgba(44, 215, 227, 0.3)" }}>
                    <div className="flex justify-between text-sm font-bold mb-3">
                      <span style={{ color: "#2CD7E3" }}>Total</span>
                      <span style={{ color: "#2CD7E3" }}>${(getCartTotal() + 5.99).toFixed(2)}</span>
                    </div>
                    <button
                      onClick={handleCheckout}
                      className="w-full py-2 rounded text-sm font-bold flex items-center justify-center gap-2 hover:scale-105 transition-transform"
                      style={{ backgroundColor: "#2CD7E3", color: "#000000" }}
                    >
                      <CreditCard size={16} />
                      Complete Purchase
                    </button>
                    <button
                      onClick={() => setShowCheckout(false)}
                      className="w-full py-1.5 mt-2 rounded text-xs font-semibold"
                      style={{ color: "#999999" }}
                    >
                      Back to Cart
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div
          className="fixed bottom-20 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full font-semibold shadow-lg z-50 animate-in fade-in slide-in-from-bottom-4"
          style={{ backgroundColor: "#2CD7E3", color: "#000000" }}
        >
          {toast}
        </div>
      )}

      {/* Ad Banner */}
      <AdBanner />
    </div>
  )
}
