"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Bell, ExternalLink, Play, Calendar, Users, Video } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

// Mock data for teams
const teamsData: Record<string, any> = {
  "team-alpha": {
    id: "team-alpha",
    name: "Team Alpha",
    banner: "/team-alpha-banner.jpg",
    avatar: "/team-alpha-logo.jpg",
    bio: "Professional esports organization competing in multiple titles. Champions of the 2024 World Championship.",
    followers: 125000,
    socialLinks: [
      { platform: "Twitter", url: "https://twitter.com/teamalpha", icon: "𝕏" },
      { platform: "Discord", url: "https://discord.gg/teamalpha", icon: "💬" },
      { platform: "YouTube", url: "https://youtube.com/teamalpha", icon: "▶️" },
    ],
    roster: [
      { name: "Player1", role: "Captain", avatar: "/player1.jpg" },
      { name: "Player2", role: "Support", avatar: "/player2.jpg" },
      { name: "Player3", role: "Carry", avatar: "/player3.jpg" },
      { name: "Player4", role: "Mid", avatar: "/player4.jpg" },
      { name: "Player5", role: "Offlane", avatar: "/player5.jpg" },
    ],
    liveMatches: [
      {
        id: "live-1",
        title: "Team Alpha vs Team Beta - Grand Finals",
        opponent: "Team Beta",
        game: "Dota 2",
        viewers: 45000,
        thumbnail: "/match-live-1.jpg",
      },
    ],
    upcomingMatches: [
      {
        id: "upcoming-1",
        title: "Team Alpha vs Team Gamma",
        opponent: "Team Gamma",
        game: "CS2",
        date: "2025-01-30T18:00:00Z",
        tournament: "ESL Pro League",
      },
      {
        id: "upcoming-2",
        title: "Team Alpha vs Team Delta",
        opponent: "Team Delta",
        game: "Valorant",
        date: "2025-02-02T20:00:00Z",
        tournament: "VCT Masters",
      },
    ],
    videos: [
      {
        id: "101",
        title: "Championship Finals - Game 5",
        thumbnail: "/vod-thumb-1.jpg",
        duration: "45:32",
        views: 250000,
        uploadDate: "2025-01-15",
        progress: 65,
      },
      {
        id: "102",
        title: "Semifinals Highlights",
        thumbnail: "/vod-thumb-2.jpg",
        duration: "28:15",
        views: 180000,
        uploadDate: "2025-01-12",
        progress: 0,
      },
      {
        id: "103",
        title: "Best Plays Compilation",
        thumbnail: "/vod-thumb-3.jpg",
        duration: "15:45",
        views: 320000,
        uploadDate: "2025-01-10",
        progress: 100,
      },
    ],
  },
}

export default function TeamProfilePage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [isFollowing, setIsFollowing] = useState(false)
  const [showFollowModal, setShowFollowModal] = useState(false)
  const [notificationPreference, setNotificationPreference] = useState<"all" | "live" | "highlights">("all")
  const [showToast, setShowToast] = useState(false)
  const [toastMessage, setToastMessage] = useState("")

  const team = teamsData[params.id]

  useEffect(() => {
    // Load follow status from localStorage
    const followData = localStorage.getItem(`follow-${params.id}`)
    if (followData) {
      const data = JSON.parse(followData)
      setIsFollowing(data.isFollowing)
      setNotificationPreference(data.preference || "all")
    }
  }, [params.id])

  const handleFollowClick = () => {
    if (isFollowing) {
      // Unfollow
      setIsFollowing(false)
      localStorage.removeItem(`follow-${params.id}`)
      showToastMessage("Unfollowed successfully")
    } else {
      // Show modal for notification preferences
      setShowFollowModal(true)
    }
  }

  const handleFollowConfirm = () => {
    setIsFollowing(true)
    localStorage.setItem(
      `follow-${params.id}`,
      JSON.stringify({ isFollowing: true, preference: notificationPreference }),
    )
    setShowFollowModal(false)
    showToastMessage(`Following ${team.name} - ${getPreferenceLabel(notificationPreference)}`)
  }

  const showToastMessage = (message: string) => {
    setToastMessage(message)
    setShowToast(true)
    setTimeout(() => setShowToast(false), 3000)
  }

  const getPreferenceLabel = (pref: string) => {
    switch (pref) {
      case "all":
        return "All notifications"
      case "live":
        return "Live streams only"
      case "highlights":
        return "Highlights only"
      default:
        return ""
    }
  }

  if (!team) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <p className="text-gray-400">Team not found</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white pb-6">
      {/* Header */}
      <div className="relative">
        <button
          onClick={() => router.back()}
          className="absolute top-4 left-4 z-10 p-2 rounded-full bg-black/50 backdrop-blur-sm"
        >
          <ArrowLeft size={24} className="text-white" />
        </button>

        {/* Banner */}
        <div className="relative h-48 bg-gradient-to-b from-[#2CD7E3]/20 to-black">
          <Image src={team.banner || "/placeholder.svg"} alt={team.name} fill className="object-cover opacity-50" />
        </div>

        {/* Avatar & Info */}
        <div className="px-4 -mt-16 relative z-10">
          <div className="flex items-end gap-4 mb-4">
            <div className="w-24 h-24 rounded-full border-4 border-black overflow-hidden bg-[#2CD7E3]/20">
              <Image
                src={team.avatar || "/placeholder.svg"}
                alt={team.name}
                width={96}
                height={96}
                className="object-cover"
              />
            </div>
            <div className="flex-1 pb-2">
              <h1 className="text-2xl font-bold mb-1">{team.name}</h1>
              <p className="text-sm text-gray-400">{team.followers.toLocaleString()} followers</p>
            </div>
          </div>

          {/* Follow Button */}
          <button
            onClick={handleFollowClick}
            className="w-full py-3 rounded-lg font-semibold transition-all mb-4"
            style={{
              backgroundColor: isFollowing ? "transparent" : "#2CD7E3",
              color: isFollowing ? "#2CD7E3" : "#000000",
              border: isFollowing ? "2px solid #2CD7E3" : "none",
              boxShadow: isFollowing ? "0 0 20px rgba(44, 215, 227, 0.3)" : "none",
            }}
          >
            <div className="flex items-center justify-center gap-2">
              <Bell size={20} />
              {isFollowing ? "Following" : "Follow"}
            </div>
          </button>

          {/* Bio */}
          <p className="text-gray-300 text-sm mb-4">{team.bio}</p>

          {/* Social Links */}
          <div className="flex gap-3 mb-6">
            {team.socialLinks.map((link: any) => (
              <a
                key={link.platform}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#2CD7E3]/30 hover:border-[#16CFF3] transition-all"
              >
                <span>{link.icon}</span>
                <span className="text-sm">{link.platform}</span>
                <ExternalLink size={14} />
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 px-4 mb-6 border-b border-[#2CD7E3]/20">
        {["overview", "matches", "videos", "roster"].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className="flex-1 py-3 text-sm font-semibold capitalize transition-all relative"
            style={{
              color: activeTab === tab ? "#2CD7E3" : "#666666",
            }}
          >
            {tab}
            {activeTab === tab && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5" style={{ backgroundColor: "#2CD7E3" }} />
            )}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="px-4">
        {activeTab === "overview" && (
          <div>
            <h2 className="text-xl font-bold mb-4">About {team.name}</h2>
            <p className="text-gray-300 mb-6">{team.bio}</p>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-[#2CD7E3]/10 border border-[#2CD7E3]/20">
                <p className="text-sm text-gray-400 mb-1">Total Followers</p>
                <p className="text-2xl font-bold text-[#2CD7E3]">{team.followers.toLocaleString()}</p>
              </div>
              <div className="p-4 rounded-lg bg-[#2CD7E3]/10 border border-[#2CD7E3]/20">
                <p className="text-sm text-gray-400 mb-1">Active Players</p>
                <p className="text-2xl font-bold text-[#2CD7E3]">{team.roster.length}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "matches" && (
          <div>
            {/* Live Matches */}
            {team.liveMatches.length > 0 && (
              <div className="mb-6">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#00FF00] animate-pulse" />
                  Live Now
                </h2>
                {team.liveMatches.map((match: any) => (
                  <Link
                    key={match.id}
                    href={`/stream/${match.id}`}
                    className="block p-4 rounded-lg bg-[#2CD7E3]/10 border border-[#2CD7E3]/20 hover:border-[#16CFF3] transition-all mb-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative w-24 h-16 rounded overflow-hidden bg-black">
                        <Image
                          src={match.thumbnail || "/placeholder.svg"}
                          alt={match.title}
                          fill
                          className="object-cover"
                        />
                        <div className="absolute top-1 left-1 px-2 py-0.5 rounded text-xs font-bold bg-[#00FF00] text-black">
                          LIVE
                        </div>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">{match.title}</h3>
                        <p className="text-sm text-gray-400">{match.game}</p>
                        <p className="text-xs text-[#2CD7E3]">{match.viewers.toLocaleString()} viewers</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}

            {/* Upcoming Matches */}
            <div>
              <h2 className="text-xl font-bold mb-4">Upcoming Matches</h2>
              {team.upcomingMatches.length > 0 ? (
                team.upcomingMatches.map((match: any) => {
                  const matchDate = new Date(match.date)
                  const now = new Date()
                  const diffMs = matchDate.getTime() - now.getTime()
                  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
                  const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))

                  return (
                    <div key={match.id} className="p-4 rounded-lg bg-[#2CD7E3]/10 border border-[#2CD7E3]/20 mb-3">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold">{match.title}</h3>
                        <Calendar size={16} className="text-[#2CD7E3]" />
                      </div>
                      <p className="text-sm text-gray-400 mb-1">{match.tournament}</p>
                      <p className="text-sm text-gray-400 mb-2">{match.game}</p>
                      <div className="flex items-center gap-2">
                        <div className="px-3 py-1 rounded-full bg-[#2CD7E3]/20 text-xs font-semibold text-[#2CD7E3]">
                          {diffDays}d {diffHours}h
                        </div>
                        <p className="text-xs text-gray-500">
                          {matchDate.toLocaleDateString()} at{" "}
                          {matchDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                    </div>
                  )
                })
              ) : (
                <div className="text-center py-12">
                  <Calendar size={48} className="mx-auto mb-4 text-gray-600" />
                  <p className="text-gray-400 mb-2">No upcoming matches</p>
                  <p className="text-sm text-gray-600">Check back later for scheduled matches</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === "videos" && (
          <div>
            <h2 className="text-xl font-bold mb-4">Videos & Highlights</h2>
            {team.videos.length > 0 ? (
              <div className="space-y-4">
                {team.videos.map((video: any) => (
                  <Link
                    key={video.id}
                    href={`/vod/${video.id}`}
                    className="block rounded-lg overflow-hidden bg-[#2CD7E3]/10 border border-[#2CD7E3]/20 hover:border-[#16CFF3] transition-all"
                  >
                    <div className="relative h-48">
                      <Image
                        src={video.thumbnail || "/placeholder.svg"}
                        alt={video.title}
                        fill
                        className="object-cover"
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/40 hover:bg-black/20 transition-all">
                        <div className="w-16 h-16 rounded-full bg-[#2CD7E3]/90 flex items-center justify-center">
                          <Play size={28} fill="#000000" className="text-black ml-1" />
                        </div>
                      </div>
                      <div className="absolute bottom-2 right-2 px-2 py-1 rounded bg-black/80 text-xs font-semibold">
                        {video.duration}
                      </div>
                      {video.progress > 0 && video.progress < 100 && (
                        <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/50">
                          <div className="h-full bg-[#2CD7E3]" style={{ width: `${video.progress}%` }} />
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold mb-2">{video.title}</h3>
                      <div className="flex items-center justify-between text-sm text-gray-400">
                        <span>{video.views.toLocaleString()} views</span>
                        <span>{new Date(video.uploadDate).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Video size={48} className="mx-auto mb-4 text-gray-600" />
                <p className="text-gray-400 mb-2">No videos yet</p>
                <p className="text-sm text-gray-600">Videos and highlights will appear here</p>
              </div>
            )}
          </div>
        )}

        {activeTab === "roster" && (
          <div>
            <h2 className="text-xl font-bold mb-4">Team Roster</h2>
            {team.roster.length > 0 ? (
              <div className="space-y-3">
                {team.roster.map((player: any, index: number) => (
                  <div
                    key={index}
                    className="flex items-center gap-4 p-4 rounded-lg bg-[#2CD7E3]/10 border border-[#2CD7E3]/20"
                  >
                    <div className="w-16 h-16 rounded-full bg-[#2CD7E3]/20 flex items-center justify-center overflow-hidden">
                      <Image
                        src={player.avatar || "/placeholder.svg"}
                        alt={player.name}
                        width={64}
                        height={64}
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg">{player.name}</h3>
                      <p className="text-sm text-gray-400">{player.role}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Users size={48} className="mx-auto mb-4 text-gray-600" />
                <p className="text-gray-400 mb-2">No roster information</p>
                <p className="text-sm text-gray-600">Team roster will be displayed here</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Follow Modal */}
      {showFollowModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-[#111111] rounded-lg p-6 max-w-sm w-full border border-[#2CD7E3]/30">
            <h3 className="text-xl font-bold mb-4">Notification Preferences</h3>
            <p className="text-sm text-gray-400 mb-6">Choose what notifications you want to receive from {team.name}</p>

            <div className="space-y-3 mb-6">
              {[
                { value: "all", label: "All Notifications", desc: "Get notified about everything" },
                { value: "live", label: "Live Streams Only", desc: "Only when they go live" },
                { value: "highlights", label: "Highlights Only", desc: "Only new highlight videos" },
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => setNotificationPreference(option.value as any)}
                  className="w-full p-4 rounded-lg border transition-all text-left"
                  style={{
                    borderColor: notificationPreference === option.value ? "#2CD7E3" : "#2CD7E3/30",
                    backgroundColor: notificationPreference === option.value ? "#2CD7E3/10" : "transparent",
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-5 h-5 rounded-full border-2 flex items-center justify-center"
                      style={{
                        borderColor: notificationPreference === option.value ? "#2CD7E3" : "#666666",
                      }}
                    >
                      {notificationPreference === option.value && <div className="w-3 h-3 rounded-full bg-[#2CD7E3]" />}
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold">{option.label}</p>
                      <p className="text-xs text-gray-400">{option.desc}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowFollowModal(false)}
                className="flex-1 py-3 rounded-lg font-semibold border border-[#2CD7E3]/30 text-gray-400 hover:text-white transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleFollowConfirm}
                className="flex-1 py-3 rounded-lg font-semibold transition-all"
                style={{
                  backgroundColor: "#2CD7E3",
                  color: "#000000",
                }}
              >
                Follow
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {showToast && (
        <div
          className="fixed bottom-24 left-4 right-4 p-4 rounded-lg shadow-lg transition-all z-50"
          style={{
            backgroundColor: "#2CD7E3",
            color: "#000000",
          }}
        >
          <p className="font-semibold text-center">{toastMessage}</p>
        </div>
      )}
    </div>
  )
}
