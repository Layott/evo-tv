"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"

export default function SplashScreen() {
  const router = useRouter()

  useEffect(() => {
    const timer = setTimeout(() => {
      router.push("/login")
    }, 5000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <div className="flex items-center justify-center min-h-screen" style={{ backgroundColor: "#000000" }}>
      <div className="flex flex-col items-center justify-center gap-8">
        {/* Glowing ring animation container */}
        <div className="relative w-64 h-64 flex items-center justify-center">
          {/* Outer expanding ring */}
          <div
            className="absolute inset-0 rounded-full"
            style={{
              animation: "expandRing 3s ease-out infinite",
              border: "2px solid #2CD7E3",
              opacity: 0,
            }}
          />

          {/* Middle expanding ring */}
          <div
            className="absolute inset-0 rounded-full"
            style={{
              animation: "expandRing 3s ease-out infinite 1s",
              border: "2px solid #16CFF3",
              opacity: 0,
            }}
          />

          {/* Inner glow ring with enhanced pulse */}
          <div
            className="absolute inset-8 rounded-full"
            style={{
              boxShadow: "0 0 60px #2CD7E3, 0 0 100px #16CFF3, inset 0 0 50px rgba(44, 215, 227, 0.4)",
              animation: "glowPulse 2s ease-in-out infinite",
            }}
          />

          {/* Rotating gradient ring */}
          <div
            className="absolute inset-12 rounded-full"
            style={{
              background: "conic-gradient(from 0deg, transparent, #2CD7E3, transparent)",
              animation: "rotate 4s linear infinite",
              opacity: 0.6,
            }}
          />

          {/* Logo with scale animation */}
          <div className="relative z-10" style={{ animation: "logoScale 2s ease-in-out infinite" }}>
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/evotv%20colored-cLVxaAns95OoPRdSwAHZUktQ6y8MTs.png"
              alt="EVO TV Logo"
              width={180}
              height={180}
              priority
              className="drop-shadow-2xl"
            />
          </div>
        </div>

        {/* Powered by text with fade animation */}
        <p
          className="text-sm font-light"
          style={{
            color: "#666666",
            animation: "fadeInOut 2s ease-in-out infinite",
          }}
        >
          Powered by EVO TV
        </p>
      </div>

      {/* Enhanced animation keyframes */}
      <style jsx>{`
        @keyframes glowPulse {
          0%, 100% {
            box-shadow: 0 0 60px #2cd7e3, 0 0 100px #16cff3, inset 0 0 50px rgba(44, 215, 227, 0.4);
          }
          50% {
            box-shadow: 0 0 80px #2cd7e3, 0 0 140px #16cff3, inset 0 0 70px rgba(44, 215, 227, 0.6);
          }
        }

        @keyframes expandRing {
          0% {
            transform: scale(0.8);
            opacity: 0.8;
          }
          100% {
            transform: scale(1.5);
            opacity: 0;
          }
        }

        @keyframes rotate {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }

        @keyframes logoScale {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.05);
          }
        }

        @keyframes fadeInOut {
          0%, 100% {
            opacity: 0.5;
          }
          50% {
            opacity: 1;
          }
        }
      `}</style>
    </div>
  )
}
