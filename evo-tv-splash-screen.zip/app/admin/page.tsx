"use client"

import { useState } from "react"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { OverviewPage } from "@/components/admin/overview-page"
import { StreamsManagerPage } from "@/components/admin/streams-manager-page"
import { PollsManagerPage } from "@/components/admin/polls-manager-page"
import { ContentManagerPage } from "@/components/admin/content-manager-page"
import { AdsManagerPage } from "@/components/admin/ads-manager-page"
import { UsersRolesPage } from "@/components/admin/users-roles-page"
import { AnalyticsPage } from "@/components/admin/analytics-page"
import { AdminSettingsPage } from "@/components/admin/admin-settings-page"

export default function AdminDashboard() {
  const [activePage, setActivePage] = useState("overview")

  const renderPage = () => {
    switch (activePage) {
      case "overview":
        return <OverviewPage />
      case "streams":
        return <StreamsManagerPage />
      case "polls":
        return <PollsManagerPage />
      case "content":
        return <ContentManagerPage />
      case "ads":
        return <AdsManagerPage />
      case "users":
        return <UsersRolesPage />
      case "analytics":
        return <AnalyticsPage />
      case "settings":
        return <AdminSettingsPage />
      default:
        return <OverviewPage />
    }
  }

  return (
    <div className="flex min-h-screen bg-black">
      <AdminSidebar activePage={activePage} onPageChange={setActivePage} />
      <main className="flex-1 lg:ml-64">{renderPage()}</main>
    </div>
  )
}
