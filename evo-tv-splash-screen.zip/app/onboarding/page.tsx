"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"

export default function OnboardingPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(0)

  const steps = [
    {
      title: "Welcome to EVO TV",
      description: "Your ultimate destination for live sports and entertainment",
      icon: "🎬",
    },
    {
      title: "Personalize Your Feed",
      description: "Choose your favorite sports and teams to customize your experience",
      icon: "⚙️",
    },
    {
      title: "Enable Notifications",
      description: "Get alerts for live matches and events you care about",
      icon: "🔔",
    },
    {
      title: "You're All Set!",
      description: "Start exploring and enjoy premium streaming",
      icon: "🚀",
    },
  ]

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      router.push("/home")
    }
  }

  const handleSkip = () => {
    router.push("/home")
  }

  const step = steps[currentStep]

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: "#000000" }}>
      <div className="w-full max-w-md">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex gap-2 mb-4">
            {steps.map((_, index) => (
              <div
                key={index}
                className="flex-1 h-1 rounded-full transition-all duration-300"
                style={{
                  backgroundColor: index <= currentStep ? "#2CD7E3" : "#333333",
                }}
              />
            ))}
          </div>
          <p style={{ color: "#666666" }} className="text-sm">
            Step {currentStep + 1} of {steps.length}
          </p>
        </div>

        {/* Content */}
        <div className="text-center mb-12">
          <div className="text-6xl mb-6">{step.icon}</div>
          <h1 className="text-3xl font-bold mb-4" style={{ color: "#2CD7E3" }}>
            {step.title}
          </h1>
          <p className="text-lg" style={{ color: "#999999" }}>
            {step.description}
          </p>
        </div>

        {/* Interactive Elements for Each Step */}
        {currentStep === 1 && (
          <div className="mb-8 space-y-3">
            {["Football", "Basketball", "Esports", "Boxing"].map((sport) => (
              <button
                key={sport}
                className="w-full py-3 px-4 rounded-lg border-2 transition-all duration-200 text-left font-medium"
                style={{
                  borderColor: "#2CD7E3",
                  color: "#2CD7E3",
                  backgroundColor: "rgba(44, 215, 227, 0.05)",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = "rgba(44, 215, 227, 0.15)"
                  e.currentTarget.style.borderColor = "#16CFF3"
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = "rgba(44, 215, 227, 0.05)"
                  e.currentTarget.style.borderColor = "#2CD7E3"
                }}
              >
                {sport}
              </button>
            ))}
          </div>
        )}

        {currentStep === 2 && (
          <div className="mb-8 space-y-4">
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" defaultChecked className="w-5 h-5 rounded" style={{ accentColor: "#2CD7E3" }} />
              <span style={{ color: "#ffffff" }}>Live match notifications</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" defaultChecked className="w-5 h-5 rounded" style={{ accentColor: "#2CD7E3" }} />
              <span style={{ color: "#ffffff" }}>Upcoming events</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" defaultChecked className="w-5 h-5 rounded" style={{ accentColor: "#2CD7E3" }} />
              <span style={{ color: "#ffffff" }}>Trending content</span>
            </label>
          </div>
        )}

        {/* Buttons */}
        <div className="space-y-3">
          <button
            onClick={handleNext}
            className="w-full py-3 px-4 rounded-lg font-semibold transition-all duration-200 border-2"
            style={{
              backgroundColor: "#2CD7E3",
              color: "#000000",
              borderColor: "#2CD7E3",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "#16CFF3"
              e.currentTarget.style.borderColor = "#16CFF3"
              e.currentTarget.style.boxShadow = "0 0 30px rgba(22, 207, 243, 0.5)"
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "#2CD7E3"
              e.currentTarget.style.borderColor = "#2CD7E3"
              e.currentTarget.style.boxShadow = "none"
            }}
          >
            {currentStep === steps.length - 1 ? "Start Watching" : "Next"}
          </button>
          <button
            onClick={handleSkip}
            className="w-full py-3 px-4 rounded-lg font-semibold transition-colors duration-200"
            style={{
              backgroundColor: "transparent",
              color: "#2CD7E3",
              border: "2px solid #2CD7E3",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = "#16CFF3"
              e.currentTarget.style.color = "#16CFF3"
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = "#2CD7E3"
              e.currentTarget.style.color = "#2CD7E3"
            }}
          >
            Skip
          </button>
        </div>
      </div>
    </div>
  )
}
