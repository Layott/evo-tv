"use client"

import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import VODPlayer from "@/components/vod/vod-player"

// Mock VOD data
const vodData: Record<string, any> = {
  "1": {
    videoId: "1",
    title: "Insane 1v5 Clutch - Championship Finals",
    event: "EVO Championship 2025 - Grand Finals",
    duration: "12:34",
    uploadDate: "2 days ago",
    thumbnail: "/esports-highlight-clutch-play.jpg",
    chapters: [
      { time: 0, label: "Match Start" },
      { time: 180, label: "First Round" },
      { time: 360, label: "Clutch Moment" },
      { time: 540, label: "Victory Celebration" },
    ],
    relatedVideos: [
      {
        id: "2",
        title: "Championship Winning Moment",
        creator: "EsportsDaily",
        views: "1.8M",
        duration: "8:45",
        thumbnail: "/esports-championship-winning-moment.jpg",
      },
      {
        id: "3",
        title: "Best Plays of the Week",
        creator: "HighlightReel",
        views: "3.1M",
        duration: "15:20",
        thumbnail: "/esports-best-plays-highlights.jpg",
      },
    ],
    initialProgress: 0,
  },
  "2": {
    videoId: "2",
    title: "Championship Winning Moment",
    event: "EVO Championship 2025 - Finals",
    duration: "8:45",
    uploadDate: "3 days ago",
    thumbnail: "/esports-championship-winning-moment.jpg",
    chapters: [
      { time: 0, label: "Pre-Match" },
      { time: 120, label: "Final Round" },
      { time: 300, label: "Winning Play" },
      { time: 450, label: "Trophy Ceremony" },
    ],
    relatedVideos: [
      {
        id: "1",
        title: "Insane 1v5 Clutch",
        creator: "ProPlayer123",
        views: "2.3M",
        duration: "12:34",
        thumbnail: "/esports-highlight-clutch-play.jpg",
      },
      {
        id: "3",
        title: "Best Plays of the Week",
        creator: "HighlightReel",
        views: "3.1M",
        duration: "15:20",
        thumbnail: "/esports-best-plays-highlights.jpg",
      },
    ],
    initialProgress: 180, // Continue watching from 3 minutes
  },
  "3": {
    videoId: "3",
    title: "Best Plays of the Week - Episode 12",
    event: "Weekly Highlights Compilation",
    duration: "15:20",
    uploadDate: "1 week ago",
    thumbnail: "/esports-best-plays-highlights.jpg",
    chapters: [
      { time: 0, label: "Intro" },
      { time: 60, label: "Play #5" },
      { time: 240, label: "Play #4" },
      { time: 420, label: "Play #3" },
      { time: 600, label: "Play #2" },
      { time: 780, label: "Play #1" },
    ],
    relatedVideos: [
      {
        id: "1",
        title: "Insane 1v5 Clutch",
        creator: "ProPlayer123",
        views: "2.3M",
        duration: "12:34",
        thumbnail: "/esports-highlight-clutch-play.jpg",
      },
      {
        id: "2",
        title: "Championship Winning Moment",
        creator: "EsportsDaily",
        views: "1.8M",
        duration: "8:45",
        thumbnail: "/esports-championship-winning-moment.jpg",
      },
    ],
    initialProgress: 420, // Continue watching from 7 minutes
  },
  "101": {
    videoId: "101",
    title: "EVO Championship 2025 Grand Finals - Team Alpha vs Team Omega",
    event: "EVO Championship 2025 - Grand Finals",
    duration: "45:23",
    uploadDate: "1 day ago",
    thumbnail: "/esports-championship-finals-live-stream.jpg",
    chapters: [
      { time: 0, label: "Pre-Match Analysis" },
      { time: 180, label: "Map 1: Dust II" },
      { time: 720, label: "Map 2: Inferno" },
      { time: 1380, label: "Map 3: Mirage" },
      { time: 2040, label: "Championship Point" },
      { time: 2520, label: "Victory Celebration" },
    ],
    relatedVideos: [
      {
        id: "1",
        title: "Insane 1v5 Clutch - Championship Finals",
        creator: "ProPlayer123",
        views: "2.3M",
        duration: "12:34",
        thumbnail: "/esports-highlight-clutch-play.jpg",
      },
      {
        id: "2",
        title: "Championship Winning Moment",
        creator: "EsportsDaily",
        views: "1.8M",
        duration: "8:45",
        thumbnail: "/esports-championship-winning-moment.jpg",
      },
      {
        id: "3",
        title: "Best Plays of the Week",
        creator: "HighlightReel",
        views: "3.1M",
        duration: "15:20",
        thumbnail: "/esports-best-plays-highlights.jpg",
      },
      {
        id: "102",
        title: "Team Alpha's Road to Finals",
        creator: "EVO TV Official",
        views: "890K",
        duration: "28:15",
        thumbnail: "/team-alpha-banner.jpg",
      },
    ],
    initialProgress: 0,
  },
}

export default async function VODPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const vod = vodData[id]

  if (!vod) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen" style={{ backgroundColor: "#000000" }}>
        <p className="text-white text-lg">Video not found</p>
        <Link
          href="/home"
          className="mt-4 px-6 py-2 rounded-full text-white transition-all"
          style={{
            border: "1px solid #2CD7E3",
            backgroundColor: "rgba(44, 215, 227, 0.1)",
          }}
        >
          Go Back
        </Link>
      </div>
    )
  }

  return (
    <div className="relative">
      {/* Back Button */}
      <Link
        href="/home"
        className="absolute top-4 left-4 z-10 w-10 h-10 rounded-full flex items-center justify-center transition-all hover:bg-[rgba(44,215,227,0.2)]"
        style={{
          backgroundColor: "rgba(0, 0, 0, 0.7)",
          border: "1px solid rgba(44, 215, 227, 0.5)",
        }}
      >
        <ArrowLeft size={20} color="white" />
      </Link>

      {/* VOD Player Component */}
      <VODPlayer {...vod} />
    </div>
  )
}
