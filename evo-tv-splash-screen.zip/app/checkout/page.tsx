"use client"

import type React from "react"

import { useState } from "react"
import { ArrowLeft, Check, CreditCard, Wallet } from "lucide-react"
import { useRouter } from "next/navigation"
import Image from "next/image"

export default function CheckoutPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [shippingInfo, setShippingInfo] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
  })
  const [paymentMethod, setPaymentMethod] = useState("card")
  const [cardInfo, setCardInfo] = useState({
    number: "",
    expiry: "",
    cvv: "",
    name: "",
  })
  const [processing, setProcessing] = useState(false)

  const cart = typeof window !== "undefined" ? JSON.parse(localStorage.getItem("evotvCart") || "[]") : []
  const subtotal = cart.reduce((sum: number, item: any) => sum + item.price * item.quantity, 0)
  const shipping = cart.some((item: any) => !item.isDigital) ? 2000 : 0
  const tax = Math.round(subtotal * 0.075)
  const total = subtotal + shipping + tax

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Analytics: checkout-step-1-completed", shippingInfo)
    setStep(2)
  }

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Analytics: checkout-step-2-completed", { paymentMethod })
    setStep(3)
  }

  const handleConfirmOrder = () => {
    setProcessing(true)
    console.log("[v0] Analytics: purchase-completed", { total, itemCount: cart.length })

    // Mock payment processing
    setTimeout(() => {
      const orderId = `EVO-${Date.now()}`
      localStorage.setItem("evotvCart", "[]")
      router.push(`/order/${orderId}`)
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black border-b border-[#2CD7E3]/20 px-4 py-4">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 hover:bg-gray-800 rounded-lg">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-xl font-bold">Checkout</h1>
            <p className="text-sm text-gray-400">Step {step} of 3</p>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 py-6">
        <div className="flex items-center justify-between max-w-2xl mx-auto">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center flex-1">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                  s <= step ? "bg-[#2CD7E3] text-black" : "bg-gray-800 text-gray-500"
                }`}
              >
                {s < step ? <Check size={20} /> : s}
              </div>
              {s < 3 && <div className={`flex-1 h-1 mx-2 ${s < step ? "bg-[#2CD7E3]" : "bg-gray-800"}`} />}
            </div>
          ))}
        </div>
        <div className="flex justify-between max-w-2xl mx-auto mt-2 text-xs text-gray-400">
          <span>Shipping</span>
          <span>Payment</span>
          <span>Review</span>
        </div>
      </div>

      <div className="px-4 pb-20 max-w-2xl mx-auto">
        {/* Step 1: Shipping */}
        {step === 1 && (
          <form onSubmit={handleShippingSubmit} className="space-y-4">
            <h2 className="text-2xl font-bold mb-4">Shipping Information</h2>

            <div>
              <label className="block text-sm font-semibold mb-2">Full Name *</label>
              <input
                type="text"
                required
                value={shippingInfo.name}
                onChange={(e) => setShippingInfo({ ...shippingInfo, name: e.target.value })}
                className="w-full bg-[#111] border border-gray-800 rounded-lg px-4 py-3 focus:outline-none focus:border-[#2CD7E3]"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">Email *</label>
              <input
                type="email"
                required
                value={shippingInfo.email}
                onChange={(e) => setShippingInfo({ ...shippingInfo, email: e.target.value })}
                className="w-full bg-[#111] border border-gray-800 rounded-lg px-4 py-3 focus:outline-none focus:border-[#2CD7E3]"
                placeholder="john@example.com"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">Phone *</label>
              <input
                type="tel"
                required
                value={shippingInfo.phone}
                onChange={(e) => setShippingInfo({ ...shippingInfo, phone: e.target.value })}
                className="w-full bg-[#111] border border-gray-800 rounded-lg px-4 py-3 focus:outline-none focus:border-[#2CD7E3]"
                placeholder="+234 800 000 0000"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">Address *</label>
              <input
                type="text"
                required
                value={shippingInfo.address}
                onChange={(e) => setShippingInfo({ ...shippingInfo, address: e.target.value })}
                className="w-full bg-[#111] border border-gray-800 rounded-lg px-4 py-3 focus:outline-none focus:border-[#2CD7E3]"
                placeholder="123 Main Street"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold mb-2">City *</label>
                <input
                  type="text"
                  required
                  value={shippingInfo.city}
                  onChange={(e) => setShippingInfo({ ...shippingInfo, city: e.target.value })}
                  className="w-full bg-[#111] border border-gray-800 rounded-lg px-4 py-3 focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="Lagos"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">State *</label>
                <input
                  type="text"
                  required
                  value={shippingInfo.state}
                  onChange={(e) => setShippingInfo({ ...shippingInfo, state: e.target.value })}
                  className="w-full bg-[#111] border border-gray-800 rounded-lg px-4 py-3 focus:outline-none focus:border-[#2CD7E3]"
                  placeholder="Lagos"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#2CD7E3] text-black font-bold py-3 rounded-lg hover:bg-[#16CFF3] transition-colors"
            >
              Continue to Payment
            </button>
          </form>
        )}

        {/* Step 2: Payment */}
        {step === 2 && (
          <form onSubmit={handlePaymentSubmit} className="space-y-4">
            <h2 className="text-2xl font-bold mb-4">Payment Method</h2>

            <div className="space-y-3">
              <button
                type="button"
                onClick={() => setPaymentMethod("card")}
                className={`w-full p-4 rounded-lg border-2 transition-all flex items-center gap-3 ${
                  paymentMethod === "card"
                    ? "border-[#2CD7E3] bg-[#2CD7E3]/10"
                    : "border-gray-800 hover:border-gray-700"
                }`}
              >
                <CreditCard size={24} className="text-[#2CD7E3]" />
                <span className="font-semibold">Credit/Debit Card</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod("wallet")}
                className={`w-full p-4 rounded-lg border-2 transition-all flex items-center gap-3 ${
                  paymentMethod === "wallet"
                    ? "border-[#2CD7E3] bg-[#2CD7E3]/10"
                    : "border-gray-800 hover:border-gray-700"
                }`}
              >
                <Wallet size={24} className="text-[#2CD7E3]" />
                <span className="font-semibold">Digital Wallet</span>
              </button>
            </div>

            {paymentMethod === "card" && (
              <div className="space-y-4 mt-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">Card Number *</label>
                  <input
                    type="text"
                    required
                    value={cardInfo.number}
                    onChange={(e) => setCardInfo({ ...cardInfo, number: e.target.value })}
                    className="w-full bg-[#111] border border-gray-800 rounded-lg px-4 py-3 focus:outline-none focus:border-[#2CD7E3]"
                    placeholder="1234 5678 9012 3456"
                    maxLength={19}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2">Expiry Date *</label>
                    <input
                      type="text"
                      required
                      value={cardInfo.expiry}
                      onChange={(e) => setCardInfo({ ...cardInfo, expiry: e.target.value })}
                      className="w-full bg-[#111] border border-gray-800 rounded-lg px-4 py-3 focus:outline-none focus:border-[#2CD7E3]"
                      placeholder="MM/YY"
                      maxLength={5}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">CVV *</label>
                    <input
                      type="text"
                      required
                      value={cardInfo.cvv}
                      onChange={(e) => setCardInfo({ ...cardInfo, cvv: e.target.value })}
                      className="w-full bg-[#111] border border-gray-800 rounded-lg px-4 py-3 focus:outline-none focus:border-[#2CD7E3]"
                      placeholder="123"
                      maxLength={3}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Cardholder Name *</label>
                  <input
                    type="text"
                    required
                    value={cardInfo.name}
                    onChange={(e) => setCardInfo({ ...cardInfo, name: e.target.value })}
                    className="w-full bg-[#111] border border-gray-800 rounded-lg px-4 py-3 focus:outline-none focus:border-[#2CD7E3]"
                    placeholder="John Doe"
                  />
                </div>
              </div>
            )}

            <div className="flex gap-3 mt-6">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex-1 bg-gray-800 text-white font-bold py-3 rounded-lg hover:bg-gray-700 transition-colors"
              >
                Back
              </button>
              <button
                type="submit"
                className="flex-1 bg-[#2CD7E3] text-black font-bold py-3 rounded-lg hover:bg-[#16CFF3] transition-colors"
              >
                Review Order
              </button>
            </div>
          </form>
        )}

        {/* Step 3: Review & Confirm */}
        {step === 3 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Review Your Order</h2>

            {/* Order Items */}
            <div className="bg-[#111] rounded-lg p-4 space-y-3">
              <h3 className="font-semibold mb-3">Order Items</h3>
              {cart.map((item: any) => (
                <div key={item.cartId} className="flex gap-3">
                  <div className="relative w-16 h-16 flex-shrink-0 bg-gray-800 rounded-lg overflow-hidden">
                    <Image
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      fill
                      className="object-cover"
                      sizes="64px"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm">{item.name}</h4>
                    <p className="text-xs text-gray-400">Qty: {item.quantity}</p>
                    <p className="text-[#2CD7E3] font-bold text-sm">₦{(item.price * item.quantity).toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Shipping Info */}
            <div className="bg-[#111] rounded-lg p-4">
              <h3 className="font-semibold mb-3">Shipping Address</h3>
              <p className="text-sm text-gray-300">
                {shippingInfo.name}
                <br />
                {shippingInfo.address}
                <br />
                {shippingInfo.city}, {shippingInfo.state}
                <br />
                {shippingInfo.phone}
              </p>
            </div>

            {/* Payment Info */}
            <div className="bg-[#111] rounded-lg p-4">
              <h3 className="font-semibold mb-3">Payment Method</h3>
              <p className="text-sm text-gray-300 capitalize">
                {paymentMethod === "card" ? "Credit/Debit Card" : "Digital Wallet"}
              </p>
            </div>

            {/* Order Summary */}
            <div className="bg-[#111] rounded-lg p-4">
              <h3 className="font-semibold mb-3">Order Summary</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Subtotal</span>
                  <span>₦{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Shipping</span>
                  <span>{shipping === 0 ? "Free" : `₦${shipping.toLocaleString()}`}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Tax (7.5%)</span>
                  <span>₦{tax.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-lg font-bold pt-2 border-t border-gray-700">
                  <span>Total</span>
                  <span className="text-[#2CD7E3]">₦{total.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(2)}
                disabled={processing}
                className="flex-1 bg-gray-800 text-white font-bold py-3 rounded-lg hover:bg-gray-700 transition-colors disabled:opacity-50"
              >
                Back
              </button>
              <button
                onClick={handleConfirmOrder}
                disabled={processing}
                className="flex-1 bg-[#00FF00] text-black font-bold py-3 rounded-lg hover:bg-[#00DD00] transition-colors disabled:opacity-50"
              >
                {processing ? "Processing..." : "Confirm & Pay"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
