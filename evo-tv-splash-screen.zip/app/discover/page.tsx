"use client"

import { useState } from "react"
import { Search, X, Filter, TrendingUp, Users, Gamepad2, Video } from "lucide-react"
import { useRouter } from "next/navigation"
import BottomNavigation from "@/components/home/bottom-navigation"
import AdBanner from "@/components/home/ad-banner"

// Mock data
const mockStreamers = [
  { id: "1", name: "ProGamer_XYZ", avatar: "/gamer-avatar-1.png", followers: "2.5M", game: "CS2", isLive: true },
  {
    id: "2",
    name: "EsportsKing",
    avatar: "/gamer-avatar-2.png",
    followers: "1.8M",
    game: "Valorant",
    isLive: true,
  },
  {
    id: "3",
    name: "StreamQueen",
    avatar: "/gamer-avatar-3.png",
    followers: "1.2M",
    game: "Dota 2",
    isLive: false,
  },
  { id: "4", name: "TacticalAce", avatar: "/gamer-avatar-4.png", followers: "980K", game: "CS2", isLive: true },
]

const mockTeams = [
  { id: "1", name: "Team Alpha", logo: "/team-alpha-logo.jpg", followers: "5.2M", game: "CS2" },
  { id: "2", name: "Velocity Gaming", logo: "/esports-team-logo-2.jpg", followers: "3.8M", game: "Valorant" },
  { id: "3", name: "Phoenix Squad", logo: "/esports-team-logo-3.jpg", followers: "2.9M", game: "Dota 2" },
  { id: "4", name: "Thunder Esports", logo: "/esports-team-logo-4.jpg", followers: "2.1M", game: "Rocket League" },
]

const mockGames = [
  { id: "1", name: "Counter-Strike 2", thumbnail: "/cs2-game.jpg", viewers: "1.2M", category: "FPS" },
  { id: "2", name: "Valorant", thumbnail: "/valorant-game.jpg", viewers: "980K", category: "FPS" },
  { id: "3", name: "Dota 2", thumbnail: "/dota2-game.jpg", viewers: "750K", category: "MOBA" },
  { id: "4", name: "Rocket League", thumbnail: "/rocket-league-game.jpg", viewers: "520K", category: "Sports" },
]

const mockVODs = [
  {
    id: "101",
    title: "Championship Finals - Epic Comeback",
    thumbnail: "/vod-thumb-1.jpg",
    views: "2.5M",
    duration: "2:45:30",
    game: "CS2",
  },
  {
    id: "102",
    title: "Best Plays of the Week",
    thumbnail: "/vod-thumb-2.jpg",
    views: "1.8M",
    duration: "15:20",
    game: "Valorant",
  },
  {
    id: "103",
    title: "Tournament Highlights",
    thumbnail: "/vod-thumb-3.jpg",
    views: "1.2M",
    duration: "45:15",
    game: "Dota 2",
  },
  {
    id: "104",
    title: "Pro Player Interview",
    thumbnail: "/interview-panel.png",
    views: "890K",
    duration: "28:40",
    game: "CS2",
  },
]

export default function DiscoverPage() {
  const [activeTab, setActiveTab] = useState("discover")
  const [searchQuery, setSearchQuery] = useState("")
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [selectedFilter, setSelectedFilter] = useState("All")
  const router = useRouter()

  // Search suggestions based on query
  const getSearchSuggestions = () => {
    if (!searchQuery) return []

    const query = searchQuery.toLowerCase()
    const suggestions: any[] = []

    // Search streamers
    mockStreamers.forEach((streamer) => {
      if (streamer.name.toLowerCase().includes(query)) {
        suggestions.push({ type: "streamer", data: streamer })
      }
    })

    // Search teams
    mockTeams.forEach((team) => {
      if (team.name.toLowerCase().includes(query)) {
        suggestions.push({ type: "team", data: team })
      }
    })

    // Search games
    mockGames.forEach((game) => {
      if (game.name.toLowerCase().includes(query)) {
        suggestions.push({ type: "game", data: game })
      }
    })

    // Search VODs
    mockVODs.forEach((vod) => {
      if (vod.title.toLowerCase().includes(query)) {
        suggestions.push({ type: "vod", data: vod })
      }
    })

    return suggestions.slice(0, 8) // Limit to 8 suggestions
  }

  const suggestions = getSearchSuggestions()

  const handleSuggestionClick = (suggestion: any) => {
    if (suggestion.type === "vod") {
      router.push(`/vod/${suggestion.data.id}`)
    } else if (suggestion.type === "team") {
      router.push(`/team/${suggestion.data.id}`)
    }
    setSearchQuery("")
    setShowSuggestions(false)
  }

  const filters = ["All", "CS2", "Valorant", "Dota 2", "Rocket League"]

  return (
    <div className="flex flex-col min-h-screen" style={{ backgroundColor: "#000000" }}>
      {/* Search Header */}
      <div
        className="sticky top-0 z-50 px-4 py-4"
        style={{ backgroundColor: "#000000", borderBottom: "1px solid rgba(44, 215, 227, 0.2)" }}
      >
        <div className="relative">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search streamers, teams, games, VODs..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value)
                setShowSuggestions(true)
              }}
              onFocus={() => setShowSuggestions(true)}
              className="w-full pl-10 pr-10 py-3 rounded-lg text-white placeholder-gray-500 focus:outline-none transition-all"
              style={{
                backgroundColor: "#1a1a1a",
                border: "1px solid rgba(44, 215, 227, 0.3)",
              }}
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery("")
                  setShowSuggestions(false)
                }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            )}
          </div>

          {/* Search Suggestions Dropdown */}
          {showSuggestions && suggestions.length > 0 && (
            <div
              className="absolute top-full left-0 right-0 mt-2 rounded-lg overflow-hidden shadow-xl z-50"
              style={{
                backgroundColor: "#1a1a1a",
                border: "1px solid rgba(44, 215, 227, 0.3)",
              }}
            >
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-opacity-50 transition-colors text-left"
                  style={{
                    backgroundColor: "transparent",
                    borderBottom: index < suggestions.length - 1 ? "1px solid rgba(44, 215, 227, 0.1)" : "none",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = "rgba(44, 215, 227, 0.1)"
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = "transparent"
                  }}
                >
                  {suggestion.type === "streamer" && (
                    <>
                      <img
                        src={suggestion.data.avatar || "/placeholder.svg"}
                        alt=""
                        className="w-10 h-10 rounded-full"
                      />
                      <div className="flex-1">
                        <div className="text-white font-semibold">{suggestion.data.name}</div>
                        <div className="text-sm text-gray-400">
                          {suggestion.data.followers} followers • {suggestion.data.game}
                        </div>
                      </div>
                      {suggestion.data.isLive && (
                        <span
                          className="px-2 py-1 rounded text-xs font-bold"
                          style={{ backgroundColor: "#00FF00", color: "#000000" }}
                        >
                          LIVE
                        </span>
                      )}
                    </>
                  )}
                  {suggestion.type === "team" && (
                    <>
                      <img src={suggestion.data.logo || "/placeholder.svg"} alt="" className="w-10 h-10 rounded-lg" />
                      <div className="flex-1">
                        <div className="text-white font-semibold">{suggestion.data.name}</div>
                        <div className="text-sm text-gray-400">
                          {suggestion.data.followers} followers • {suggestion.data.game}
                        </div>
                      </div>
                    </>
                  )}
                  {suggestion.type === "game" && (
                    <>
                      <img
                        src={suggestion.data.thumbnail || "/placeholder.svg"}
                        alt=""
                        className="w-16 h-10 rounded object-cover"
                      />
                      <div className="flex-1">
                        <div className="text-white font-semibold">{suggestion.data.name}</div>
                        <div className="text-sm text-gray-400">
                          {suggestion.data.viewers} viewers • {suggestion.data.category}
                        </div>
                      </div>
                    </>
                  )}
                  {suggestion.type === "vod" && (
                    <>
                      <img
                        src={suggestion.data.thumbnail || "/placeholder.svg"}
                        alt=""
                        className="w-16 h-10 rounded object-cover"
                      />
                      <div className="flex-1">
                        <div className="text-white font-semibold">{suggestion.data.title}</div>
                        <div className="text-sm text-gray-400">
                          {suggestion.data.views} views • {suggestion.data.duration}
                        </div>
                      </div>
                      <Video size={16} className="text-gray-400" />
                    </>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Filter Chips */}
        <div className="flex items-center gap-2 mt-3 overflow-x-auto pb-2 scrollbar-hide">
          <button
            className="flex items-center gap-2 px-3 py-2 rounded-lg whitespace-nowrap transition-all"
            style={{ backgroundColor: "#1a1a1a", border: "1px solid rgba(44, 215, 227, 0.3)", color: "#2CD7E3" }}
          >
            <Filter size={16} />
            <span className="text-sm font-semibold">Filters</span>
          </button>
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setSelectedFilter(filter)}
              className="px-4 py-2 rounded-lg whitespace-nowrap text-sm font-semibold transition-all"
              style={{
                backgroundColor: selectedFilter === filter ? "#2CD7E3" : "#1a1a1a",
                color: selectedFilter === filter ? "#000000" : "#ffffff",
                border: selectedFilter === filter ? "none" : "1px solid rgba(44, 215, 227, 0.3)",
              }}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {/* Top Streamers Section */}
        <section className="px-4 py-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={20} style={{ color: "#2CD7E3" }} />
            <h2 className="text-xl font-bold text-white">Top Streamers</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {mockStreamers.map((streamer) => (
              <div
                key={streamer.id}
                className="rounded-lg p-3 transition-all cursor-pointer"
                style={{
                  backgroundColor: "#1a1a1a",
                  border: "1px solid rgba(44, 215, 227, 0.2)",
                }}
                onClick={() => router.push(`/team/${streamer.id}`)}
              >
                <div className="relative mb-2">
                  <img
                    src={streamer.avatar || "/placeholder.svg"}
                    alt={streamer.name}
                    className="w-full aspect-square rounded-lg object-cover"
                  />
                  {streamer.isLive && (
                    <span
                      className="absolute top-2 right-2 px-2 py-1 rounded text-xs font-bold"
                      style={{ backgroundColor: "#00FF00", color: "#000000" }}
                    >
                      LIVE
                    </span>
                  )}
                </div>
                <h3 className="text-white font-semibold text-sm mb-1 truncate">{streamer.name}</h3>
                <p className="text-gray-400 text-xs">{streamer.followers} followers</p>
                <p className="text-xs mt-1" style={{ color: "#2CD7E3" }}>
                  {streamer.game}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Ad Banner */}
        <AdBanner />

        {/* Popular Teams Section */}
        <section className="px-4 py-6">
          <div className="flex items-center gap-2 mb-4">
            <Users size={20} style={{ color: "#2CD7E3" }} />
            <h2 className="text-xl font-bold text-white">Popular Teams</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {mockTeams.map((team) => (
              <div
                key={team.id}
                className="rounded-lg p-3 transition-all cursor-pointer"
                style={{
                  backgroundColor: "#1a1a1a",
                  border: "1px solid rgba(44, 215, 227, 0.2)",
                }}
                onClick={() => router.push(`/team/${team.id}`)}
              >
                <img
                  src={team.logo || "/placeholder.svg"}
                  alt={team.name}
                  className="w-full aspect-square rounded-lg object-cover mb-2"
                />
                <h3 className="text-white font-semibold text-sm mb-1 truncate">{team.name}</h3>
                <p className="text-gray-400 text-xs">{team.followers} followers</p>
                <p className="text-xs mt-1" style={{ color: "#2CD7E3" }}>
                  {team.game}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Trending Games Section */}
        <section className="px-4 py-6">
          <div className="flex items-center gap-2 mb-4">
            <Gamepad2 size={20} style={{ color: "#2CD7E3" }} />
            <h2 className="text-xl font-bold text-white">Trending Games</h2>
          </div>
          <div className="space-y-3">
            {mockGames.map((game) => (
              <div
                key={game.id}
                className="flex items-center gap-3 rounded-lg p-3 transition-all cursor-pointer"
                style={{
                  backgroundColor: "#1a1a1a",
                  border: "1px solid rgba(44, 215, 227, 0.2)",
                }}
              >
                <img
                  src={game.thumbnail || "/placeholder.svg"}
                  alt={game.name}
                  className="w-24 h-16 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h3 className="text-white font-semibold mb-1">{game.name}</h3>
                  <p className="text-gray-400 text-sm">{game.viewers} viewers</p>
                  <p className="text-xs mt-1" style={{ color: "#2CD7E3" }}>
                    {game.category}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Trending VODs Section */}
        <section className="px-4 py-6">
          <div className="flex items-center gap-2 mb-4">
            <Video size={20} style={{ color: "#2CD7E3" }} />
            <h2 className="text-xl font-bold text-white">Trending VODs</h2>
          </div>
          <div className="space-y-3">
            {mockVODs.map((vod) => (
              <div
                key={vod.id}
                className="flex items-center gap-3 rounded-lg p-3 transition-all cursor-pointer"
                style={{
                  backgroundColor: "#1a1a1a",
                  border: "1px solid rgba(44, 215, 227, 0.2)",
                }}
                onClick={() => router.push(`/vod/${vod.id}`)}
              >
                <div className="relative">
                  <img
                    src={vod.thumbnail || "/placeholder.svg"}
                    alt={vod.title}
                    className="w-32 h-20 rounded-lg object-cover"
                  />
                  <span
                    className="absolute bottom-1 right-1 px-2 py-0.5 rounded text-xs font-semibold"
                    style={{ backgroundColor: "rgba(0, 0, 0, 0.8)", color: "#ffffff" }}
                  >
                    {vod.duration}
                  </span>
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-semibold text-sm mb-1 line-clamp-2">{vod.title}</h3>
                  <p className="text-gray-400 text-xs">{vod.views} views</p>
                  <p className="text-xs mt-1" style={{ color: "#2CD7E3" }}>
                    {vod.game}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab={activeTab} setActiveTab={setActiveTab} />

      <style jsx>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  )
}
