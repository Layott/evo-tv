"use client"

import { useState } from "react"
import { Search, Bell, BellOff, Shield } from "lucide-react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import BottomNavigation from "@/components/home/bottom-navigation"

// Mock events data
const mockEvents = [
  {
    id: "1",
    title: "World Championship Finals 2025",
    game: "League of Legends",
    region: "Global",
    logo: "/esports-tournament-logo.png",
    startDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
    status: "upcoming",
    isPartnerOnly: true,
  },
  {
    id: "2",
    title: "CS2 Major Championship",
    game: "Counter-Strike 2",
    region: "Europe",
    logo: "/cs2-tournament-logo.jpg",
    startDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
    status: "upcoming",
    isPartnerOnly: false,
  },
  {
    id: "3",
    title: "Valorant Champions Tour",
    game: "Valorant",
    region: "North America",
    logo: "/valorant-tournament-logo.jpg",
    startDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
    status: "upcoming",
    isPartnerOnly: false,
  },
  {
    id: "4",
    title: "Dota 2 International",
    game: "Dota 2",
    region: "Asia",
    logo: "/dota-2-tournament-logo.jpg",
    startDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days from now
    status: "upcoming",
    isPartnerOnly: true,
  },
  {
    id: "5",
    title: "Rocket League World Cup",
    game: "Rocket League",
    region: "Global",
    logo: "/rocket-league-tournament-logo.jpg",
    startDate: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000), // 21 days from now
    status: "upcoming",
    isPartnerOnly: false,
  },
]

const games = ["All Games", "League of Legends", "Counter-Strike 2", "Valorant", "Dota 2", "Rocket League"]
const regions = ["All Regions", "Global", "North America", "Europe", "Asia"]

export default function EventsPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("events")
  const [selectedGame, setSelectedGame] = useState("All Games")
  const [selectedRegion, setSelectedRegion] = useState("All Regions")
  const [notifiedEvents, setNotifiedEvents] = useState<Set<string>>(new Set())

  // Filter events based on selected filters
  const filteredEvents = mockEvents.filter((event) => {
    const gameMatch = selectedGame === "All Games" || event.game === selectedGame
    const regionMatch = selectedRegion === "All Regions" || event.region === selectedRegion
    return gameMatch && regionMatch
  })

  const toggleNotify = (eventId: string) => {
    setNotifiedEvents((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(eventId)) {
        newSet.delete(eventId)
      } else {
        newSet.add(eventId)
      }
      return newSet
    })
  }

  const getCountdown = (startDate: Date) => {
    const now = new Date()
    const diff = startDate.getTime() - now.getTime()
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))

    if (days > 0) {
      return `${days}d ${hours}h`
    }
    return `${hours}h`
  }

  return (
    <div className="flex flex-col min-h-screen" style={{ backgroundColor: "#000000" }}>
      {/* Top Navbar */}
      <div
        className="sticky top-0 z-50 flex items-center justify-between px-4 py-3 border-b"
        style={{
          backgroundColor: "#000000",
          borderColor: "rgba(44, 215, 227, 0.2)",
        }}
      >
        <h1 className="text-xl font-bold" style={{ color: "#2CD7E3" }}>
          Events
        </h1>
        <button className="p-2 rounded-lg transition-colors hover:bg-white/5">
          <Search size={24} style={{ color: "#2CD7E3" }} />
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {/* Filter Chips */}
        <div className="px-4 py-4 space-y-3">
          {/* Game Filter */}
          <div>
            <p className="text-sm font-semibold mb-2" style={{ color: "#999999" }}>
              Game
            </p>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {games.map((game) => (
                <button
                  key={game}
                  onClick={() => setSelectedGame(game)}
                  className="px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all"
                  style={{
                    backgroundColor: selectedGame === game ? "#2CD7E3" : "transparent",
                    color: selectedGame === game ? "#000000" : "#999999",
                    border: `1px solid ${selectedGame === game ? "#2CD7E3" : "rgba(153, 153, 153, 0.3)"}`,
                  }}
                >
                  {game}
                </button>
              ))}
            </div>
          </div>

          {/* Region Filter */}
          <div>
            <p className="text-sm font-semibold mb-2" style={{ color: "#999999" }}>
              Region
            </p>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {regions.map((region) => (
                <button
                  key={region}
                  onClick={() => setSelectedRegion(region)}
                  className="px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all"
                  style={{
                    backgroundColor: selectedRegion === region ? "#2CD7E3" : "transparent",
                    color: selectedRegion === region ? "#000000" : "#999999",
                    border: `1px solid ${selectedRegion === region ? "#2CD7E3" : "rgba(153, 153, 153, 0.3)"}`,
                  }}
                >
                  {region}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Event Cards */}
        <div className="px-4 space-y-4 pb-4">
          {filteredEvents.map((event) => (
            <div
              key={event.id}
              className="rounded-lg p-4 border cursor-pointer transition-all hover:border-[#2CD7E3]"
              style={{
                backgroundColor: "#0a0a0a",
                borderColor: "rgba(44, 215, 227, 0.2)",
              }}
              onClick={() => router.push(`/events/${event.id}`)}
            >
              <div className="flex gap-4">
                {/* Event Logo */}
                <div className="relative w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                  <Image src={event.logo || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
                  {event.isPartnerOnly && (
                    <div
                      className="absolute top-1 right-1 p-1 rounded"
                      style={{ backgroundColor: "rgba(44, 215, 227, 0.9)" }}
                    >
                      <Shield size={14} style={{ color: "#000000" }} />
                    </div>
                  )}
                </div>

                {/* Event Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base font-bold text-white mb-1 line-clamp-2">{event.title}</h3>
                      <p className="text-sm" style={{ color: "#999999" }}>
                        {event.game}
                      </p>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        toggleNotify(event.id)
                      }}
                      className="p-2 rounded-lg transition-colors hover:bg-white/5"
                    >
                      {notifiedEvents.has(event.id) ? (
                        <Bell size={20} style={{ color: "#2CD7E3" }} fill="#2CD7E3" />
                      ) : (
                        <BellOff size={20} style={{ color: "#666666" }} />
                      )}
                    </button>
                  </div>

                  <div className="flex items-center gap-4 text-sm">
                    <div>
                      <p style={{ color: "#999999" }}>Starts in</p>
                      <p className="font-bold" style={{ color: "#2CD7E3" }}>
                        {getCountdown(event.startDate)}
                      </p>
                    </div>
                    <div>
                      <p style={{ color: "#999999" }}>Region</p>
                      <p className="font-semibold text-white">{event.region}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  )
}
