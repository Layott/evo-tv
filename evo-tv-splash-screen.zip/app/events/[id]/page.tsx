"use client"

import { useState } from "react"
import { ArrowLeft, Bell, BellOff, Shield, ExternalLink, Play } from "lucide-react"
import { useRouter, useParams } from "next/navigation"
import Image from "next/image"

// Mock event detail data
const mockEventDetails: Record<string, any> = {
  "1": {
    id: "1",
    title: "World Championship Finals 2025",
    game: "League of Legends",
    region: "Global",
    logo: "/esports-tournament-logo.png",
    startDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
    description:
      "The ultimate showdown of the world's best League of Legends teams competing for glory and a $2M prize pool.",
    isPartnerOnly: true,
    bracketLink: "https://example.com/bracket",
    teams: [
      { name: "Team Alpha", logo: "/team-alpha-logo.jpg" },
      { name: "Team Beta", logo: "/team-beta-logo.jpg" },
      { name: "Team Gamma", logo: "/team-gamma-logo.jpg" },
      { name: "Team Delta", logo: "/team-delta-logo.jpg" },
    ],
    schedule: [
      { date: "Day 1", time: "14:00 UTC", match: "Team Alpha vs Team Beta", status: "upcoming" },
      { date: "Day 1", time: "17:00 UTC", match: "Team Gamma vs Team Delta", status: "upcoming" },
      { date: "Day 2", time: "14:00 UTC", match: "Winners Match", status: "upcoming" },
      { date: "Day 3", time: "16:00 UTC", match: "Grand Finals", status: "upcoming" },
    ],
    streamLink: "/stream/1",
    vodArchive: [
      {
        id: "101",
        title: "Semifinals - Team Alpha vs Team Omega",
        thumbnail: "/esports-match-highlight.jpg",
        duration: "2:45:30",
        views: "1.2M",
        uploadDate: "2 days ago",
      },
      {
        id: "102",
        title: "Quarterfinals - Team Beta vs Team Sigma",
        thumbnail: "/esports-tournament-match.jpg",
        duration: "1:58:15",
        views: "890K",
        uploadDate: "4 days ago",
      },
      {
        id: "103",
        title: "Group Stage - Day 3 Highlights",
        thumbnail: "/esports-highlights-compilation.jpg",
        duration: "45:20",
        views: "650K",
        uploadDate: "1 week ago",
      },
    ],
  },
  "2": {
    id: "2",
    title: "CS2 Major Championship",
    game: "Counter-Strike 2",
    region: "Europe",
    logo: "/cs2-tournament-logo.jpg",
    startDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
    description: "Europe's finest CS2 teams battle it out in this prestigious Major Championship.",
    isPartnerOnly: false,
    bracketLink: "https://example.com/bracket",
    teams: [
      { name: "Fnatic", logo: "/fnatic-logo.jpg" },
      { name: "G2 Esports", logo: "/g2-esports-logo.png" },
      { name: "Vitality", logo: "/vitality-logo.png" },
      { name: "NaVi", logo: "/navi-logo.png" },
    ],
    schedule: [
      { date: "Day 1", time: "12:00 UTC", match: "Fnatic vs G2 Esports", status: "upcoming" },
      { date: "Day 1", time: "15:00 UTC", match: "Vitality vs NaVi", status: "upcoming" },
      { date: "Day 2", time: "13:00 UTC", match: "Winners Match", status: "upcoming" },
    ],
    streamLink: "/stream/2",
    vodArchive: [
      {
        id: "201",
        title: "Opening Match - Fnatic Dominance",
        thumbnail: "/cs2-match-gameplay.jpg",
        duration: "1:32:45",
        views: "780K",
        uploadDate: "3 days ago",
      },
    ],
  },
}

export default function EventDetailPage() {
  const router = useRouter()
  const params = useParams()
  const eventId = params.id as string
  const [isNotified, setIsNotified] = useState(false)

  const event = mockEventDetails[eventId]

  if (!event) {
    return (
      <div className="flex items-center justify-center min-h-screen" style={{ backgroundColor: "#000000" }}>
        <p className="text-white">Event not found</p>
      </div>
    )
  }

  const getCountdown = (startDate: Date) => {
    const now = new Date()
    const diff = startDate.getTime() - now.getTime()
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))

    if (days > 0) {
      return `${days} days ${hours} hours`
    }
    return `${hours} hours`
  }

  return (
    <div className="flex flex-col min-h-screen" style={{ backgroundColor: "#000000" }}>
      {/* Top Navbar */}
      <div
        className="sticky top-0 z-50 flex items-center justify-between px-4 py-3 border-b"
        style={{
          backgroundColor: "#000000",
          borderColor: "rgba(44, 215, 227, 0.2)",
        }}
      >
        <button onClick={() => router.back()} className="p-2 rounded-lg transition-colors hover:bg-white/5">
          <ArrowLeft size={24} style={{ color: "#2CD7E3" }} />
        </button>
        <h1 className="text-lg font-bold text-white">Event Details</h1>
        <button
          onClick={() => setIsNotified(!isNotified)}
          className="p-2 rounded-lg transition-colors hover:bg-white/5"
        >
          {isNotified ? (
            <Bell size={24} style={{ color: "#2CD7E3" }} fill="#2CD7E3" />
          ) : (
            <BellOff size={24} style={{ color: "#666666" }} />
          )}
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto pb-6">
        {/* Event Header */}
        <div className="px-4 py-6 border-b" style={{ borderColor: "rgba(44, 215, 227, 0.2)" }}>
          <div className="flex gap-4 mb-4">
            <div className="relative w-24 h-24 rounded-lg overflow-hidden flex-shrink-0">
              <Image src={event.logo || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
              {event.isPartnerOnly && (
                <div
                  className="absolute top-2 right-2 p-1.5 rounded"
                  style={{ backgroundColor: "rgba(44, 215, 227, 0.9)" }}
                >
                  <Shield size={16} style={{ color: "#000000" }} />
                </div>
              )}
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-white mb-2">{event.title}</h2>
              <p className="text-sm mb-1" style={{ color: "#999999" }}>
                {event.game} • {event.region}
              </p>
              <p className="text-sm font-bold" style={{ color: "#2CD7E3" }}>
                Starts in {getCountdown(event.startDate)}
              </p>
            </div>
          </div>
          <p className="text-sm leading-relaxed" style={{ color: "#999999" }}>
            {event.description}
          </p>
        </div>

        {/* Bracket Link */}
        <div className="px-4 py-4 border-b" style={{ borderColor: "rgba(44, 215, 227, 0.2)" }}>
          <a
            href={event.bracketLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 rounded-lg border transition-all hover:border-[#2CD7E3]"
            style={{
              backgroundColor: "#0a0a0a",
              borderColor: "rgba(44, 215, 227, 0.2)",
            }}
          >
            <span className="font-semibold text-white">View Tournament Bracket</span>
            <ExternalLink size={20} style={{ color: "#2CD7E3" }} />
          </a>
        </div>

        {/* Teams */}
        <div className="px-4 py-4 border-b" style={{ borderColor: "rgba(44, 215, 227, 0.2)" }}>
          <h3 className="text-lg font-bold text-white mb-3">Participating Teams</h3>
          <div className="grid grid-cols-2 gap-3">
            {event.teams.map((team: any, index: number) => (
              <div
                key={index}
                className="flex items-center gap-3 p-3 rounded-lg border"
                style={{
                  backgroundColor: "#0a0a0a",
                  borderColor: "rgba(44, 215, 227, 0.2)",
                }}
              >
                <div className="relative w-10 h-10 rounded overflow-hidden flex-shrink-0">
                  <Image src={team.logo || "/placeholder.svg"} alt={team.name} fill className="object-cover" />
                </div>
                <span className="text-sm font-semibold text-white">{team.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Schedule */}
        <div className="px-4 py-4 border-b" style={{ borderColor: "rgba(44, 215, 227, 0.2)" }}>
          <h3 className="text-lg font-bold text-white mb-3">Schedule</h3>
          <div className="space-y-3">
            {event.schedule.map((item: any, index: number) => (
              <div
                key={index}
                className="p-4 rounded-lg border"
                style={{
                  backgroundColor: "#0a0a0a",
                  borderColor: "rgba(44, 215, 227, 0.2)",
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-bold" style={{ color: "#2CD7E3" }}>
                    {item.date}
                  </span>
                  <span className="text-sm" style={{ color: "#999999" }}>
                    {item.time}
                  </span>
                </div>
                <p className="text-sm font-semibold text-white">{item.match}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Stream Link */}
        <div className="px-4 py-4 border-b" style={{ borderColor: "rgba(44, 215, 227, 0.2)" }}>
          <button
            onClick={() => router.push(event.streamLink)}
            className="w-full p-4 rounded-lg font-bold text-lg transition-all hover:opacity-90"
            style={{
              backgroundColor: "#2CD7E3",
              color: "#000000",
            }}
          >
            Watch Live Stream
          </button>
        </div>

        {/* VOD Archive */}
        <div className="px-4 py-4">
          <h3 className="text-lg font-bold text-white mb-3">Past Matches (VOD Archive)</h3>
          <div className="space-y-3">
            {event.vodArchive.map((vod: any) => (
              <div
                key={vod.id}
                className="flex gap-3 p-3 rounded-lg border cursor-pointer transition-all hover:border-[#2CD7E3]"
                style={{
                  backgroundColor: "#0a0a0a",
                  borderColor: "rgba(44, 215, 227, 0.2)",
                }}
                onClick={() => router.push(`/vod/${vod.id}`)}
              >
                <div className="relative w-32 h-20 rounded overflow-hidden flex-shrink-0">
                  <Image src={vod.thumbnail || "/placeholder.svg"} alt={vod.title} fill className="object-cover" />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                    <Play size={24} style={{ color: "#2CD7E3" }} fill="#2CD7E3" />
                  </div>
                  <div
                    className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded text-xs font-bold"
                    style={{ backgroundColor: "rgba(0, 0, 0, 0.8)", color: "#ffffff" }}
                  >
                    {vod.duration}
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-semibold text-white mb-1 line-clamp-2">{vod.title}</h4>
                  <p className="text-xs mb-1" style={{ color: "#999999" }}>
                    {vod.views} views • {vod.uploadDate}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
